OxyCam - OxygenOS 16 style camera (native CameraX, Kotlin)
Build: GitHub repo mein sab files upload karo (root par .github, app, build.gradle.kts, settings.gradle.kts, gradle.properties),
Actions tab -> "Build APK" -> artifact "OxyCam-debug-apk" download karo.
