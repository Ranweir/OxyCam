package com.oxycam.eis

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Timestamped CAMERA-frame orientation quaternions in a circular buffer.
 *
 * Source: TYPE_GAME_ROTATION_VECTOR (fused gyro + accelerometer, no magnetometer) at SENSOR_DELAY_FASTEST;
 * if the phone has none it integrates TYPE_GYROSCOPE itself. Quaternions are stored as camera->world rotations in the
 * camera's own axes (x right, y down, z forward in SENSOR orientation), so rows of the sensor map to time directly.
 * [slerpAt] returns the orientation at any time by SLERP between the two neighbouring samples.
 *
 * Timestamps are in the sensor clock (elapsedRealtime nanoseconds).
 */
class GyroEisBuffer(ctx: Context, sensorOrientationDeg: Int, private val capacity: Int = 8192) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var thread: HandlerThread? = null

    private val ts = LongArray(capacity)
    private val q = DoubleArray(capacity * 4)
    private var head = 0   // next write position
    private var count = 0

    private val qc = DoubleArray(4)          // camera axes expressed in device axes
    private val qDev = Quat.identity()       // integrated device orientation (gyro fallback)
    private var lastGyroTs = 0L
    private val tmpA = DoubleArray(4)
    private val tmpB = DoubleArray(4)
    private val tmpC = DoubleArray(4)
    private val rv = FloatArray(4)
    @Volatile var usingRotationVector = false
        private set

    init {
        // camera -> device:  C = diag(1,-1,-1) * Rz(sensorOrientation)   (verified for 90 deg: rows (0,-1,0) (-1,0,0) (0,0,-1))
        val c0 = doubleArrayOf(0.0, 1.0, 0.0, 0.0)
        val th = Math.toRadians(sensorOrientationDeg.toDouble())
        val rz = doubleArrayOf(cos(th / 2), 0.0, 0.0, sin(th / 2))
        Quat.mul(c0, rz, qc)
        Quat.normalize(qc)
    }

    fun start(): Boolean {
        val grv = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val sensor = grv ?: gyro ?: return false
        usingRotationVector = grv != null
        synchronized(this) { head = 0; count = 0 }
        val th = HandlerThread("eis-gyro")
        th.start()
        thread = th
        return sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_FASTEST, Handler(th.looper))
    }

    fun stop() {
        sm.unregisterListener(this)
        thread?.quitSafely()
        thread = null
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_GAME_ROTATION_VECTOR) {
            SensorManager.getQuaternionFromVector(rv, e.values) // [w, x, y, z]
            tmpA[0] = rv[0].toDouble(); tmpA[1] = rv[1].toDouble(); tmpA[2] = rv[2].toDouble(); tmpA[3] = rv[3].toDouble()
            Quat.normalize(tmpA)
            push(e.timestamp, tmpA)
        } else {
            // gyro fallback: q <- q * exp(w dt) in device axes
            if (lastGyroTs != 0L) {
                val dt = ((e.timestamp - lastGyroTs) * 1e-9).coerceIn(0.0, 0.05)
                Quat.fromRotVec(e.values[0] * dt, e.values[1] * dt, e.values[2] * dt, tmpB)
                Quat.mul(qDev, tmpB, tmpC)
                Quat.set(qDev, tmpC)
                Quat.normalize(qDev)
            }
            lastGyroTs = e.timestamp
            push(e.timestamp, qDev)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @Synchronized
    private fun push(t: Long, qDevice: DoubleArray) {
        Quat.mul(qDevice, qc, tmpC) // camera orientation = device orientation * camera-in-device
        Quat.normalize(tmpC)
        if (count > 0) {
            val p = ((head - 1 + capacity) % capacity) * 4
            if (q[p] * tmpC[0] + q[p + 1] * tmpC[1] + q[p + 2] * tmpC[2] + q[p + 3] * tmpC[3] < 0) {
                tmpC[0] = -tmpC[0]; tmpC[1] = -tmpC[1]; tmpC[2] = -tmpC[2]; tmpC[3] = -tmpC[3]
            }
        }
        ts[head] = t
        val o = head * 4
        q[o] = tmpC[0]; q[o + 1] = tmpC[1]; q[o + 2] = tmpC[2]; q[o + 3] = tmpC[3]
        head = (head + 1) % capacity
        if (count < capacity) count++
    }

    private fun phys(i: Int): Int = (head - count + i + capacity * 2) % capacity

    @Synchronized
    fun latestTimestamp(): Long = if (count == 0) 0L else ts[phys(count - 1)]

    /** Camera orientation at [tNs]. False if there is no data near that time. */
    @Synchronized
    fun slerpAt(tNs: Long, out: DoubleArray): Boolean {
        if (count < 2) return false
        val firstT = ts[phys(0)]
        val lastT = ts[phys(count - 1)]
        if (tNs <= firstT) {
            load(phys(0), out)
            return firstT - tNs < 20_000_000L
        }
        if (tNs >= lastT) {
            load(phys(count - 1), out)
            return tNs - lastT < 40_000_000L
        }
        var lo = 0
        var hi = count - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (ts[phys(mid)] <= tNs) lo = mid else hi = mid
        }
        val a = phys(lo)
        val b = phys(hi)
        val span = (ts[b] - ts[a]).toDouble()
        val f = if (span <= 0) 0.0 else (tNs - ts[a]) / span
        load(a, tmpA)
        load(b, tmpB)
        Quat.slerp(tmpA, tmpB, f, out)
        return true
    }

    private fun load(p: Int, out: DoubleArray) {
        val o = p * 4
        out[0] = q[o]; out[1] = q[o + 1]; out[2] = q[o + 2]; out[3] = q[o + 3]
    }
}

/**
 * Maps camera frame timestamps onto the sensor clock used by [GyroEisBuffer].
 * - SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME: the clocks are the same, only a small manual trim is applied.
 * - UNKNOWN: the offset is estimated from frame arrival times (the smallest "arrival - frame time - readout" seen
 *   recently is the cleanest estimate) and tracked slowly.
 * [refine] lets any other calibrator (e.g. optical-flow vs gyro correlation) nudge the offset.
 */
class ClockSync(private val realtimeSource: Boolean) {
    @Volatile var trimNs = 0L
    @Volatile private var offsetNs = 0L
    private val win = LongArray(90)
    private var wn = 0
    private var wi = 0
    private var inited = false

    fun onFrame(frameTs: Long, arrivalElapsedNs: Long, exposureNs: Long, skewNs: Long) {
        if (realtimeSource) return
        val d = arrivalElapsedNs - frameTs - exposureNs - skewNs - 4_000_000L
        win[wi] = d
        wi = (wi + 1) % win.size
        if (wn < win.size) wn++
        var mn = Long.MAX_VALUE
        for (i in 0 until wn) if (win[i] < mn) mn = win[i]
        if (!inited) { offsetNs = mn; inited = true } else offsetNs += (mn - offsetNs) / 16
    }

    fun refine(deltaNs: Long) { trimNs += deltaNs }

    /** Frame timestamp (exposure start of the first row) expressed in the sensor clock. */
    fun toSensorClock(frameTs: Long): Long = frameTs + (if (realtimeSource) 0L else offsetNs) + trimNs

    /** Timestamp to give the encoder (elapsedRealtime base, so audio stays in sync). */
    fun toEncoderClock(frameTs: Long): Long = frameTs + (if (realtimeSource) 0L else offsetNs)
}

internal fun hypot3(x: Double, y: Double, z: Double): Double = sqrt(x * x + y * y + z * z)
