package com.oxycam

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

/** Bakes a colour look into a finished recording (export runs after recording stops). Call from the main thread. */
object VideoFilter {
    fun apply(ctx: Context, src: Uri, look: Filters.Look, out: File, done: (Boolean, String?) -> Unit) {
        export(ctx, src, emptyList(), look, 0, out, done)
    }

    /**
     * One export pass: [pre] effects first (e.g. gyro stabilisation), then the optional colour [look].
     * [bitrate] > 0 asks the encoder for that video bitrate (otherwise the exporter picks its own).
     */
    fun export(
        ctx: Context, src: Uri, pre: List<Effect>, look: Filters.Look?, bitrate: Int, out: File,
        done: (Boolean, String?) -> Unit
    ) {
        val fx = ArrayList<Effect>(pre)
        if (look != null) addLook(fx, look)
        val item = EditedMediaItem.Builder(MediaItem.fromUri(src))
            .setEffects(Effects(emptyList(), fx))
            .build()
        val tb = Transformer.Builder(ctx)
        if (bitrate > 0) {
            tb.setEncoderFactory(
                DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                    .setEnableFallback(true)
                    .build()
            )
        }
        val t = tb
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    done(true, null)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    done(false, exportException.message)
                }
            })
            .build()
        t.start(item, out.absolutePath)
    }

    private fun addLook(fx: MutableList<Effect>, look: Filters.Look) {
        if (look.r != 1f || look.g != 1f || look.b != 1f) {
            fx.add(RgbAdjustment.Builder().setRedScale(look.r).setGreenScale(look.g).setBlueScale(look.b).build())
        }
        if (look.sat != 1f) {
            fx.add(HslAdjustment.Builder().adjustSaturation(((look.sat - 1f) * 100f).coerceIn(-100f, 100f)).build())
        }
        if (look.contrast != 1f) fx.add(Contrast((look.contrast - 1f).coerceIn(-1f, 1f)))
        if (look.bright != 0f) fx.add(Brightness((look.bright / 255f).coerceIn(-1f, 1f)))
    }
}
