package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Draws histogram, zebra (over-exposure) and focus-peaking cells computed from the live preview. */
class AnalysisOverlay(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var showHist = false
    var showZebra = false
    var showPeak = false

    private var hist = IntArray(64)
    private var zebra = BooleanArray(0)
    private var peak = BooleanArray(0)
    private var cols = 1
    private var rows = 1
    private val d = resources.displayMetrics.density
    private val pz = Paint().apply { color = Color.argb(120, 255, 220, 0) }
    private val pp = Paint().apply { color = Color.argb(200, 255, 40, 40) }
    private val pb = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val ph = Paint().apply { color = Color.WHITE }

    fun update(h: IntArray, z: BooleanArray, p: BooleanArray, c: Int, r: Int) {
        hist = h
        zebra = z
        peak = p
        cols = c
        rows = r
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cw = width / cols.toFloat()
        val ch = height / rows.toFloat()
        if (showZebra && zebra.size == cols * rows) {
            for (y in 0 until rows) for (x in 0 until cols) {
                if (zebra[y * cols + x] && (x + y) % 2 == 0) canvas.drawRect(x * cw, y * ch, (x + 1) * cw, (y + 1) * ch, pz)
            }
        }
        if (showPeak && peak.size == cols * rows) {
            for (y in 0 until rows) for (x in 0 until cols) {
                if (peak[y * cols + x]) canvas.drawRect(x * cw, y * ch, (x + 0.8f) * cw, (y + 0.8f) * ch, pp)
            }
        }
        if (showHist) {
            val bw = 128 * d
            val bh = 56 * d
            val l = 10 * d
            val t = 10 * d
            canvas.drawRect(l, t, l + bw, t + bh, pb)
            val mx = (hist.maxOrNull() ?: 1).coerceAtLeast(1)
            val step = bw / hist.size
            for (i in hist.indices) {
                val hh = bh * hist[i] / mx
                canvas.drawRect(l + i * step, t + bh - hh, l + (i + 1) * step, t + bh, ph)
            }
        }
    }
}
