package com.oxycam

import androidx.media3.effect.GlMatrixTransformation
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Gyroscope-driven stabilisation as a per-frame transform.
 *
 * 1. The gyro rates (converted to the camera frame) are integrated into a camera orientation q(t).
 * 2. The "ideal" smooth orientation is a Gaussian-weighted mean of the real orientation around each frame,
 *    taken on the rotation manifold. It looks both into the past and the future, so it behaves like a gimbal.
 * 3. The difference between real and smooth orientation becomes a rotation homography K * R * K^-1 that is
 *    applied to the frame, together with a crop that hides the borders.
 *
 * level 1 = GYRO EIS   : short window, fixed
 * level 2 = GYRO EIS+  : longer window, window shrinks while you pan on purpose (pan aware)
 * level 3 = GYRO EIS++ : longest window, pan aware, plus first-order rolling-shutter correction
 */
class StabTransform(
    private val d: GyroData,
    private val level: Int,
    private val focal: Double,        // focal length in units of "half image height" (F = 2 f / sensorLongSide)
    private val aspect: Double,       // frame width / height (upright)
    private val videoStartNs: Long,   // gyro-clock time of video frame 0
    invert: Boolean,
    private val rsSign: Double,
    private val readoutS: Double
) : GlMatrixTransformation {

    private val n = d.n
    private val qw = DoubleArray(n)
    private val qx = DoubleArray(n)
    private val qy = DoubleArray(n)
    private val qz = DoubleArray(n)
    private val wx = DoubleArray(n)
    private val wy = DoubleArray(n)
    private val wz = DoubleArray(n)

    private val sigma0 = when (level) { 1 -> 0.14; 2 -> 0.40; else -> 0.80 }
    private val crop = when (level) { 1 -> 1.08; 2 -> 1.12; else -> 1.18 }
    private val adaptive = level >= 2
    private val w0 = if (level == 2) 0.30 else 0.45
    private val rsOn = level >= 3
    private val maxPitch = atan((crop - 1.0) / crop / focal) * 0.85
    private val maxYaw = atan((crop - 1.0) / crop * aspect / focal) * 0.85
    private val maxRoll = (crop - 1.0) / (crop * 1.5) * 0.85

    private var lastUs = Long.MIN_VALUE
    private var last = FloatArray(16)

    init {
        // device axes (x right, y up, z out of screen)  ->  camera axes (x right, y down, z forward)
        val sgn = if (invert) -1.0 else 1.0
        for (i in 0 until n) {
            wx[i] = sgn * d.x[i]
            wy[i] = -sgn * d.y[i]
            wz[i] = -sgn * d.z[i]
        }
        qw[0] = 1.0
        for (i in 1 until n) {
            val dt = ((d.t[i] - d.t[i - 1]) * 1e-9).coerceIn(0.0, 0.05)
            val ax = (wx[i] + wx[i - 1]) * 0.5 * dt
            val ay = (wy[i] + wy[i - 1]) * 0.5 * dt
            val az = (wz[i] + wz[i - 1]) * 0.5 * dt
            val ang = sqrt(ax * ax + ay * ay + az * az)
            val c = cos(ang / 2)
            val s = if (ang < 1e-9) 0.5 else sin(ang / 2) / ang
            val bw = c
            val bx = s * ax
            val by = s * ay
            val bz = s * az
            val aw = qw[i - 1]
            val axq = qx[i - 1]
            val ayq = qy[i - 1]
            val azq = qz[i - 1]
            var rw = aw * bw - axq * bx - ayq * by - azq * bz
            var rx = aw * bx + axq * bw + ayq * bz - azq * by
            var ry = aw * by - axq * bz + ayq * bw + azq * bx
            var rz = aw * bz + axq * by - ayq * bx + azq * bw
            val nn = sqrt(rw * rw + rx * rx + ry * ry + rz * rz)
            rw /= nn; rx /= nn; ry /= nn; rz /= nn
            qw[i] = rw; qx[i] = rx; qy[i] = ry; qz[i] = rz
        }
    }

    private fun lowerBound(tNs: Long): Int {
        var lo = 0
        var hi = n
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (d.t[m] < tNs) lo = m + 1 else hi = m
        }
        return lo
    }

    private fun nearest(tNs: Long): Int {
        val i = lowerBound(tNs)
        if (i <= 0) return 0
        if (i >= n) return n - 1
        return if (tNs - d.t[i - 1] < d.t[i] - tNs) i - 1 else i
    }

    private fun meanSpeed(t0: Long, t1: Long): Double {
        val lo = lowerBound(t0).coerceAtMost(n - 1)
        val hi = lowerBound(t1).coerceIn(lo, n - 1)
        val stride = max(1, (hi - lo) / 80)
        var s = 0.0
        var c = 0
        var k = lo
        while (k <= hi) {
            s += sqrt(wx[k] * wx[k] + wy[k] * wy[k] + wz[k] * wz[k])
            c++
            k += stride
        }
        return if (c == 0) 0.0 else s / c
    }

    /** Weighted mean of log(q_now^-1 * q_k) over the window: how far the smooth path is from the real one. */
    private fun tangentMean(i: Int, tg: Long, sigma: Double): DoubleArray {
        val half = (3 * sigma * 1e9).toLong()
        val lo = lowerBound(tg - half).coerceAtMost(n - 1)
        val hi = lowerBound(tg + half).coerceIn(lo, n - 1)
        val stride = max(1, (hi - lo) / 200)
        val aw = qw[i]
        val ax = -qx[i]
        val ay = -qy[i]
        val az = -qz[i]
        var sx = 0.0
        var sy = 0.0
        var sz = 0.0
        var sw = 0.0
        var k = lo
        while (k <= hi) {
            val bw = qw[k]
            val bx = qx[k]
            val by = qy[k]
            val bz = qz[k]
            var rw = aw * bw - ax * bx - ay * by - az * bz
            var rx = aw * bx + ax * bw + ay * bz - az * by
            var ry = aw * by - ax * bz + ay * bw + az * bx
            var rz = aw * bz + ax * by - ay * bx + az * bw
            if (rw < 0) { rw = -rw; rx = -rx; ry = -ry; rz = -rz }
            val vn = sqrt(rx * rx + ry * ry + rz * rz)
            val f = if (vn < 1e-9) 2.0 else 2.0 * atan2(vn, rw) / vn
            val dts = (d.t[k] - tg) * 1e-9
            val wgt = exp(-0.5 * (dts / sigma) * (dts / sigma))
            sx += wgt * rx * f
            sy += wgt * ry * f
            sz += wgt * rz * f
            sw += wgt
            k += stride
        }
        if (sw <= 0.0) return doubleArrayOf(0.0, 0.0, 0.0)
        return doubleArrayOf(sx / sw, sy / sw, sz / sw)
    }

    private fun softClamp(v: Double, m: Double): Double = m * tanh(v / m)

    private fun rodrigues(rx: Double, ry: Double, rz: Double): DoubleArray {
        val th = sqrt(rx * rx + ry * ry + rz * rz)
        if (th < 1e-9) return doubleArrayOf(1.0, -rz, ry, rz, 1.0, -rx, -ry, rx, 1.0)
        val kx = rx / th
        val ky = ry / th
        val kz = rz / th
        val s = sin(th)
        val c = 1.0 - cos(th)
        // R = I + s*K + c*K^2, K = skew(k)
        val k2xx = -(ky * ky + kz * kz)
        val k2yy = -(kx * kx + kz * kz)
        val k2zz = -(kx * kx + ky * ky)
        val k2xy = kx * ky
        val k2xz = kx * kz
        val k2yz = ky * kz
        return doubleArrayOf(
            1.0 + c * k2xx, -s * kz + c * k2xy, s * ky + c * k2xz,
            s * kz + c * k2xy, 1.0 + c * k2yy, -s * kx + c * k2yz,
            -s * ky + c * k2xz, s * kx + c * k2yz, 1.0 + c * k2zz
        )
    }

    private fun mul(a: DoubleArray, b: DoubleArray): DoubleArray {
        val r = DoubleArray(9)
        for (i in 0..2) for (j in 0..2) {
            r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j]
        }
        return r
    }

    private fun compute(tg: Long): DoubleArray {
        var rx = 0.0
        var ry = 0.0
        var rz = 0.0
        var vx = 0.0
        var vy = 0.0
        var vz = 0.0
        if (n > 8 && tg >= d.t[0] && tg <= d.t[n - 1]) {
            val i = nearest(tg)
            val avg = meanSpeed(tg - 200_000_000L, tg + 200_000_000L)
            val sigma = if (adaptive) max(0.07, sigma0 / (1.0 + (avg / w0).pow(2.0))) else sigma0
            val v = tangentMean(i, tg, sigma)
            rx = softClamp(v[0], maxPitch)
            ry = softClamp(v[1], maxYaw)
            rz = softClamp(v[2], maxRoll)
            if (rsOn) {
                val lo = lowerBound(tg - 6_000_000L).coerceAtMost(n - 1)
                val hi = lowerBound(tg + 6_000_000L).coerceIn(lo, n - 1)
                var c = 0
                for (k in lo..hi) { vx += wx[k]; vy += wy[k]; vz += wz[k]; c++ }
                if (c > 0) { vx /= c; vy /= c; vz /= c }
            }
        }
        val rot = rodrigues(-rx, -ry, -rz)
        val kk = doubleArrayOf(focal / aspect, 0.0, 0.0, 0.0, -focal, 0.0, 0.0, 0.0, 1.0)
        val ki = doubleArrayOf(aspect / focal, 0.0, 0.0, 0.0, -1.0 / focal, 0.0, 0.0, 0.0, 1.0)
        var h = mul(mul(kk, rot), ki)
        if (rsOn) {
            val s = readoutS * 0.5 * rsSign
            val r1x = (vx * s).coerceIn(-0.03, 0.03)
            val r1y = (vy * s).coerceIn(-0.03, 0.03)
            val mrs = doubleArrayOf(1.0 + (focal / aspect) * r1y, 0.0, 0.0, focal * r1x, 1.0, 0.0, 0.0, 0.0, 1.0)
            h = mul(h, mrs)
        }
        for (c in 0..2) { h[c] *= crop; h[3 + c] *= crop }
        return h
    }

    override fun getGlMatrixArray(presentationTimeUs: Long): FloatArray {
        if (presentationTimeUs == lastUs) return last
        val h = compute(videoStartNs + presentationTimeUs * 1000L)
        val m = FloatArray(16)
        m[0] = h[0].toFloat(); m[1] = h[3].toFloat(); m[3] = h[6].toFloat()
        m[4] = h[1].toFloat(); m[5] = h[4].toFloat(); m[7] = h[7].toFloat()
        m[10] = 1f
        m[12] = h[2].toFloat(); m[13] = h[5].toFloat(); m[15] = h[8].toFloat()
        lastUs = presentationTimeUs
        last = m
        return m
    }
}
