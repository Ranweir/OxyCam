package com.oxycam

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

/**
 * Live sharpening of what the viewfinder shows (done on the GPU, so it costs almost nothing).
 * It needs Android 13+ (AGSL shaders). On older phones nothing is applied and the camera's own picture is shown.
 */
object ViewfinderFx {
    // Unsharp mask: pixel + amount * (pixel - average of its 4 neighbours)
    private const val AGSL = """
        uniform shader image;
        uniform float amount;
        half4 main(float2 c) {
            half4 p = image.eval(c);
            half4 n = image.eval(c + float2(0.0, -1.0));
            half4 s = image.eval(c + float2(0.0, 1.0));
            half4 e = image.eval(c + float2(1.0, 0.0));
            half4 w = image.eval(c + float2(-1.0, 0.0));
            half3 blur = (n.rgb + s.rgb + e.rgb + w.rgb) * 0.25;
            half3 outc = p.rgb + half(amount) * (p.rgb - blur);
            return half4(clamp(outc, half3(0.0), half3(1.0)), p.a);
        }
    """

    fun supported(): Boolean = Build.VERSION.SDK_INT >= 33

    fun apply(view: View, level: Int) {
        if (Build.VERSION.SDK_INT < 33) return
        set(view, level)
    }

    @RequiresApi(33)
    private fun set(view: View, level: Int) {
        try {
            if (level <= 0) {
                view.setRenderEffect(null)
                return
            }
            val amount = floatArrayOf(0f, 0.45f, 0.8f, 1.2f)[level.coerceIn(0, 3)]
            val shader = RuntimeShader(AGSL)
            shader.setFloatUniform("amount", amount)
            view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(shader, "image"))
        } catch (t: Throwable) {
            // shader not accepted on this GPU: leave the viewfinder as it is
        }
    }
}
