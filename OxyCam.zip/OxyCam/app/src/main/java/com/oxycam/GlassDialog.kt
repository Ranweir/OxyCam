package com.oxycam

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.camera.view.PreviewView

/**
 * Rounded "frosted glass" dialogs: the screen behind is blurred, the panel is translucent with
 * rounded corners and it grows out of the row that was tapped.
 */
object GlassDialog {
    class Handle {
        var closer: () -> Unit = {}
        fun close() = closer()
    }

    internal class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }
    }

    fun accent(ctx: Context): Int = ThemeColors.color(ctx)

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /** Small blurred copy of whatever is on screen right now. */
    internal fun frosted(act: Activity, live: PreviewView?): Bitmap? = try {
        val v = act.window.decorView
        val w = (v.width / 8).coerceAtLeast(8)
        val h = (v.height / 8).coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(w / v.width.toFloat(), h / v.height.toFloat())
        v.draw(c)
        // the camera preview is a hardware surface and shows up black in v.draw(): paste the real frame in
        if (live != null) {
            val pb = live.bitmap
            if (pb != null) {
                val a = IntArray(2)
                val b = IntArray(2)
                live.getLocationInWindow(a)
                v.getLocationInWindow(b)
                val l = a[0] - b[0]
                val t = a[1] - b[1]
                val paint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.LIGHTEN) }
                c.drawBitmap(pb, null, Rect(l, t, l + live.width, t + live.height), paint)
            }
        }
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.setPixels(Processor.boxBlur(px, w, h, 3), 0, w, 0, 0, w, h)
        bmp
    } catch (t: Throwable) {
        null
    }

    private fun titleView(act: Activity, title: String) = TextView(act).apply {
        text = title
        textSize = 20f
        setTextColor(Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(dp(act, 26), 0, dp(act, 26), dp(act, 12))
    }

    private fun present(act: Activity, anchor: View?, live: PreviewView?, build: (LinearLayout, MutableList<View>, Handle) -> Unit) {
        val d = Dialog(act, android.R.style.Theme_Translucent_NoTitleBar)
        val handle = Handle()
        val rows = ArrayList<View>()
        val root = FrameLayout(act)
        val scrim = FrameLayout(act)
        val img = ImageView(act).apply { scaleType = ImageView.ScaleType.FIT_XY }
        val blurred = frosted(act, live)
        if (blurred != null) img.setImageBitmap(blurred)
        scrim.addView(img, FrameLayout.LayoutParams(-1, -1))
        scrim.addView(
            View(act).apply { setBackgroundColor(Color.argb(if (blurred != null) 85 else 170, 0, 0, 0)) },
            FrameLayout.LayoutParams(-1, -1)
        )
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val radius = dp(act, 28).toFloat()
        val panel = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(125, 70, 70, 80), Color.argb(105, 28, 28, 34))
            ).apply {
                cornerRadius = radius
                setStroke(dp(act, 1), Color.argb(80, 255, 255, 255))
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            isClickable = true
            setPadding(0, dp(act, 22), 0, dp(act, 10))
        }
        val lp = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)
        lp.setMargins(dp(act, 28), 0, dp(act, 28), 0)
        root.addView(panel, lp)
        build(panel, rows, handle)

        d.setContentView(root)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(-1, -1)
            setWindowAnimations(0)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        var closing = false
        handle.closer = {
            if (!closing) {
                closing = true
                panel.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f)
                    .translationY(dp(act, 10).toFloat())
                    .setDuration(170).setInterpolator(AccelerateInterpolator()).start()
                scrim.animate().alpha(0f).setDuration(190).withEndAction {
                    try { d.dismiss() } catch (t: Throwable) { }
                }.start()
            }
        }
        scrim.setOnClickListener { handle.close() }
        d.setOnKeyListener { _, keyCode, ev ->
            if (keyCode == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                handle.close()
                true
            } else false
        }

        panel.alpha = 0f
        scrim.alpha = 0f
        d.show()
        root.post {
            var dx = 0f
            var dy = dp(act, 40).toFloat()
            if (anchor != null) {
                val a = IntArray(2)
                val p = IntArray(2)
                anchor.getLocationOnScreen(a)
                panel.getLocationOnScreen(p)
                dx = (a[0] + anchor.width / 2f) - (p[0] + panel.width / 2f)
                dy = (a[1] + anchor.height / 2f) - (p[1] + panel.height / 2f)
            }
            panel.pivotX = panel.width / 2f
            panel.pivotY = panel.height / 2f
            panel.translationX = dx * 0.8f
            panel.translationY = dy * 0.8f
            panel.scaleX = 0.6f
            panel.scaleY = 0.6f
            panel.alpha = 0f
            panel.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(340).setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f)).start()
            scrim.animate().alpha(1f).setDuration(280).start()
            for ((i, r) in rows.withIndex()) {
                r.alpha = 0f
                r.translationY = dp(act, 10).toFloat()
                r.animate().alpha(1f).translationY(0f).setStartDelay(120L + i * 28L).setDuration(240)
                    .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f)).start()
            }
        }
    }

    fun choice(
        act: Activity, title: String, options: List<String>, current: Int, anchor: View?,
        live: PreviewView? = null, swatches: List<Int>? = null, onPick: (Int) -> Unit
    ) {
        val acc = accent(act)
        present(act, anchor, live) { panel, rows, h ->
            panel.addView(titleView(act, title))
            val maxH = (act.resources.displayMetrics.heightPixels * 0.62f).toInt()
            val sv = MaxHeightScroll(act, maxH)
            sv.isVerticalScrollBarEnabled = false
            val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            val tv = TypedValue()
            act.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            for ((i, o) in options.withIndex()) {
                val row = LinearLayout(act).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    minimumHeight = dp(act, 52)
                    setPadding(dp(act, 26), 0, dp(act, 26), 0)
                    setBackgroundResource(tv.resourceId)
                }
                if (swatches != null && i < swatches.size) {
                    val dot = View(act).apply {
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(swatches[i])
                            setStroke(dp(act, 1), Color.argb(110, 255, 255, 255))
                        }
                    }
                    val dlp = LinearLayout.LayoutParams(dp(act, 20), dp(act, 20))
                    dlp.setMargins(0, 0, dp(act, 14), 0)
                    row.addView(dot, dlp)
                }
                row.addView(
                    TextView(act).apply {
                        text = o
                        textSize = 17f
                        setTextColor(if (i == current) acc else Color.WHITE)
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                if (i == current) {
                    row.addView(TextView(act).apply {
                        text = "✓"
                        textSize = 18f
                        setTextColor(acc)
                    })
                }
                row.setOnClickListener {
                    onPick(i)
                    h.close()
                }
                col.addView(row)
                rows.add(row)
            }
            sv.addView(col)
            panel.addView(sv, LinearLayout.LayoutParams(-1, -2))
        }
    }

    /** Picker that shows every focus ring style drawn, three per row. */
    fun focusStyles(act: Activity, title: String, current: Int, anchor: View?, onPick: (Int) -> Unit) {
        val acc = accent(act)
        present(act, anchor, null) { panel, rows, h ->
            panel.addView(titleView(act, title))
            val maxH = (act.resources.displayMetrics.heightPixels * 0.7f).toInt()
            val sv = MaxHeightScroll(act, maxH)
            sv.isVerticalScrollBarEnabled = false
            val col = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(act, 12), 0, dp(act, 12), dp(act, 8))
            }
            val names = FocusRingView.STYLE_NAMES
            var i = 0
            while (i < names.size) {
                val line = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
                for (j in 0 until 3) {
                    val idx = i + j
                    val cell = LinearLayout(act).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER_HORIZONTAL
                        setPadding(dp(act, 4), dp(act, 4), dp(act, 4), dp(act, 6))
                    }
                    if (idx < names.size) {
                        val fv = FocusRingView(act)
                        fv.ringStyle = idx
                        fv.showSlider = false
                        cell.addView(fv, LinearLayout.LayoutParams(dp(act, 88), dp(act, 88)))
                        cell.addView(TextView(act).apply {
                            text = names[idx]
                            textSize = 11f
                            gravity = Gravity.CENTER
                            maxLines = 2
                            setTextColor(if (idx == current) acc else Color.WHITE)
                        })
                        if (idx == current) {
                            cell.background = GradientDrawable().apply {
                                cornerRadius = dp(act, 12).toFloat()
                                setStroke(dp(act, 1), acc)
                            }
                        }
                        cell.setOnClickListener {
                            onPick(idx)
                            h.close()
                        }
                    }
                    line.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
                }
                col.addView(line)
                rows.add(line)
                i += 3
            }
            sv.addView(col)
            panel.addView(sv, LinearLayout.LayoutParams(-1, -2))
        }
    }

    fun input(act: Activity, title: String, current: String, anchor: View?, onSave: (String) -> Unit) {
        val acc = accent(act)
        present(act, anchor, null) { panel, rows, h ->
            panel.addView(titleView(act, title))
            val et = EditText(act).apply {
                setText(current)
                setSingleLine()
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                textSize = 17f
                background = GradientDrawable().apply {
                    cornerRadius = dp(act, 14).toFloat()
                    setColor(Color.argb(60, 255, 255, 255))
                }
                setPadding(dp(act, 16), dp(act, 12), dp(act, 16), dp(act, 12))
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(dp(act, 22), dp(act, 4), dp(act, 22), dp(act, 8))
            panel.addView(et, lp)
            rows.add(et)
            val btns = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(dp(act, 14), dp(act, 4), dp(act, 14), 0)
            }
            fun btn(label: String, primary: Boolean, click: () -> Unit) = TextView(act).apply {
                text = label
                textSize = 16f
                setTextColor(if (primary) acc else Color.WHITE)
                setPadding(dp(act, 16), dp(act, 12), dp(act, 16), dp(act, 12))
                setOnClickListener { click() }
            }
            btns.addView(btn("Cancel", false) { h.close() })
            btns.addView(btn("Save", true) {
                onSave(et.text.toString().trim())
                h.close()
            })
            panel.addView(btns)
        }
    }
}
