package com.oxycam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Software stabilisation for the photo viewfinder at high zoom (phones without OIS / driver stabilisation).
 *
 * The gyroscope tells how far the phone has turned; the viewfinder is nudged the opposite way by the matching number
 * of pixels. A slow wash-out lets deliberate pans through, so only the fast hand tremor is cancelled. The gyro stream
 * is delayed by [LATENCY_NS] to line up with the camera frame that is on screen at that moment. The preview is
 * enlarged a little ([SCALE]) so its edges never show while it moves.
 *
 * [speed] (smoothed angular speed in rad/s) is also used to wait for a calm moment before the shutter fires.
 * Portrait only, which is how the app is locked.
 */
class SoftStab(ctx: Context) : SensorEventListener {

    companion object {
        private const val LATENCY_NS = 60_000_000L
        private const val WASHOUT_S = 0.6f
        private const val SCALE = 1.05f
    }

    private class Sample(val t: Long, val yaw: Float, val pitch: Float)

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val queue = ArrayDeque<Sample>()

    private var target: View? = null
    private var lastT = 0L
    private var offX = 0f
    private var offY = 0f

    var running = false
        private set

    /** Focal length expressed in viewfinder pixels at the current zoom (pixels of image shift per radian turned). */
    @Volatile var pxPerRad = 1000f

    /** Smoothed angular speed in rad/s. */
    @Volatile var speed = 0f
        private set

    fun start(view: View): Boolean {
        if (running) return true
        val g = gyro ?: return false
        target = view
        queue.clear()
        lastT = 0L
        offX = 0f
        offY = 0f
        speed = 0f
        running = sm.registerListener(this, g, SensorManager.SENSOR_DELAY_GAME, Handler(Looper.getMainLooper()))
        if (running) {
            view.scaleX = SCALE
            view.scaleY = SCALE
        }
        return running
    }

    fun stop() {
        if (!running) return
        running = false
        sm.unregisterListener(this)
        target?.let {
            it.translationX = 0f
            it.translationY = 0f
            it.scaleX = 1f
            it.scaleY = 1f
        }
        target = null
        queue.clear()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val v = target ?: return
        val wx = e.values[0] // turning about the phone's horizontal axis (tilt up / down)
        val wy = e.values[1] // turning about the phone's vertical axis (pan left / right)
        val wz = e.values[2]
        speed = speed * 0.9f + 0.1f * sqrt(wx * wx + wy * wy + wz * wz)
        queue.addLast(Sample(e.timestamp, wy, wx))

        var changed = false
        while (queue.isNotEmpty() && queue.first().t <= e.timestamp - LATENCY_NS) {
            val s = queue.removeFirst()
            val dt = if (lastT == 0L) 0f else ((s.t - lastT) / 1e9f).coerceIn(0f, 0.05f)
            lastT = s.t
            val k = exp(-dt / WASHOUT_S)
            // scene moves one way when the phone turns the other way: shift the view against it
            offX = (offX - pxPerRad * s.yaw * dt) * k
            offY = (offY - pxPerRad * s.pitch * dt) * k
            changed = true
        }
        if (changed) {
            val mx = v.width * (SCALE - 1f) / 2f * 0.9f
            val my = v.height * (SCALE - 1f) / 2f * 0.9f
            offX = offX.coerceIn(-mx, mx)
            offY = offY.coerceIn(-my, my)
            v.translationX = offX
            v.translationY = offY
        }
    }
}
