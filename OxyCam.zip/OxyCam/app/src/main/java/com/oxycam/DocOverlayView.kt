package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

/** Draws the detected document outline over the viewfinder, gliding smoothly from frame to frame. */
class DocOverlayView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private var target: FloatArray? = null
    private var shown: FloatArray? = null

    /** True for the front camera, whose viewfinder is mirrored. */
    var mirror = false

    private val d = ctx.resources.displayMetrics.density
    private val yellow = Color.parseColor("#FFCC00")
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(55, 255, 204, 0)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
        strokeJoin = Paint.Join.ROUND
        color = yellow
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        textSize = 14f * d
        isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()

    /** [q]: TL, TR, BR, BL as x,y in 0..1 of the viewfinder, or null when no document is in view. */
    fun setQuad(q: FloatArray?) {
        target = q?.copyOf()
        if (q == null) shown = null
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val t = target
        if (t == null) {
            c.drawText("Point the camera at a document", width / 2f, height * 0.14f, txt)
            return
        }
        val first = shown == null
        val s = shown ?: t.copyOf().also { shown = it }
        if (!first) {
            var moving = false
            for (i in 0 until 8) {
                val delta = t[i] - s[i]
                s[i] = s[i] + delta * 0.35f
                if (abs(delta) > 0.001f) moving = true
            }
            if (moving) postInvalidateOnAnimation()
        }
        path.reset()
        for (k in 0 until 4) {
            val u = s[k * 2]
            val v = s[k * 2 + 1]
            val x = (if (mirror) 1f - u else u) * width
            val y = v * height
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, fill)
        c.drawPath(path, line)
        for (k in 0 until 4) {
            val u = s[k * 2]
            val x = (if (mirror) 1f - u else u) * width
            c.drawCircle(x, s[k * 2 + 1] * height, 5f * d, dot)
        }
    }
}
