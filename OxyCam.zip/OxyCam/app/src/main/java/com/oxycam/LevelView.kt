package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2

class LevelView(context: Context, attrs: AttributeSet?) : View(context, attrs), SensorEventListener {
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var tilt = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }

    fun start() {
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
    }

    fun stop() {
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        tilt = Math.toDegrees(atan2(e.values[0].toDouble(), e.values[1].toDouble())).toFloat()
        invalidate()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val len = width * 0.45f
        val level = abs(tilt) < 1.2f
        // fixed reference marks
        p.color = Color.argb(160, 255, 255, 255)
        canvas.drawLine(cx - len - 30f, cy, cx - len - 8f, cy, p)
        canvas.drawLine(cx + len + 8f, cy, cx + len + 30f, cy, p)
        // moving horizon line
        p.color = if (level) Color.parseColor("#FFCC00") else Color.WHITE
        canvas.save()
        canvas.rotate(-tilt, cx, cy)
        canvas.drawLine(cx - len, cy, cx + len, cy, p)
        canvas.restore()
    }
}
