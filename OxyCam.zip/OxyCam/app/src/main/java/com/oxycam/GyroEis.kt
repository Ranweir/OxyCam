package com.oxycam

import android.content.Context
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import androidx.media3.effect.MatrixTransformation
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Gyro EIS++ : gyroscope based electronic stabilisation.
 *
 * While you record, the phone's gyroscope is logged together with the exact capture time of every camera frame.
 * When recording stops, the camera path is rebuilt from the gyro, smoothed (looking both backwards and forwards in
 * time, which a live stabiliser cannot do) and every frame is warped back onto the smooth path with a small crop.
 * The warped video is then exported, so the stabilised clip appears a moment after you press stop.
 *
 * Corrects rotation shake (pan / tilt / roll). It does not correct walking "bob" (camera translation) and does not
 * model rolling shutter wobble.
 */
class GyroEis(ctx: Context) {

    /** Everything recorded during one clip. */
    class Log(
        val gt: LongArray, val gx: FloatArray, val gy: FloatArray, val gz: FloatArray, val n: Int,
        val frameTs: LongArray, val centerOffNs: Long, val startNs: Long,
        val focalMm: Float, val zoom: Float, val sensorWidthMm: Float, val front: Boolean
    )

    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private var thread: HandlerThread? = null

    val hasGyro: Boolean get() = gyro != null

    private val lock = Any()
    @Volatile private var active = false
    private var gt = LongArray(8192)
    private var gx = FloatArray(8192)
    private var gy = FloatArray(8192)
    private var gz = FloatArray(8192)
    private var gn = 0
    private var ft = LongArray(2048)
    private var fn = 0
    private var centerSumNs = 0L
    private var centerCount = 0
    private var startNs = 0L
    private var focalMm = 0f
    private var zoom = 1f
    private var activeW = 0
    private var sensorWidthMm = 0f
    private var front = false

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (!active) return
            synchronized(lock) {
                if (gn >= MAX_GYRO_SAMPLES) return
                if (gn == gt.size) {
                    val c = gn * 2
                    gt = gt.copyOf(c); gx = gx.copyOf(c); gy = gy.copyOf(c); gz = gz.copyOf(c)
                }
                gt[gn] = e.timestamp
                gx[gn] = e.values[0]
                gy[gn] = e.values[1]
                gz[gn] = e.values[2]
                gn++
            }
        }

        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
    }

    /** Attach this to the video use case. It records when each camera frame was exposed. */
    val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            if (!active) return
            val ts = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L
            val skew = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW) ?: 0L
            synchronized(lock) {
                if (fn == ft.size) ft = ft.copyOf(fn * 2)
                ft[fn++] = ts
                // SENSOR_TIMESTAMP is the start of exposure of the first row; the middle of the frame is later.
                centerSumNs += exp / 2 + skew / 2
                centerCount++
                if (focalMm <= 0f) {
                    result.get(CaptureResult.LENS_FOCAL_LENGTH)?.let { focalMm = it }
                    val crop = result.get(CaptureResult.SCALER_CROP_REGION)
                    if (crop != null && crop.width() > 0 && activeW > 0) zoom = max(1f, activeW.toFloat() / crop.width())
                }
            }
        }
    }

    /** Begin logging. Call right before the recording is started. */
    fun start(frontCamera: Boolean, sensorWidthMm: Float, activeArrayWidth: Int) {
        val g = gyro ?: return
        synchronized(lock) {
            gn = 0; fn = 0; centerSumNs = 0L; centerCount = 0
            focalMm = 0f; zoom = 1f
            front = frontCamera
            this.sensorWidthMm = sensorWidthMm
            activeW = activeArrayWidth
            startNs = SystemClock.elapsedRealtimeNanos()
        }
        val t = thread ?: HandlerThread("oxycam-gyro").also { it.start(); thread = it }
        active = true
        // SENSOR_DELAY_FASTEST gives the highest rate the phone allows (needs HIGH_SAMPLING_RATE_SENSORS on Android 12+)
        sm.registerListener(listener, g, SensorManager.SENSOR_DELAY_FASTEST, Handler(t.looper))
    }

    /** Stop logging and return what was recorded (null if nothing usable). */
    fun stop(): Log? {
        if (!active) return null
        active = false
        sm.unregisterListener(listener)
        return synchronized(lock) {
            if (gn < 20 || fn < 5) null
            else Log(
                gt.copyOf(gn), gx.copyOf(gn), gy.copyOf(gn), gz.copyOf(gn), gn,
                ft.copyOf(fn), if (centerCount > 0) centerSumNs / centerCount else 0L, startNs,
                focalMm, zoom, sensorWidthMm, front
            )
        }
    }

    fun release() {
        active = false
        try { sm.unregisterListener(listener) } catch (t: Throwable) { }
        thread?.quitSafely()
        thread = null
    }

    /** Per-frame correction for one clip. */
    class Plan(
        private val relUs: LongArray,
        private val tx: FloatArray, private val ty: FloatArray, private val roll: FloatArray,
        private val aspect: Float, val bitrate: Int
    ) {
        fun matrixAt(presentationTimeUs: Long): Matrix {
            val n = relUs.size
            if (n == 0) return Matrix()
            var lo = 0
            var hi = n - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) ushr 1
                if (relUs[mid] <= presentationTimeUs) lo = mid else hi = mid - 1
            }
            val a = lo
            val b = min(a + 1, n - 1)
            val f = if (b == a || presentationTimeUs <= relUs[a]) 0f
            else ((presentationTimeUs - relUs[a]).toFloat() / (relUs[b] - relUs[a]).toFloat()).coerceIn(0f, 1f)
            return buildMatrix(
                tx[a] + (tx[b] - tx[a]) * f,
                ty[a] + (ty[b] - ty[a]) * f,
                roll[a] + (roll[b] - roll[a]) * f,
                aspect, CROP
            )
        }

        /** The effect handed to the video exporter. */
        fun effect(): MatrixTransformation = object : MatrixTransformation {
            override fun getMatrix(presentationTimeUs: Long): Matrix = matrixAt(presentationTimeUs)
        }
    }

    companion object {
        private const val MAX_GYRO_SAMPLES = 1_500_000
        /** Digital crop that gives the stabiliser room to move (1.15 = 15% zoom). */
        const val CROP = 1.15f
        /** Smoothing strength: standard deviation of the smoothing window, in seconds. */
        private const val SIGMA_S = 0.30

        /**
         * The picture is drawn in normalised device coordinates (-1..1 on both axes), so a rotation has to be
         * done in an aspect-corrected space or it would shear. tx / ty are in the same normalised units.
         */
        private fun buildMatrix(tx: Float, ty: Float, rollRad: Float, aspect: Float, z: Float): Matrix {
            val m = Matrix()
            m.postScale(aspect, 1f)
            m.postRotate(Math.toDegrees(rollRad.toDouble()).toFloat())
            m.postTranslate(tx * aspect, ty)
            m.postScale(z, z)
            m.postScale(1f / aspect, 1f)
            return m
        }

        /** True if the warped picture still fills the whole frame (no black edges). */
        private fun covers(tx: Float, ty: Float, roll: Float, aspect: Float): Boolean {
            val inv = Matrix()
            if (!buildMatrix(tx, ty, roll, aspect, CROP).invert(inv)) return false
            val p = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, 1f)
            inv.mapPoints(p)
            for (v in p) if (abs(v) > 1.0005f) return false
            return true
        }

        // ---- quaternion helpers: q = [w, x, y, z] ----

        private fun mul(a: DoubleArray, b: DoubleArray, out: DoubleArray) {
            val w = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
            val x = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2]
            val y = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1]
            val z = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
            out[0] = w; out[1] = x; out[2] = y; out[3] = z
        }

        private fun normalize(q: DoubleArray) {
            val l = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
            if (l > 1e-12) { q[0] /= l; q[1] /= l; q[2] /= l; q[3] /= l }
        }

        /**
         * Builds the stabilisation plan for a finished clip. Slow: call it from a background thread.
         * Returns null if the clip cannot be matched to the gyro log.
         */
        fun buildPlan(ctx: Context, src: Uri, log: Log): Plan? {
            // ---- 1. frame times and size of the recorded video ----
            val ex = MediaExtractor()
            val times = ArrayList<Long>()
            var vw = 0
            var vh = 0
            var srcBitrate = 0
            try {
                ex.setDataSource(ctx, src, null)
                var track = -1
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) {
                        track = i
                        vw = f.getInteger(MediaFormat.KEY_WIDTH)
                        vh = f.getInteger(MediaFormat.KEY_HEIGHT)
                        val rot = if (f.containsKey(MediaFormat.KEY_ROTATION)) f.getInteger(MediaFormat.KEY_ROTATION) else 0
                        if (rot == 90 || rot == 270) { val t = vw; vw = vh; vh = t }
                        if (f.containsKey(MediaFormat.KEY_BIT_RATE)) srcBitrate = f.getInteger(MediaFormat.KEY_BIT_RATE)
                        break
                    }
                }
                if (track < 0 || vw <= 0 || vh <= 0) return null
                ex.selectTrack(track)
                while (true) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    times.add(t)
                    if (!ex.advance()) break
                }
            } finally {
                ex.release()
            }
            if (times.size < 5) return null
            times.sort()
            val p0 = times[0]
            val nf = times.size
            val rel = LongArray(nf) { times[it] - p0 }

            // ---- 2. which camera frame is the first frame of the video ----
            var first = -1
            for (i in log.frameTs.indices) if (log.frameTs[i] >= log.startNs) { first = i; break }
            if (first < 0) return null
            val tsFirst = log.frameTs[first]
            // time of each video frame's middle, in the gyro clock, in seconds
            val tf = DoubleArray(nf) { (tsFirst + rel[it] * 1000L + log.centerOffNs) * 1e-9 }

            // ---- 3. camera orientation from the gyro ----
            val n = log.n
            val qw = DoubleArray(n)
            val qx = DoubleArray(n)
            val qy = DoubleArray(n)
            val qz = DoubleArray(n)
            qw[0] = 1.0
            val cur = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
            val d = DoubleArray(4)
            for (i in 1 until n) {
                val dt = min((log.gt[i] - log.gt[i - 1]) * 1e-9, 0.05)
                val wx = (log.gx[i] + log.gx[i - 1]) * 0.5
                val wy = (log.gy[i] + log.gy[i - 1]) * 0.5
                val wz = (log.gz[i] + log.gz[i - 1]) * 0.5
                val mag = sqrt(wx * wx + wy * wy + wz * wz)
                val ang = mag * dt
                if (mag > 1e-9 && dt > 0) {
                    val s = sin(ang / 2) / mag
                    d[0] = cos(ang / 2); d[1] = wx * s; d[2] = wy * s; d[3] = wz * s
                    mul(cur, d, cur)
                    normalize(cur)
                }
                qw[i] = cur[0]; qx[i] = cur[1]; qy[i] = cur[2]; qz[i] = cur[3]
            }

            // pose at each video frame (normalised linear interpolation between gyro samples)
            val fw = DoubleArray(nf)
            val fx = DoubleArray(nf)
            val fy = DoubleArray(nf)
            val fz = DoubleArray(nf)
            var gi = 0
            for (k in 0 until nf) {
                val tns = tf[k] * 1e9
                while (gi < n - 2 && log.gt[gi + 1] <= tns) gi++
                val t0 = log.gt[gi].toDouble()
                val t1 = log.gt[min(gi + 1, n - 1)].toDouble()
                val a = if (t1 > t0) ((tns - t0) / (t1 - t0)).coerceIn(0.0, 1.0) else 0.0
                val j = min(gi + 1, n - 1)
                val sgn = if (qw[gi] * qw[j] + qx[gi] * qx[j] + qy[gi] * qy[j] + qz[gi] * qz[j] < 0) -1.0 else 1.0
                val q = doubleArrayOf(
                    qw[gi] * (1 - a) + sgn * qw[j] * a, qx[gi] * (1 - a) + sgn * qx[j] * a,
                    qy[gi] * (1 - a) + sgn * qy[j] * a, qz[gi] * (1 - a) + sgn * qz[j] * a
                )
                normalize(q)
                fw[k] = q[0]; fx[k] = q[1]; fy[k] = q[2]; fz[k] = q[3]
            }

            // ---- 4. focal length in pixels ----
            val longSide = max(vw, vh).toDouble()
            val fPx = if (log.focalMm > 0f && log.sensorWidthMm > 0f)
                log.focalMm / log.sensorWidthMm * longSide * log.zoom
            else longSide / (2.0 * tan(Math.toRadians(35.0))) * log.zoom
            val aspect = vw.toFloat() / vh.toFloat()

            // ---- 5. smooth path + per-frame correction ----
            val tx = FloatArray(nf)
            val ty = FloatArray(nf)
            val roll = FloatArray(nf)
            val radius = SIGMA_S * 3
            val conj = DoubleArray(4)
            val r = DoubleArray(4)
            val qm = DoubleArray(4)
            var lo = 0
            for (k in 0 until nf) {
                while (lo < k && tf[k] - tf[lo] > radius) lo++
                conj[0] = fw[k]; conj[1] = -fx[k]; conj[2] = -fy[k]; conj[3] = -fz[k]
                var sx = 0.0
                var sy = 0.0
                var sz = 0.0
                var sw = 0.0
                var m = lo
                while (m < nf && tf[m] - tf[k] <= radius) {
                    val dt = tf[m] - tf[k]
                    val w = exp(-dt * dt / (2 * SIGMA_S * SIGMA_S))
                    qm[0] = fw[m]; qm[1] = fx[m]; qm[2] = fy[m]; qm[3] = fz[m]
                    mul(conj, qm, r) // rotation from the real camera at k to the camera at m, in camera axes
                    if (r[0] < 0) { r[0] = -r[0]; r[1] = -r[1]; r[2] = -r[2]; r[3] = -r[3] }
                    val s = sqrt(r[1] * r[1] + r[2] * r[2] + r[3] * r[3])
                    val k2 = if (s < 1e-12) 2.0 else 2.0 * atan2(s, r[0]) / s
                    sx += w * r[1] * k2
                    sy += w * r[2] * k2
                    sz += w * r[3] * k2
                    sw += w
                    m++
                }
                if (sw <= 0) continue
                val bx = sx / sw // where the smooth camera is, relative to the real camera: rotation vector in device axes
                val by = sy / sw
                val bz = sz / sw

                // device axes (x right, y up, z towards you, phone upright) -> picture axes (right, up, towards viewer)
                val ar = if (log.front) -bx else bx
                val au = by
                val ab = if (log.front) -bz else bz

                // Turning the camera by (ar, au, ab) moves the scene by (+f*au, -f*ar) and turns it by -ab.
                // Moving the picture the same way gives the view of the smooth camera.
                val ptx = (fPx * au / (vw / 2.0)).toFloat()
                val pty = (-fPx * ar / (vh / 2.0)).toFloat()
                val prl = (-ab).toFloat()
                // never let the correction pull in black edges: scale it down until the crop covers the frame
                var scale = 1f
                var tries = 0
                while (tries < 12 && !covers(ptx * scale, pty * scale, prl * scale, aspect)) {
                    scale *= 0.85f
                    tries++
                }
                if (tries >= 12) scale = 0f
                tx[k] = ptx * scale
                ty[k] = pty * scale
                roll[k] = prl * scale
            }

            var br = srcBitrate
            if (br <= 0) {
                val durS = max(0.1, (rel[nf - 1] / 1e6))
                val fps = nf / durS
                br = (vw.toDouble() * vh * fps * 0.12).toInt()
            }
            br = br.coerceIn(4_000_000, 100_000_000)
            return Plan(rel, tx, ty, roll, aspect, br)
        }
    }
}
