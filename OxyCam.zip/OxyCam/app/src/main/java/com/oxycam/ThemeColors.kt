package com.oxycam

import android.content.Context
import android.graphics.Color
import android.os.Build

/** Accent colours for the camera UI. Index is stored in the "theme" preference. */
object ThemeColors {
    val names = listOf(
        "OnePlus red", "Classic amber", "Minimal white", "Material You",
        "Ocean blue", "Sky cyan", "Emerald green", "Lime", "Sunset orange",
        "Rose pink", "Violet", "Magenta", "Gold", "Coral", "Custom colour"
    )
    const val CUSTOM = 14
    private const val AMBER = "#FFCC00"

    private val fixed = mapOf(
        0 to "#EB0028", 1 to AMBER, 2 to "#FFFFFF",
        4 to "#2F80FF", 5 to "#18D4E8", 6 to "#00C46A", 7 to "#B4E600", 8 to "#FF7A00",
        9 to "#FF4F8B", 10 to "#8F5BFF", 11 to "#E83DDC", 12 to "#F5B700", 13 to "#FF6B5E"
    )

    fun colorFor(ctx: Context, idx: Int): Int {
        val amber = Color.parseColor(AMBER)
        return when (idx) {
            3 -> if (Build.VERSION.SDK_INT >= 31) ctx.resources.getColor(android.R.color.system_accent1_300, ctx.theme) else amber
            CUSTOM -> {
                val p = ctx.getSharedPreferences("oxycam", Context.MODE_PRIVATE)
                val raw = p.getString("themehex", "").orEmpty().trim()
                try {
                    Color.parseColor(if (raw.startsWith("#")) raw else "#$raw")
                } catch (e: Exception) {
                    Color.parseColor("#FF5722")
                }
            }
            else -> fixed[idx]?.let { Color.parseColor(it) } ?: amber
        }
    }

    fun color(ctx: Context): Int =
        colorFor(ctx, ctx.getSharedPreferences("oxycam", Context.MODE_PRIVATE).getInt("theme", 1))
}
