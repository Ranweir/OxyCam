package com.oxycam

/**
 * HDR video helper. It talks to CameraX through reflection so the app still builds and runs when a CameraX
 * version does not have these classes; in that case nothing is reported as supported.
 */
object HdrVideo {
    private const val DR = "androidx.camera.core.DynamicRange"

    /** Best first. HDR10+ is what we want; HDR10 and HLG are used only if the camera offers nothing better. */
    private val prefer = listOf("HDR10_PLUS_10_BIT", "HDR10_10_BIT", "HLG_10_BIT")

    private fun constant(name: String): Any? = try {
        Class.forName(DR).getField(name).get(null)
    } catch (t: Throwable) {
        null
    }

    private fun recorderSupports(cameraInfo: Any): Set<*>? = try {
        val infoCls = Class.forName("androidx.camera.core.CameraInfo")
        val rec = Class.forName("androidx.camera.video.Recorder")
        val vc = rec.getMethod("getVideoCapabilities", infoCls).invoke(null, cameraInfo)
        val vcCls = Class.forName("androidx.camera.video.VideoCapabilities")
        vcCls.getMethod("getSupportedDynamicRanges").invoke(vc) as? Set<*>
    } catch (t: Throwable) {
        null
    }

    /** Returns (constant name, DynamicRange object) of the best HDR format this camera can record, or null. */
    fun pick(cameraInfo: Any): Pair<String, Any>? {
        try {
            val infoCls = Class.forName("androidx.camera.core.CameraInfo")
            val query = infoCls.getMethod("querySupportedDynamicRanges", java.util.Set::class.java)
            val cands = prefer.mapNotNull { n -> constant(n)?.let { n to it } }
            if (cands.isEmpty()) return null
            val cameraSet = query.invoke(cameraInfo, cands.map { it.second }.toSet()) as? Set<*> ?: return null
            val recSet = recorderSupports(cameraInfo)
            for ((n, o) in cands) {
                if (cameraSet.contains(o) && (recSet == null || recSet.contains(o))) return n to o
            }
        } catch (t: Throwable) { }
        return null
    }

    /** Sets the dynamic range on a Preview.Builder / VideoCapture.Builder. */
    fun apply(builder: Any, range: Any) {
        try {
            val cls = Class.forName(DR)
            builder.javaClass.getMethod("setDynamicRange", cls).invoke(builder, range)
        } catch (t: Throwable) { }
    }
}
