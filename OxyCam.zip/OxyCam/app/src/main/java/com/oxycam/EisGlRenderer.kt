package com.oxycam

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.util.concurrent.Executor

/**
 * OpenGL ES renderer. Receives camera frames (as an external texture), warps + sharpens them and draws the same
 * result into every output surface CameraX gives us (preview and video encoder).
 * Everything here runs on one dedicated GL thread.
 */
class EisGlRenderer(private val processor: EisProcessor) {
    private val thread = HandlerThread("eis-gl").also { it.start() }
    val handler = Handler(thread.looper)
    val executor = Executor { r -> handler.post(r) }

    @Volatile var sharpness = 0.65f
    /** 2 = send every second frame to the encoder (sensor runs 60 fps, video is 30 fps). */
    @Volatile var videoDecimation = 1

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aUv = 0
    private var uTexMat = 0
    private var uOutT = 0
    private var uRv = 0
    private var uInvF = 0
    private var uCrop = 0
    private var uPix = 0
    private var uSharp = 0
    private var texId = 0
    private var st: SurfaceTexture? = null
    private var inSurface: Surface? = null
    private var bufW = 0
    private var bufH = 0
    private var frameNo = 0L
    private var released = false

    private val texMat = FloatArray(16)
    private val inv = FloatArray(16)
    private val rv = FloatArray((EisProcessor.STRIPS + 1) * 3)
    private val invF = FloatArray(2)

    private class Out(val out: SurfaceOutput, val surface: Surface, val egl: EGLSurface, val size: Size, val video: Boolean) {
        val updated = FloatArray(16)
        val t = FloatArray(16)
    }

    private val outs = ArrayList<Out>()

    private lateinit var vertexBuf: FloatBuffer
    private lateinit var indexBuf: ShortBuffer
    private var indexCount = 0

    // ---------------- setup ----------------

    private fun ensureGl() {
        if (display != EGL14.EGL_NO_DISPLAY) return
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "eglInitialize failed" }
        val attribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0)
        config = configs[0]
        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        pbuffer = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)

        program = buildProgram(EisShaders.VERTEX, EisShaders.FRAGMENT)
        aUv = GLES20.glGetAttribLocation(program, "aUv")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")
        uOutT = GLES20.glGetUniformLocation(program, "uOutT")
        uRv = GLES20.glGetUniformLocation(program, "uRv[0]")
        if (uRv < 0) uRv = GLES20.glGetUniformLocation(program, "uRv")
        uInvF = GLES20.glGetUniformLocation(program, "uInvF")
        uCrop = GLES20.glGetUniformLocation(program, "uCrop")
        uPix = GLES20.glGetUniformLocation(program, "uPix")
        uSharp = GLES20.glGetUniformLocation(program, "uSharp")
        buildMesh()
    }

    private fun buildMesh() {
        val n = EisProcessor.STRIPS + 1
        val v = FloatArray(n * n * 2)
        var k = 0
        for (j in 0 until n) for (i in 0 until n) {
            v[k++] = i / (n - 1f)
            v[k++] = j / (n - 1f)
        }
        vertexBuf = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(v); it.position(0)
        }
        val idx = ShortArray((n - 1) * (n - 1) * 6)
        k = 0
        for (j in 0 until n - 1) for (i in 0 until n - 1) {
            val a = (j * n + i).toShort()
            val b = (j * n + i + 1).toShort()
            val c = ((j + 1) * n + i).toShort()
            val d = ((j + 1) * n + i + 1).toShort()
            idx[k++] = a; idx[k++] = b; idx[k++] = c
            idx[k++] = b; idx[k++] = d; idx[k++] = c
        }
        indexCount = idx.size
        indexBuf = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().also {
            it.put(idx); it.position(0)
        }
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { "shader error: " + GLES20.glGetShaderInfoLog(s) }
        return s
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { "link error: " + GLES20.glGetProgramInfoLog(p) }
        return p
    }

    // ---------------- CameraX hooks ----------------

    fun attachInput(request: SurfaceRequest) {
        if (released) {
            request.willNotProvideSurface()
            return
        }
        ensureGl()
        bufW = request.resolution.width
        bufH = request.resolution.height
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        texId = tex[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val tex2 = SurfaceTexture(texId)
        tex2.setDefaultBufferSize(bufW, bufH)
        tex2.setOnFrameAvailableListener({ onFrame() }, handler)
        val surface = Surface(tex2)
        st = tex2
        inSurface = surface
        processor.reset()
        request.provideSurface(surface, executor) {
            tex2.setOnFrameAvailableListener(null)
            surface.release()
            tex2.release()
            if (st === tex2) { st = null; inSurface = null }
        }
    }

    fun attachOutput(output: SurfaceOutput) {
        if (released) {
            output.close()
            return
        }
        ensureGl()
        val surface = output.getSurface(executor) { event ->
            if (event.eventCode == SurfaceOutput.Event.EVENT_REQUEST_CLOSE) {
                removeOutput(output)
            }
        }
        val egl = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
        val video = (output.targets and CameraEffect.VIDEO_CAPTURE) != 0
        outs.add(Out(output, surface, egl, output.size, video))
    }

    private fun removeOutput(output: SurfaceOutput) {
        val it = outs.iterator()
        while (it.hasNext()) {
            val o = it.next()
            if (o.out === output) {
                it.remove()
                try {
                    EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                    EGL14.eglDestroySurface(display, o.egl)
                } catch (t: Throwable) { }
            }
        }
        output.close()
    }

    // ---------------- per frame ----------------

    private fun onFrame() {
        val tex = st ?: return
        if (released || outs.isEmpty()) {
            try { EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context); tex.updateTexImage() } catch (t: Throwable) { }
            return
        }
        try {
            EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
            tex.updateTexImage()
            tex.getTransformMatrix(texMat)
            val ts = tex.timestamp
            frameNo++
            Matrix.invertM(inv, 0, texMat, 0)
            val ts4 = ArrayList<FloatArray>(outs.size)
            for (o in outs) {
                o.out.updateTransformMatrix(o.updated, texMat)
                Matrix.multiplyMM(o.t, 0, inv, 0, o.updated, 0)   // T = original^-1 * updated
                ts4.add(o.t)
            }
            processor.update(ts, SystemClock.elapsedRealtimeNanos(), bufW, bufH, ts4, rv)
            processor.invFocal(bufW, bufH, invF)
            val dec = videoDecimation
            for (o in outs) {
                if (o.video && dec > 1 && frameNo % dec != 0L) continue
                draw(o, ts)
            }
        } catch (t: Throwable) {
            // keep going; a single bad frame must not kill recording
        }
    }

    private fun draw(o: Out, ts: Long) {
        if (!EGL14.eglMakeCurrent(display, o.egl, o.egl, context)) return
        GLES20.glViewport(0, 0, o.size.width, o.size.height)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glUniformMatrix4fv(uTexMat, 1, false, texMat, 0)
        GLES20.glUniformMatrix4fv(uOutT, 1, false, o.t, 0)
        GLES20.glUniform3fv(uRv, EisProcessor.STRIPS + 1, rv, 0)
        GLES20.glUniform2f(uInvF, invF[0], invF[1])
        GLES20.glUniform1f(uCrop, EisProcessor.CROP.toFloat())
        GLES20.glUniform2f(uPix, 1f / o.size.width, 1f / o.size.height)
        GLES20.glUniform1f(uSharp, sharpness)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, vertexBuf)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuf)
        GLES20.glDisableVertexAttribArray(aUv)
        EGLExt.eglPresentationTimeANDROID(display, o.egl, ts)
        EGL14.eglSwapBuffers(display, o.egl)
    }

    fun release() {
        handler.post {
            released = true
            try {
                for (o in outs) {
                    try { EGL14.eglDestroySurface(display, o.egl) } catch (t: Throwable) { }
                    try { o.out.close() } catch (t: Throwable) { }
                }
                outs.clear()
                if (display != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    if (pbuffer != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, pbuffer)
                    if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
                    EGL14.eglTerminate(display)
                }
            } catch (t: Throwable) { }
            display = EGL14.EGL_NO_DISPLAY
            thread.quitSafely()
        }
    }
}
