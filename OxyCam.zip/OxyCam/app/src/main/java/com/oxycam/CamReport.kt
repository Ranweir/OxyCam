package com.oxycam

import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.CamcorderProfile
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import android.util.Size

/** Plain-text report of what the phone's camera driver really offers apps (video frame rates, sizes, limits). */
object CamReport {
    private fun fpsOf(durNs: Long): String = if (durNs <= 0L) "n/a" else String.format("%.0f fps", 1e9 / durNs)

    fun build(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_BACK -> "back"
                    CameraCharacteristics.LENS_FACING_FRONT -> "front"
                    else -> "other"
                }
                val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?"
                }
                sb.append("\n== Camera $id ($facing), hardware level $level ==\n")
                val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                sb.append("AE fps ranges: ").append(ranges?.joinToString(" ") { "[${it.lower}-${it.upper}]" } ?: "n/a").append("\n")
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                if (map != null) {
                    for (size in listOf(Size(3840, 2160), Size(1920, 1080), Size(1280, 720))) {
                        val has = map.getOutputSizes(MediaRecorder::class.java)?.any { it.width == size.width && it.height == size.height } == true
                        sb.append("${size.width}x${size.height}: ")
                        if (!has) {
                            sb.append("not offered for video recording\n")
                            continue
                        }
                        val parts = ArrayList<String>()
                        try { parts.add("recorder " + fpsOf(map.getOutputMinFrameDuration(MediaRecorder::class.java, size))) } catch (t: Throwable) { }
                        try { parts.add("texture " + fpsOf(map.getOutputMinFrameDuration(SurfaceTexture::class.java, size))) } catch (t: Throwable) { }
                        try { parts.add("yuv " + fpsOf(map.getOutputMinFrameDuration(ImageFormat.YUV_420_888, size))) } catch (t: Throwable) { }
                        sb.append("max ").append(parts.joinToString(", ")).append("\n")
                    }
                    try {
                        val hs = map.highSpeedVideoSizes
                        if (hs != null && hs.isNotEmpty()) {
                            sb.append("High-speed video: ")
                            sb.append(hs.joinToString("; ") { s -> "${s.width}x${s.height} " + map.getHighSpeedVideoFpsRangesFor(s).joinToString(",") { "${it.lower}-${it.upper}" } })
                            sb.append("\n")
                        } else sb.append("High-speed video: none\n")
                    } catch (t: Throwable) { }
                }
                val camId = id.toIntOrNull()
                if (camId != null) {
                    val names = listOf(
                        "2160p" to CamcorderProfile.QUALITY_2160P, "1080p" to CamcorderProfile.QUALITY_1080P,
                        "720p" to CamcorderProfile.QUALITY_720P,
                        "HS 2160p" to CamcorderProfile.QUALITY_HIGH_SPEED_2160P, "HS 1080p" to CamcorderProfile.QUALITY_HIGH_SPEED_1080P,
                        "HS 720p" to CamcorderProfile.QUALITY_HIGH_SPEED_720P
                    )
                    sb.append("Camcorder profiles: ")
                    sb.append(names.joinToString("; ") { (n, q) ->
                        if (CamcorderProfile.hasProfile(camId, q)) {
                            val p = CamcorderProfile.get(camId, q)
                            "$n=${p.videoFrameWidth}x${p.videoFrameHeight}@${p.videoFrameRate}"
                        } else "$n=none"
                    })
                    sb.append("\n")
                }
            }
        } catch (t: Throwable) {
            sb.append("Camera query failed: ${t.message}\n")
        }
        sb.append("\n== Video encoders at 3840x2160 ==\n")
        try {
            for (mime in listOf("video/avc", "video/hevc")) {
                var best = 0.0
                for (info in MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos) {
                    if (!info.isEncoder || !info.supportedTypes.contains(mime)) continue
                    try {
                        val vc: MediaCodecInfo.VideoCapabilities = info.getCapabilitiesForType(mime).videoCapabilities ?: continue
                        best = maxOf(best, vc.getSupportedFrameRatesFor(3840, 2160).upper)
                    } catch (t: Throwable) { }
                }
                sb.append("$mime: up to ${if (best > 0) String.format("%.0f", best) else "n/a"} fps\n")
            }
        } catch (t: Throwable) {
            sb.append("n/a\n")
        }
        return sb.toString()
    }
}
