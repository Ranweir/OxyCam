package com.oxycam

/** Same camera, opened from the lock screen. MainActivity switches to its "secure" behaviour for this class. */
class SecureCameraActivity : MainActivity()
