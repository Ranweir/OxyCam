package com.oxycam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Wide frosted-glass strip of live filter thumbnails (each shows the viewfinder with that look applied)
 * with the name underneath. Swipe to browse: the filter in the middle is the selected one.
 */
class FilterStrip(ctx: Context) : FrameLayout(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var selected = 0
        private set

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val cellW = dp(80)
    private val n = Filters.names.size
    private val sv = HorizontalScrollView(ctx)
    private val row = LinearLayout(ctx)
    private val backdrop = ImageView(ctx)
    private val thumbs = ArrayList<ImageView>()
    private val borders = ArrayList<View>()
    private val labels = ArrayList<TextView>()
    private var accent = Color.parseColor("#FFCC00")
    private val handler = Handler(Looper.getMainLooper())
    private var touching = false
    private val snap = Runnable {
        if (!touching) sv.smoothScrollTo(selected * cellW, 0)
    }

    init {
        val radius = dp(22).toFloat()
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        backdrop.scaleType = ImageView.ScaleType.FIT_XY
        addView(backdrop, LayoutParams(-1, -1))
        addView(View(ctx).apply { setBackgroundColor(Color.argb(105, 22, 22, 28)) }, LayoutParams(-1, -1))

        sv.isHorizontalScrollBarEnabled = false
        sv.isHorizontalFadingEdgeEnabled = true
        sv.setFadingEdgeLength(dp(40))
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until n) row.addView(makeCell(i), LinearLayout.LayoutParams(cellW, LinearLayout.LayoutParams.WRAP_CONTENT))
        sv.addView(row)
        addView(sv, LayoutParams(-1, -1))
        addView(
            View(ctx).apply {
                background = GradientDrawable().apply {
                    cornerRadius = radius
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(1), Color.argb(90, 255, 255, 255))
                }
            },
            LayoutParams(-1, -1)
        )

        sv.setOnScrollChangeListener { _, x, _, _, _ ->
            val idx = Math.round(x / cellW.toFloat()).coerceIn(0, n - 1)
            if (idx != selected) {
                selected = idx
                updateSelected()
                onSelect?.invoke(idx)
            }
            handler.removeCallbacks(snap)
            handler.postDelayed(snap, 130)
        }
        updateSelected()
    }

    private fun makeCell(i: Int): View {
        val cell = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(12), 0, dp(6))
        }
        val box = FrameLayout(context)
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                }
            }
            setBackgroundColor(Color.argb(60, 255, 255, 255))
            val m = Filters.matrix(i)
            colorFilter = if (m != null) ColorMatrixColorFilter(m) else null
        }
        val border = View(context).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), accent)
            }
            visibility = View.INVISIBLE
        }
        box.addView(iv, FrameLayout.LayoutParams(-1, -1))
        box.addView(border, FrameLayout.LayoutParams(-1, -1))
        cell.addView(box, LinearLayout.LayoutParams(dp(62), dp(62)))
        val label = TextView(context).apply {
            text = Filters.names[i]
            textSize = 10.5f
            maxLines = 2
            gravity = Gravity.CENTER
            setTextColor(Color.argb(220, 255, 255, 255))
            setPadding(dp(4), dp(4), dp(4), 0)
        }
        cell.addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        cell.setOnClickListener {
            if (selected != i) {
                selected = i
                updateSelected()
                onSelect?.invoke(i)
            }
            sv.smoothScrollTo(i * cellW, 0)
        }
        thumbs.add(iv)
        borders.add(border)
        labels.add(label)
        return cell
    }

    private fun updateSelected() {
        for (i in 0 until n) {
            val on = i == selected
            borders[i].visibility = if (on) View.VISIBLE else View.INVISIBLE
            (borders[i].background as GradientDrawable).setStroke(dp(3), accent)
            labels[i].setTextColor(if (on) accent else Color.argb(220, 255, 255, 255))
        }
    }

    fun setSource(b: Bitmap) {
        for (t in thumbs) t.setImageBitmap(b)
    }

    /** New live frame arrived: redraw thumbnails and refresh the blurred glass behind the strip. */
    fun frameUpdated(b: Bitmap, fx0: Float, fy0: Float, fx1: Float, fy1: Float) {
        for (t in thumbs) t.invalidate()
        try {
            val x0 = (fx0 * b.width).toInt().coerceIn(0, b.width - 2)
            val y0 = (fy0 * b.height).toInt().coerceIn(0, b.height - 2)
            val x1 = (fx1 * b.width).toInt().coerceIn(x0 + 1, b.width)
            val y1 = (fy1 * b.height).toInt().coerceIn(y0 + 1, b.height)
            val cw = x1 - x0
            val ch = y1 - y0
            val crop = Bitmap.createBitmap(b, x0, y0, cw, ch)
            val px = IntArray(cw * ch)
            crop.getPixels(px, 0, cw, 0, 0, cw, ch)
            val bl = Processor.boxBlur(px, cw, ch, 2)
            val out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            out.setPixels(bl, 0, cw, 0, 0, cw, ch)
            crop.recycle()
            backdrop.setImageBitmap(out)
        } catch (t: Throwable) { }
    }

    fun show(sel: Int, acc: Int) {
        selected = sel.coerceIn(0, n - 1)
        accent = acc
        updateSelected()
        visibility = View.VISIBLE
        post {
            val pad = ((width - cellW) / 2).coerceAtLeast(0)
            row.setPadding(pad, 0, pad, 0)
            sv.post { sv.scrollTo(selected * cellW, 0) }
        }
    }

    fun hide() {
        handler.removeCallbacks(snap)
        visibility = View.GONE
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> touching = true
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                handler.removeCallbacks(snap)
                handler.postDelayed(snap, 140)
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}
