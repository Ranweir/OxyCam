package com.oxycam

import android.content.Context
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import androidx.core.util.Consumer

/** Hands CameraX's surfaces to the EIS renderer. */
class EisSurfaceProcessor(private val renderer: EisGlRenderer) : SurfaceProcessor {
    override fun onInputSurface(request: SurfaceRequest) {
        renderer.handler.post { renderer.attachInput(request) }
    }

    override fun onOutputSurface(surfaceOutput: SurfaceOutput) {
        renderer.handler.post { renderer.attachOutput(surfaceOutput) }
    }
}

/**
 * CameraX effect = "put my GL renderer between the camera and both the preview and the video encoder".
 * Create with EisEffect.create(), add it to the UseCaseGroup, register [captureCallback] on the Preview builder
 * (Camera2Interop) so the real rolling-shutter skew and exposure of every frame are known, call release() when done.
 */
class EisEffect private constructor(
    private val renderer: EisGlRenderer,
    private val processor: EisProcessor,
    private val gyro: GyroEisBuffer,
    sp: EisSurfaceProcessor
) : CameraEffect(CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE, renderer.executor, sp, Consumer<Throwable> { }) {

    val gyroOk: Boolean

    init {
        gyroOk = gyro.start()
    }

    /** Register on the Preview builder with Camera2Interop.Extender(...).setSessionCaptureCallback(). */
    val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            val ts = result.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
            val skew = result.get(CaptureResult.SENSOR_ROLLING_SHUTTER_SKEW) ?: 0L
            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L
            processor.onCaptureResult(ts, skew, exp)
        }
    }

    fun setZoom(z: Double) { processor.zoom = z }
    fun setSyncOffsetNs(ns: Long) { processor.userOffsetNs = ns }
    fun setSharpness(s: Float) { renderer.sharpness = s }
    fun setVideoDecimation(d: Int, expectedFrameNs: Long) {
        renderer.videoDecimation = d
        processor.expectedFrameNs = expectedFrameNs
    }
    fun setOnFrameDrops(cb: () -> Unit) { processor.onFrameDrops = cb }

    fun release() {
        gyro.stop()
        renderer.release()
    }

    companion object {
        fun create(ctx: Context, useRotationVector: Boolean = false): EisEffect {
            val gyro = GyroEisBuffer(ctx, useRotationVector)
            val cam = EisCamInfo.readBack(ctx)
            val processor = EisProcessor(cam, gyro)
            val renderer = EisGlRenderer(processor)
            return EisEffect(renderer, processor, gyro, EisSurfaceProcessor(renderer))
        }
    }
}
