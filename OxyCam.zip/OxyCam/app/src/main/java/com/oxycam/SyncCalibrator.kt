package com.oxycam

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * Finds how far the gyro clock is shifted against the video clock.
 * It measures how fast the picture moves between frames (optical flow, phase correlation via OpenCV),
 * and slides that curve over the gyro speed curve until they match best.
 */
object SyncCalibrator {
    fun estimateLagNs(ctx: Context, src: Uri, d: GyroData, baseStartNs: Long): Long? {
        if (!MultiFrame.init()) return null
        val mmr = MediaMetadataRetriever()
        val frames = ArrayList<Mat>()
        val times = ArrayList<Long>()
        try {
            mmr.setDataSource(ctx, src)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            val stepUs = 125_000L
            val count = (minOf(durMs, 7000L) * 1000L / stepUs).toInt() - 2
            if (count < 16) return null
            var w = 0
            var h = 0
            for (j in 0 until count) {
                val tUs = 250_000L + j * stepUs
                val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 27) {
                    mmr.getScaledFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST, 144, 256)
                } else {
                    mmr.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST)
                }
                if (bmp == null) continue
                val rgba = Mat()
                Utils.bitmapToMat(bmp, rgba)
                bmp.recycle()
                val g = Mat()
                Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
                rgba.release()
                val g32 = Mat()
                g.convertTo(g32, CvType.CV_32F)
                g.release()
                if (w == 0) { w = g32.cols(); h = g32.rows() }
                if (g32.cols() != w || g32.rows() != h) { g32.release(); continue }
                frames.add(g32)
                times.add(tUs)
            }
            if (frames.size < 14) return null

            // picture speed between consecutive frames
            val fs = ArrayList<Double>()
            val ft = ArrayList<Long>()
            for (j in 1 until frames.size) {
                val p = Imgproc.phaseCorrelate(frames[j - 1], frames[j])
                val dt = (times[j] - times[j - 1]) / 1e6
                if (dt <= 0.0) continue
                fs.add(hypot(p.x, p.y) / dt)
                ft.add((times[j] + times[j - 1]) / 2)
            }
            if (fs.size < 12) return null

            // gyro speed that moves the picture (pitch + yaw), as prefix sums for fast window means
            val cum = DoubleArray(d.n + 1)
            for (i in 0 until d.n) cum[i + 1] = cum[i] + hypot(d.x[i].toDouble(), d.y[i].toDouble())
            fun lower(tNs: Long): Int {
                var lo = 0
                var hi = d.n
                while (lo < hi) {
                    val m = (lo + hi) ushr 1
                    if (d.t[m] < tNs) lo = m + 1 else hi = m
                }
                return lo
            }
            fun gyroMean(t0: Long, t1: Long): Double {
                val a = lower(t0).coerceIn(0, d.n)
                val b = lower(t1).coerceIn(a, d.n)
                return if (b > a) (cum[b] - cum[a]) / (b - a) else 0.0
            }

            val n = fs.size
            val fm = fs.average()
            var fv = 0.0
            for (v in fs) fv += (v - fm) * (v - fm)
            if (fv < 1e-9) return null

            var bestLag = 0
            var bestCorr = -2.0
            var lag = -400
            while (lag <= 400) {
                val gs = DoubleArray(n)
                for (j in 0 until n) {
                    val centre = baseStartNs + ft[j] * 1000L + lag * 1_000_000L
                    gs[j] = gyroMean(centre - 60_000_000L, centre + 60_000_000L)
                }
                val gm = gs.average()
                var gv = 0.0
                var cov = 0.0
                for (j in 0 until n) {
                    gv += (gs[j] - gm) * (gs[j] - gm)
                    cov += (gs[j] - gm) * (fs[j] - fm)
                }
                if (gv > 1e-12) {
                    val r = cov / sqrt(gv * fv)
                    if (r > bestCorr) { bestCorr = r; bestLag = lag }
                }
                lag += 10
            }
            return if (bestCorr > 0.35) bestLag * 1_000_000L else null
        } catch (t: Throwable) {
            return null
        } finally {
            for (m in frames) m.release()
            try { mmr.release() } catch (t: Throwable) { }
        }
    }
}
