package com.oxycam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * EIS+ : gyroscope driven video stabilization.
 *
 *  1. Gyro sync   - TYPE_GYROSCOPE at SENSOR_DELAY_FASTEST goes into a ring buffer. Every sample also stores the
 *                   orientation quaternion [qActual] (world -> camera) integrated from the rates (dt integration).
 *                   Frames are matched to it with SurfaceTexture.getTimestamp().
 *  2. Gimbal math - [qVirtual] follows [qActual] with an adaptive slerp (heavy smoothing for shake, quick follow
 *                   for real pans). qDelta = qVirtual * inverse(qActual) is turned into a homography and scaled
 *                   back (never more than the crop margin allows) so the picture never shows black borders.
 *  3. Rolling shutter - a separate qDelta/homography is made for 17 row boundaries (16 strips) of the sensor
 *                   readout (about READOUT_NS from the first to the last row); the shader interpolates them.
 *
 * All maths is done in the camera sensor frame (x right, y down, z forward, like the raw buffer) so that the result
 * can be applied directly to the SurfaceTexture coordinates.
 */
object GyroStab : SensorEventListener {
    const val STRIPS = 16
    const val CROP_ZOOM = 1.15            // fixed 15% crop used as the stabilization margin
    private const val READOUT_NS = 15_000_000L   // sensor readout time, first row -> last row
    private const val CAP = 2048          // ring buffer size (about 4 s at 500 Hz)
    private const val TAU_MAX = 0.40      // seconds: virtual camera time constant when the hand only shakes
    private const val TAU_MIN = 0.05      // seconds: ... when the user pans on purpose
    private const val UNKNOWN_CLOCK_LATENCY_NS = 30_000_000L

    // ---- set by MainActivity before the camera is bound ----
    @Volatile var sensorOrientation = 90
    @Volatile var focalRatio = 0.8        // focal length / sensor width (both mm)
    @Volatile var zoom = 1.0              // current camera zoom ratio
    @Volatile var realtimeClock = true    // camera timestamps use the same clock as the gyro

    private val lock = Any()
    private val tt = LongArray(CAP)
    private val sq = DoubleArray(CAP * 4)
    private val sw = DoubleArray(CAP * 3)
    private var total = 0L
    private var qCur = doubleArrayOf(1.0, 0.0, 0.0, 0.0)   // qActual (world -> camera), integrated live
    private var lastT = 0L
    private var lwx = 0.0
    private var lwy = 0.0
    private var lwz = 0.0
    private var cosS = 0.0
    private var sinS = 1.0

    private var refs = 0
    private var thread: HandlerThread? = null
    private var sm: SensorManager? = null

    // ---- per-video state (GL thread only) ----
    private var inited = false
    private var qV = doubleArrayOf(1.0, 0.0, 0.0, 0.0)       // qVirtual
    private val wLp = DoubleArray(3)
    private var lastTs = 0L
    private var offEst = 0L
    private var offInit = false

    fun available(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager).getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
    } catch (t: Throwable) {
        false
    }

    // ---------------- sensor ----------------

    /** Starts the gyro (counted: every acquire needs a release). Returns false if there is no gyro. */
    @Synchronized
    fun acquire(ctx: Context): Boolean {
        if (refs == 0 && !startSensor(ctx)) return false
        refs++
        return true
    }

    @Synchronized
    fun release() {
        if (refs == 0) return
        refs--
        if (refs == 0) {
            try { sm?.unregisterListener(this) } catch (t: Throwable) { }
            try { thread?.quitSafely() } catch (t: Throwable) { }
            sm = null
            thread = null
        }
    }

    private fun startSensor(ctx: Context): Boolean {
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return false
        val g = m.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return false
        val rad = sensorOrientation * PI / 180.0
        cosS = cos(rad)
        sinS = sin(rad)
        synchronized(lock) {
            total = 0L
            qCur = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
            lastT = 0L
            lwx = 0.0; lwy = 0.0; lwz = 0.0
        }
        inited = false
        offInit = false
        val th = HandlerThread("OxyCamGyro").also { it.start() }
        val h = Handler(th.looper)
        var ok = false
        try {
            ok = m.registerListener(this, g, SensorManager.SENSOR_DELAY_FASTEST, h)
        } catch (t: Throwable) { }
        if (!ok) {
            try { ok = m.registerListener(this, g, 5000, h) } catch (t: Throwable) { }
        }
        if (!ok) {
            th.quitSafely()
            return false
        }
        sm = m
        thread = th
        return true
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val t = e.timestamp
        val ax = e.values[0].toDouble()
        val ay = e.values[1].toDouble()
        val az = e.values[2].toDouble()
        // device axes -> camera sensor axes (back camera, see class comment)
        val wx = cosS * ax - sinS * ay
        val wy = -sinS * ax - cosS * ay
        val wz = -az
        synchronized(lock) {
            if (total > 0L) {
                val dt = (t - lastT) * 1e-9
                if (dt > 0.0 && dt < 0.1) {
                    val mx = 0.5 * (wx + lwx)
                    val my = 0.5 * (wy + lwy)
                    val mz = 0.5 * (wz + lwz)
                    val mag = sqrt(mx * mx + my * my + mz * mz)
                    val ang = mag * dt
                    if (ang > 1e-12) {
                        val h = ang * 0.5
                        val s = sin(h) / mag
                        // the camera turns by dq, so the world turns by conj(dq) as seen from the camera
                        val dq = doubleArrayOf(cos(h), -mx * s, -my * s, -mz * s)
                        qCur = qnorm(qmul(dq, qCur))
                    }
                }
            }
            val i = (total % CAP).toInt()
            tt[i] = t
            sq[i * 4] = qCur[0]; sq[i * 4 + 1] = qCur[1]; sq[i * 4 + 2] = qCur[2]; sq[i * 4 + 3] = qCur[3]
            sw[i * 3] = wx; sw[i * 3 + 1] = wy; sw[i * 3 + 2] = wz
            total++
            lastT = t
            lwx = wx; lwy = wy; lwz = wz
        }
    }

    /** out = [qw, qx, qy, qz, wx, wy, wz] at time t (gyro clock), interpolated. False when there is no data for t. */
    private fun sampleAt(t: Long, out: DoubleArray): Boolean = synchronized(lock) { sampleLocked(t, out) }

    private fun sampleLocked(t: Long, out: DoubleArray): Boolean {
            val n = if (total < CAP) total.toInt() else CAP
            if (n < 2) return false
            val base = total - n
            fun ph(i: Int) = ((base + i) % CAP).toInt()
            var lo = 0
            var hi = n
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (tt[ph(mid)] >= t) hi = mid else lo = mid + 1
            }
            if (lo == 0) {
                val p = ph(0)
                if (tt[p] - t > 50_000_000L) return false
                copySample(p, out)
                return true
            }
            if (lo == n) {
                val p = ph(n - 1)
                if (t - tt[p] > 200_000_000L) return false
                copySample(p, out)
                return true
            }
            val p0 = ph(lo - 1)
            val p1 = ph(lo)
            val span = (tt[p1] - tt[p0]).toDouble()
            val f = if (span > 0.0) (t - tt[p0]) / span else 0.0
            val a = doubleArrayOf(sq[p0 * 4], sq[p0 * 4 + 1], sq[p0 * 4 + 2], sq[p0 * 4 + 3])
            val b = doubleArrayOf(sq[p1 * 4], sq[p1 * 4 + 1], sq[p1 * 4 + 2], sq[p1 * 4 + 3])
            val q = qslerp(a, b, f)
            out[0] = q[0]; out[1] = q[1]; out[2] = q[2]; out[3] = q[3]
            out[4] = sw[p0 * 3] + (sw[p1 * 3] - sw[p0 * 3]) * f
            out[5] = sw[p0 * 3 + 1] + (sw[p1 * 3 + 1] - sw[p0 * 3 + 1]) * f
            out[6] = sw[p0 * 3 + 2] + (sw[p1 * 3 + 2] - sw[p0 * 3 + 2]) * f
            return true
    }

    private fun copySample(p: Int, out: DoubleArray) {
        out[0] = sq[p * 4]; out[1] = sq[p * 4 + 1]; out[2] = sq[p * 4 + 2]; out[3] = sq[p * 4 + 3]
        out[4] = sw[p * 3]; out[5] = sw[p * 3 + 1]; out[6] = sw[p * 3 + 2]
    }

    // ---------------- quaternion helpers: (w, x, y, z), Hamilton product ----------------

    private fun qmul(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
        a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
        a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
        a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
        a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
    )

    private fun qconj(a: DoubleArray) = doubleArrayOf(a[0], -a[1], -a[2], -a[3])

    private fun qnorm(a: DoubleArray): DoubleArray {
        val n = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2] + a[3] * a[3])
        return if (n < 1e-12) doubleArrayOf(1.0, 0.0, 0.0, 0.0) else doubleArrayOf(a[0] / n, a[1] / n, a[2] / n, a[3] / n)
    }

    /** slerp(identity, q, s): the rotation q scaled to a fraction s of its angle (shortest path). */
    private fun qpow(q: DoubleArray, s: Double): DoubleArray {
        var w = q[0]; var x = q[1]; var y = q[2]; var z = q[3]
        if (w < 0.0) { w = -w; x = -x; y = -y; z = -z }
        val vn = sqrt(x * x + y * y + z * z)
        if (vn < 1e-12) return doubleArrayOf(1.0, 0.0, 0.0, 0.0)
        val h = atan2(vn, w) * s
        val k = sin(h) / vn
        return doubleArrayOf(cos(h), x * k, y * k, z * k)
    }

    private fun qslerp(a: DoubleArray, b: DoubleArray, t: Double): DoubleArray =
        qnorm(qmul(a, qpow(qmul(qconj(a), b), t)))

    private fun qangle(q: DoubleArray): Double {
        val vn = sqrt(q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
        return 2.0 * atan2(vn, abs(q[0]))
    }

    private fun smooth(e0: Double, e1: Double, x: Double): Double {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0)
        return t * t * (3.0 - 2.0 * t)
    }

    /**
     * H = K * R * K^-1 in texture coordinates, with R = rotation of conj(qDelta) (virtual ray -> actual ray),
     * K = [[a 0 .5] [0 b .5] [0 0 1]]. Row-major, written to h[0..8].
     */
    private fun homography(qd: DoubleArray, a: Double, b: Double, h: DoubleArray) {
        val q = qconj(qd)
        val w = q[0]; val x = q[1]; val y = q[2]; val z = q[3]
        val r00 = 1 - 2 * (y * y + z * z); val r01 = 2 * (x * y - w * z); val r02 = 2 * (x * z + w * y)
        val r10 = 2 * (x * y + w * z); val r11 = 1 - 2 * (x * x + z * z); val r12 = 2 * (y * z - w * x)
        val r20 = 2 * (x * z - w * y); val r21 = 2 * (y * z + w * x); val r22 = 1 - 2 * (x * x + y * y)
        // M = R * K^-1
        val m00 = r00 / a; val m01 = r01 / b; val m02 = -0.5 * r00 / a - 0.5 * r01 / b + r02
        val m10 = r10 / a; val m11 = r11 / b; val m12 = -0.5 * r10 / a - 0.5 * r11 / b + r12
        val m20 = r20 / a; val m21 = r21 / b; val m22 = -0.5 * r20 / a - 0.5 * r21 / b + r22
        h[0] = a * m00 + 0.5 * m20; h[1] = a * m01 + 0.5 * m21; h[2] = a * m02 + 0.5 * m22
        h[3] = b * m10 + 0.5 * m20; h[4] = b * m11 + 0.5 * m21; h[5] = b * m12 + 0.5 * m22
        h[6] = m20; h[7] = m21; h[8] = m22
    }

    // ---------------- per frame ----------------

    /**
     * Called for every camera frame on the GL thread.
     * [ts] = SurfaceTexture.getTimestamp() of the frame, [bufW]x[bufH] = camera buffer size.
     * [wins] = for each output the part of the camera texture it shows: [minX, maxX, minY, maxY] (texture coords).
     * [out] = for each output (STRIPS + 1) row-boundary homographies, 9 floats each (row-major), top row first.
     * Returns false when there is no gyro data yet (the caller then draws the plain, only cropped, picture).
     */
    fun solve(ts: Long, bufW: Int, bufH: Int, wins: List<DoubleArray>, out: List<FloatArray>): Boolean {
        if (bufW <= 0 || bufH <= 0) return false
        val nOut = wins.size
        val a = focalRatio * zoom
        val b = a * bufW / bufH
        val zc = CROP_ZOOM

        // frame clock -> gyro clock
        val now = SystemClock.elapsedRealtimeNanos()
        var off = 0L
        if (!realtimeClock) {
            val cand = now - ts
            offEst = if (!offInit) cand else min(offEst + 20_000L, cand)
            offInit = true
            off = offEst - UNKNOWN_CLOCK_LATENCY_NS
        }
        fun timeOf(row: Double): Long = ts + off + (READOUT_NS * row.coerceIn(0.0, 1.0)).toLong()

        val s0 = DoubleArray(7)
        if (!sampleAt(timeOf(0.5), s0)) {
            inited = false
            return false
        }
        val qAc = doubleArrayOf(s0[0], s0[1], s0[2], s0[3])

        val dt = if (lastTs == 0L) 0.0 else (ts - lastTs) * 1e-9
        if (!inited || dt <= 0.0 || dt > 0.5) {
            qV = qAc.copyOf()
            wLp[0] = 0.0; wLp[1] = 0.0; wLp[2] = 0.0
            inited = true
        } else {
            val d = dt.coerceIn(0.004, 0.1)
            val lp = 1.0 - exp(-d / 0.25)
            wLp[0] += (s0[4] - wLp[0]) * lp
            wLp[1] += (s0[5] - wLp[1]) * lp
            wLp[2] += (s0[6] - wLp[2]) * lp
            val pan = sqrt(wLp[0] * wLp[0] + wLp[1] * wLp[1] + wLp[2] * wLp[2])
            // how far the crop margin allows the virtual camera to be from the real one (radians)
            var lim = 1e9
            for (w in wins) {
                val mx = 0.5 * (1.0 - 1.0 / zc) * (w[1] - w[0]) / a
                val my = 0.5 * (1.0 - 1.0 / zc) * (w[3] - w[2]) / b
                lim = min(lim, min(mx, my))
            }
            val dev = qangle(qmul(qV, qconj(qAc)))
            val follow = max(smooth(0.25, 1.2, pan), smooth(0.45 * lim, 0.9 * lim, dev))
            val tau = TAU_MAX + (TAU_MIN - TAU_MAX) * follow
            qV = qslerp(qV, qAc, 1.0 - exp(-d / tau))
        }
        lastTs = ts

        // qDelta = qVirtual * inverse(qActual) for every row boundary of every output
        val rows = STRIPS + 1
        val qd = Array(nOut) { Array(rows) { doubleArrayOf(1.0, 0.0, 0.0, 0.0) } }
        val s1 = DoubleArray(7)
        for (j in 0 until nOut) {
            val w = wins[j]
            val cy = 0.5 * (w[2] + w[3])
            for (k in 0 until rows) {
                val ty = w[2] + (w[3] - w[2]) * k / STRIPS
                val tyZ = cy + (ty - cy) / zc      // the sensor row that really ends up on this screen row
                if (sampleAt(timeOf(tyZ), s1)) {
                    qd[j][k] = qmul(qV, qconj(doubleArrayOf(s1[0], s1[1], s1[2], s1[3])))
                } else {
                    qd[j][k] = qmul(qV, qconj(qAc))
                }
            }
        }

        val hh = DoubleArray(9)
        val gx = 1.5 / bufW
        val gy = 1.5 / bufH

        // true when scaling every rotation to [s] of its angle keeps the 15%-zoomed picture inside the camera picture
        fun feasible(s: Double): Boolean {
            for (j in 0 until nOut) {
                val w = wins[j]
                val cx = 0.5 * (w[0] + w[1])
                val cy = 0.5 * (w[2] + w[3])
                for (k in 0 until rows) {
                    homography(qpow(qd[j][k], s), a, b, hh)
                    val ty = w[2] + (w[3] - w[2]) * k / STRIPS
                    val y0 = cy + (ty - cy) / zc
                    for (c in 0..1) {
                        val x0 = cx + ((if (c == 0) w[0] else w[1]) - cx) / zc
                        val pz = hh[6] * x0 + hh[7] * y0 + hh[8]
                        if (pz < 1e-4) return false
                        val px = (hh[0] * x0 + hh[1] * y0 + hh[2]) / pz
                        val py = (hh[3] * x0 + hh[4] * y0 + hh[5]) / pz
                        if (px < w[0] + gx || px > w[1] - gx || py < w[2] + gy || py > w[3] - gy) return false
                    }
                }
            }
            return true
        }

        var s = 1.0
        if (!feasible(1.0)) {
            var lo = 0.0
            var hi = 1.0
            for (i in 0 until 8) {
                val mid = 0.5 * (lo + hi)
                if (feasible(mid)) lo = mid else hi = mid
            }
            s = lo
            // drag the virtual camera along so it does not wind up against the crop limit
            qV = qnorm(qmul(qpow(qmul(qV, qconj(qAc)), s), qAc))
        }

        for (j in 0 until nOut) {
            for (k in 0 until rows) {
                homography(qpow(qd[j][k], s), a, b, hh)
                for (i in 0 until 9) out[j][k * 9 + i] = hh[i].toFloat()
            }
        }
        return true
    }
}
