package com.oxycam

import android.graphics.Bitmap
import androidx.camera.core.ImageProxy
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point as CvPoint
import org.opencv.core.Size as CvSize
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot

/** Document mode: finds the page, straightens it (perspective crop) and applies Standard / Enhanced / B&W. */
object DocumentFilterProcessor {

    const val STANDARD = 0
    const val ENHANCED = 1
    const val BLACK_WHITE = 2

    // ---------------- detection ----------------

    /**
     * Reads the Y (brightness) plane of a camera frame, turns it upright and looks for the page.
     * Returns 8 numbers (TL, TR, BR, BL as x,y in 0..1 of the upright frame) or null. Does not close [image].
     */
    fun detectFromFrame(image: ImageProxy, maxSide: Int): FloatArray? {
        if (!MultiFrame.init()) return null
        val pl = image.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val w = image.width
        val h = image.height
        val bytes = ByteArray(w * h)
        for (row in 0 until h) {
            buf.position(row * rs)
            buf.get(bytes, row * w, w)
        }
        val g = Mat(h, w, CvType.CV_8UC1)
        g.put(0, 0, bytes)
        val up = Mat()
        when (image.imageInfo.rotationDegrees) {
            90 -> Core.rotate(g, up, Core.ROTATE_90_CLOCKWISE)
            180 -> Core.rotate(g, up, Core.ROTATE_180)
            270 -> Core.rotate(g, up, Core.ROTATE_90_COUNTERCLOCKWISE)
            else -> g.copyTo(up)
        }
        g.release()
        val q = detectQuad(up, maxSide)
        up.release()
        return q
    }

    /** [gray] is an upright 8-bit gray image of any size. Result as in [detectFromFrame]. */
    fun detectQuad(gray: Mat, maxSide: Int): FloatArray? {
        val w0 = gray.cols()
        val h0 = gray.rows()
        if (w0 < 16 || h0 < 16) return null
        val scale = minOf(1.0, maxSide.toDouble() / maxOf(w0, h0))
        val small = Mat()
        if (scale < 1.0) {
            Imgproc.resize(gray, small, CvSize(w0 * scale, h0 * scale), 0.0, 0.0, Imgproc.INTER_AREA)
        } else {
            gray.copyTo(small)
        }
        val blur = Mat()
        Imgproc.GaussianBlur(small, blur, CvSize(5.0, 5.0), 0.0)
        val edges = Mat()
        Imgproc.Canny(blur, edges, 40.0, 120.0)
        val k3 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, CvSize(3.0, 3.0))
        Imgproc.dilate(edges, edges, k3)
        var found = bestQuad(edges, small.cols(), small.rows())
        if (found == null) {
            // second try: the page is usually the big bright blob
            val th = Mat()
            Imgproc.threshold(blur, th, 0.0, 255.0, Imgproc.THRESH_BINARY + Imgproc.THRESH_OTSU)
            val k9 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, CvSize(9.0, 9.0))
            Imgproc.morphologyEx(th, th, Imgproc.MORPH_CLOSE, k9)
            found = bestQuad(th, small.cols(), small.rows())
            th.release()
            k9.release()
        }
        k3.release()
        edges.release()
        blur.release()
        small.release()
        return found
    }

    /** Biggest convex 4-corner shape in a binary / edge image, corners sorted TL, TR, BR, BL and normalised to 0..1. */
    private fun bestQuad(bin: Mat, w: Int, h: Int): FloatArray? {
        val contours = ArrayList<MatOfPoint>()
        val hier = Mat()
        Imgproc.findContours(bin, contours, hier, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
        hier.release()
        val minArea = 0.12 * w * h
        val maxArea = 0.985 * w * h
        var bestArea = 0.0
        var best: Array<CvPoint>? = null
        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area >= minArea && area <= maxArea && area > bestArea) {
                val c2f = MatOfPoint2f(*c.toArray())
                val peri = Imgproc.arcLength(c2f, true)
                val approx = MatOfPoint2f()
                Imgproc.approxPolyDP(c2f, approx, 0.02 * peri, true)
                if (approx.total() == 4L) {
                    val ap = MatOfPoint(*approx.toArray())
                    if (Imgproc.isContourConvex(ap)) {
                        bestArea = area
                        best = approx.toArray()
                    }
                    ap.release()
                }
                approx.release()
                c2f.release()
            }
            c.release()
        }
        val pts = best ?: return null
        return sortCorners(pts, w, h)
    }

    private fun sortCorners(p: Array<CvPoint>, w: Int, h: Int): FloatArray {
        var tl = p[0]
        var br = p[0]
        var tr = p[0]
        var bl = p[0]
        for (pt in p) {
            if (pt.x + pt.y < tl.x + tl.y) tl = pt
            if (pt.x + pt.y > br.x + br.y) br = pt
            if (pt.y - pt.x < tr.y - tr.x) tr = pt
            if (pt.y - pt.x > bl.y - bl.x) bl = pt
        }
        return floatArrayOf(
            (tl.x / w).toFloat(), (tl.y / h).toFloat(), (tr.x / w).toFloat(), (tr.y / h).toFloat(),
            (br.x / w).toFloat(), (br.y / h).toFloat(), (bl.x / w).toFloat(), (bl.y / h).toFloat()
        )
    }

    // ---------------- crop + filters ----------------

    /**
     * Straightens the page in the full-size photo [src] and applies [filter] (STANDARD / ENHANCED / BLACK_WHITE).
     * The page is looked for again in the full photo; [liveQuad] (from the viewfinder) is used if that finds nothing.
     * If no page is found at all, the whole photo is used. [src] is recycled when a new bitmap is returned.
     */
    fun process(src: Bitmap, liveQuad: FloatArray?, filter: Int): Bitmap {
        if (!MultiFrame.init()) return src
        val rgba = Mat()
        Utils.bitmapToMat(src, rgba)
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        val gray = Mat()
        Imgproc.cvtColor(rgb, gray, Imgproc.COLOR_RGB2GRAY)
        val quad = detectQuad(gray, 960) ?: liveQuad
        gray.release()

        val cropped = if (quad != null) warp(rgb, quad) else rgb
        if (cropped !== rgb) rgb.release()

        val filtered = when (filter) {
            ENHANCED -> enhance(cropped)
            BLACK_WHITE -> blackWhite(cropped)
            else -> cropped
        }
        if (filtered !== cropped) cropped.release()

        val out = Mat()
        Imgproc.cvtColor(filtered, out, Imgproc.COLOR_RGB2RGBA)
        val bmp = Bitmap.createBitmap(out.cols(), out.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(out, bmp)
        out.release()
        filtered.release()
        src.recycle()
        return bmp
    }

    /** Perspective crop: the 4 sorted corners become a flat rectangle. */
    private fun warp(rgb: Mat, q: FloatArray): Mat {
        val w = rgb.cols()
        val h = rgb.rows()
        val tl = CvPoint(q[0] * w.toDouble(), q[1] * h.toDouble())
        val tr = CvPoint(q[2] * w.toDouble(), q[3] * h.toDouble())
        val br = CvPoint(q[4] * w.toDouble(), q[5] * h.toDouble())
        val bl = CvPoint(q[6] * w.toDouble(), q[7] * h.toDouble())
        val wTop = hypot(tr.x - tl.x, tr.y - tl.y)
        val wBot = hypot(br.x - bl.x, br.y - bl.y)
        val hLeft = hypot(bl.x - tl.x, bl.y - tl.y)
        val hRight = hypot(br.x - tr.x, br.y - tr.y)
        var outW = maxOf(wTop, wBot)
        var outH = maxOf(hLeft, hRight)
        val big = maxOf(outW, outH)
        if (big > 6000.0) {
            outW = outW * 6000.0 / big
            outH = outH * 6000.0 / big
        }
        val ow = maxOf(64, outW.toInt())
        val oh = maxOf(64, outH.toInt())
        val srcPts = MatOfPoint2f(tl, tr, br, bl)
        val dstPts = MatOfPoint2f(
            CvPoint(0.0, 0.0), CvPoint(ow - 1.0, 0.0), CvPoint(ow - 1.0, oh - 1.0), CvPoint(0.0, oh - 1.0)
        )
        val m = Imgproc.getPerspectiveTransform(srcPts, dstPts)
        val out = Mat()
        Imgproc.warpPerspective(rgb, out, m, CvSize(ow.toDouble(), oh.toDouble()), Imgproc.INTER_CUBIC, Core.BORDER_REPLICATE)
        m.release()
        srcPts.release()
        dstPts.release()
        return out
    }

    /** Removes shadows (paper brightness is estimated and divided out) and sharpens text and colours. */
    private fun enhance(rgb: Mat): Mat {
        val w = rgb.cols()
        val h = rgb.rows()
        val s = minOf(1.0, 640.0 / maxOf(w, h))
        val small = Mat()
        Imgproc.resize(rgb, small, CvSize(maxOf(8.0, w * s), maxOf(8.0, h * s)), 0.0, 0.0, Imgproc.INTER_AREA)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, CvSize(9.0, 9.0))
        val dil = Mat()
        Imgproc.dilate(small, dil, kernel) // dark text disappears, the paper brightness stays
        val bgSmall = Mat()
        Imgproc.blur(dil, bgSmall, CvSize(31.0, 31.0))
        val bg = Mat()
        Imgproc.resize(bgSmall, bg, CvSize(w.toDouble(), h.toDouble()), 0.0, 0.0, Imgproc.INTER_LINEAR)
        val flat = Mat()
        Core.divide(rgb, bg, flat, 255.0)
        flat.convertTo(flat, -1, 1.1, -8.0)
        val soft = Mat()
        Imgproc.GaussianBlur(flat, soft, CvSize(0.0, 0.0), 1.4)
        val out = Mat()
        Core.addWeighted(flat, 1.6, soft, -0.6, 0.0, out)
        for (m in listOf(small, kernel, dil, bgSmall, bg, flat, soft)) m.release()
        return out
    }

    /** Grayscale + Gaussian adaptive threshold: pure black text on white paper. */
    private fun blackWhite(rgb: Mat): Mat {
        val gray = Mat()
        Imgproc.cvtColor(rgb, gray, Imgproc.COLOR_RGB2GRAY)
        Imgproc.medianBlur(gray, gray, 3)
        var block = maxOf(31, maxOf(gray.cols(), gray.rows()) / 40)
        if (block % 2 == 0) block += 1
        val bw = Mat()
        Imgproc.adaptiveThreshold(gray, bw, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY, block, 12.0)
        val out = Mat()
        Imgproc.cvtColor(bw, out, Imgproc.COLOR_GRAY2RGB)
        gray.release()
        bw.release()
        return out
    }
}
