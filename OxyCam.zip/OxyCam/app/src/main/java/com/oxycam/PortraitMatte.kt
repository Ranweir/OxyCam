package com.oxycam

import android.graphics.Bitmap
import android.graphics.PointF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/**
 * Software portrait (bokeh) with a much cleaner subject cut-out than a plain person mask:
 *  1. ML Kit finds the person (rough, low-resolution confidence map).
 *  2. GrabCut (OpenCV) re-draws the edge from the real colours of the picture. If the subject is an object
 *     (or you tapped on one) a seed around the focus point is added, so objects are cut out too.
 *  3. Small specks / holes are removed and a guided filter snaps the edge to the real edges at higher resolution.
 *  4. The background is blurred WITHOUT the subject's colours (no bright halos) and the blur grows with
 *     distance from the subject (soft depth transition) instead of one flat blur.
 */
object PortraitMatte {

    private class Person(val m: FloatArray, val w: Int, val h: Int)
    private class Alpha(val a: FloatArray, val w: Int, val h: Int)

    private fun person(bmp: Bitmap): Person? {
        return try {
            val sc = 640f / maxOf(bmp.width, bmp.height)
            val small = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
            val seg = Segmentation.getClient(
                SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
            )
            val res = Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
            val buf = res.buffer
            buf.rewind()
            val mw = res.width
            val mh = res.height
            val m = FloatArray(mw * mh) { buf.float }
            seg.close()
            small.recycle()
            Person(m, mw, mh)
        } catch (t: Throwable) {
            null
        }
    }

    private fun sample(m: FloatArray, mw: Int, mh: Int, u: Float, v: Float): Float {
        val x = (u * (mw - 1)).coerceIn(0f, mw - 1f)
        val y = (v * (mh - 1)).coerceIn(0f, mh - 1f)
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(x0 + 1, mw - 1)
        val y1 = min(y0 + 1, mh - 1)
        val tx = x - x0
        val ty = y - y0
        val a = m[y0 * mw + x0] * (1 - tx) + m[y0 * mw + x1] * tx
        val b = m[y1 * mw + x0] * (1 - tx) + m[y1 * mw + x1] * tx
        return a * (1 - ty) + b * ty
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Flips connected blobs of value [target] that are smaller than [minArea] pixels. */
    private fun removeSmall(m: FloatArray, w: Int, h: Int, minArea: Int, target: Float) {
        val bytes = ByteArray(w * h) { i -> if (m[i] == target) 255.toByte() else 0.toByte() }
        val mat = Mat(h, w, CvType.CV_8UC1)
        mat.put(0, 0, bytes)
        val labels = Mat()
        val stats = Mat()
        val cent = Mat()
        val n = Imgproc.connectedComponentsWithStats(mat, labels, stats, cent, 8, CvType.CV_32S)
        val tiny = BooleanArray(n)
        for (i in 1 until n) tiny[i] = stats.get(i, Imgproc.CC_STAT_AREA)[0] < minArea
        val lab = IntArray(w * h)
        labels.get(0, 0, lab)
        for (i in lab.indices) if (lab[i] > 0 && tiny[lab[i]]) m[i] = 1f - target
        mat.release(); labels.release(); stats.release(); cent.release()
    }

    /** Guided filter (He et al.): makes [p] follow the edges of the guide [g]. Both CV_32FC1. */
    private fun guided(g: Mat, p: Mat, r: Int, eps: Double): Mat {
        val k = Size((2 * r + 1).toDouble(), (2 * r + 1).toDouble())
        val meanI = Mat(); Imgproc.boxFilter(g, meanI, CvType.CV_32F, k)
        val meanP = Mat(); Imgproc.boxFilter(p, meanP, CvType.CV_32F, k)
        val tmp = Mat()
        Core.multiply(g, p, tmp)
        val meanIp = Mat(); Imgproc.boxFilter(tmp, meanIp, CvType.CV_32F, k)
        Core.multiply(g, g, tmp)
        val meanII = Mat(); Imgproc.boxFilter(tmp, meanII, CvType.CV_32F, k)
        Core.multiply(meanI, meanP, tmp)
        val cov = Mat(); Core.subtract(meanIp, tmp, cov)
        Core.multiply(meanI, meanI, tmp)
        val varI = Mat(); Core.subtract(meanII, tmp, varI)
        Core.add(varI, Scalar(eps), varI)
        val a = Mat(); Core.divide(cov, varI, a)
        Core.multiply(a, meanI, tmp)
        val b = Mat(); Core.subtract(meanP, tmp, b)
        val meanA = Mat(); Imgproc.boxFilter(a, meanA, CvType.CV_32F, k)
        val meanB = Mat(); Imgproc.boxFilter(b, meanB, CvType.CV_32F, k)
        Core.multiply(meanA, g, tmp)
        val q = Mat(); Core.add(tmp, meanB, q)
        Core.max(q, Scalar(0.0), q)
        Core.min(q, Scalar(1.0), q)
        for (m in listOf(meanI, meanP, tmp, meanIp, meanII, cov, varI, a, b, meanA, meanB)) m.release()
        return q
    }

    private fun toMat8(bmp: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        return rgb
    }

    private fun refine(bmp: Bitmap, p: Person?, focus: PointF?): Alpha {
        val w = bmp.width
        val h = bmp.height
        val gs = 720f / max(w, h)
        val gw = max(64, (w * gs).toInt())
        val gh = max(64, (h * gs).toInt())
        val smallBmp = Bitmap.createScaledBitmap(bmp, gw, gh, true)
        val rgb = toMat8(smallBmp)
        smallBmp.recycle()

        // person confidence at working size
        val ml = FloatArray(gw * gh)
        var cnt = 0
        if (p != null) {
            for (y in 0 until gh) for (x in 0 until gw) {
                val v = sample(p.m, p.w, p.h, x / (gw - 1f), y / (gh - 1f))
                ml[y * gw + x] = v
                if (v > 0.5f) cnt++
            }
        }
        val cover = cnt.toFloat() / (gw * gh)

        // sure foreground / sure background cores (eroded so wrong patches near the edge can be corrected)
        val hiB = ByteArray(gw * gh) { i -> if (ml[i] > 0.9f) 255.toByte() else 0.toByte() }
        val loB = ByteArray(gw * gh) { i -> if (ml[i] < 0.1f) 255.toByte() else 0.toByte() }
        val hi = Mat(gh, gw, CvType.CV_8UC1)
        val lo = Mat(gh, gw, CvType.CV_8UC1)
        hi.put(0, 0, hiB)
        lo.put(0, 0, loB)
        val kern = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(15.0, 15.0))
        Imgproc.erode(hi, hi, kern)
        Imgproc.erode(lo, lo, kern)
        hi.get(0, 0, hiB)
        lo.get(0, 0, loB)
        hi.release(); lo.release()

        // GrabCut codes: 0 sure BG, 1 sure FG, 2 probable BG, 3 probable FG
        val code = ByteArray(gw * gh)
        for (i in code.indices) {
            val c = when {
                p != null && hiB[i] != 0.toByte() -> 1
                p != null && loB[i] != 0.toByte() -> 0
                p != null && ml[i] > 0.5f -> 3
                else -> 2
            }
            code[i] = c.toByte()
        }

        // object subject (or none found): seed around the tapped / centre point
        val fx = (focus?.x ?: 0.5f).coerceIn(0.1f, 0.9f)
        val fy = (focus?.y ?: 0.5f).coerceIn(0.1f, 0.9f)
        val mlAt = ml[(fy * (gh - 1)).toInt() * gw + (fx * (gw - 1)).toInt()]
        if (p == null || cover < 0.03f || mlAt < 0.3f) {
            val cx = fx * gw
            val cy = fy * gh
            val rd = 0.05f * min(gw, gh)
            val ax = 0.28f * gw
            val ay = 0.25f * gh
            for (y in 0 until gh) for (x in 0 until gw) {
                val dx = x - cx
                val dy = y - cy
                val i = y * gw + x
                if (dx * dx + dy * dy < rd * rd) code[i] = 1
                else if ((dx / ax) * (dx / ax) + (dy / ay) * (dy / ay) < 1f && code[i] == 2.toByte()) code[i] = 3
            }
        }
        if (p == null || cover < 0.03f) {
            val bw = (0.03f * min(gw, gh)).toInt()
            for (y in 0 until gh) for (x in 0 until gw) {
                if (x < bw || y < bw || x >= gw - bw || y >= gh - bw) code[y * gw + x] = 0
            }
        }

        val gc = Mat(gh, gw, CvType.CV_8UC1)
        gc.put(0, 0, code)
        Imgproc.grabCut(rgb, gc, Rect(), Mat(), Mat(), 3, Imgproc.GC_INIT_WITH_MASK)
        gc.get(0, 0, code)
        gc.release()
        rgb.release()

        val fg = FloatArray(gw * gh) { i -> if (code[i] == 1.toByte() || code[i] == 3.toByte()) 1f else 0f }
        removeSmall(fg, gw, gh, (0.003f * gw * gh).toInt(), 1f)   // stray specks of "subject"
        removeSmall(fg, gw, gh, (0.0015f * gw * gh).toInt(), 0f)  // tiny holes inside the subject
        var sum = 0f
        for (v in fg) sum += v
        val frac = sum / fg.size
        if (frac < 0.01f || frac > 0.97f) throw IllegalStateException("no usable subject")

        // snap the edge to the real picture edges at higher resolution
        val rs = 1600f / max(w, h)
        val rw = max(64, (w * rs).toInt())
        val rh = max(64, (h * rs).toInt())
        val bigBmp = Bitmap.createScaledBitmap(bmp, rw, rh, true)
        val rgb2 = toMat8(bigBmp)
        bigBmp.recycle()
        val g8 = Mat()
        Imgproc.cvtColor(rgb2, g8, Imgproc.COLOR_RGB2GRAY)
        rgb2.release()
        val guide = Mat()
        g8.convertTo(guide, CvType.CV_32F, 1.0 / 255.0)
        g8.release()
        val pSmall = Mat(gh, gw, CvType.CV_32FC1)
        pSmall.put(0, 0, fg)
        val pBig = Mat()
        Imgproc.resize(pSmall, pBig, Size(rw.toDouble(), rh.toDouble()), 0.0, 0.0, Imgproc.INTER_LINEAR)
        pSmall.release()
        val q = guided(guide, pBig, 8, 1e-3)
        guide.release(); pBig.release()
        val qa = FloatArray(rw * rh)
        q.get(0, 0, qa)
        q.release()
        return Alpha(qa, rw, rh)
    }

    /** Blur of the background that ignores the subject's colours (no halos). [apI] 0..3 = f/1.4 .. f/4. */
    private fun backgroundBlur(bmp: Bitmap, alpha: Alpha, apI: Int): IntArray {
        val w = bmp.width
        val h = bmp.height
        val sw = max(64, w / 6)
        val sh = max(64, h * sw / w)
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val rgb8 = toMat8(small)
        small.recycle()
        val img = Mat()
        rgb8.convertTo(img, CvType.CV_32FC3, 1.0 / 255.0)
        rgb8.release()

        val aFull = Mat(alpha.h, alpha.w, CvType.CV_32FC1)
        aFull.put(0, 0, alpha.a)
        val aS = Mat()
        Imgproc.resize(aFull, aS, Size(sw.toDouble(), sh.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
        aFull.release()
        val aDil = Mat()
        Imgproc.dilate(aS, aDil, Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(7.0, 7.0)))
        val bgw = Mat()
        Core.subtract(Mat.ones(sh, sw, CvType.CV_32FC1), aDil, bgw)
        aDil.release()
        val bgBin = Mat()
        Core.compare(aS, Scalar(0.5), bgBin, Core.CMP_LT)
        aS.release()
        val dist = Mat()
        Imgproc.distanceTransform(bgBin, dist, Imgproc.DIST_L2, 3)
        bgBin.release()

        val sigmaBase = floatArrayOf(10f, 7f, 5f, 3.5f)[apI.coerceIn(0, 3)] * sw / 533f
        val bgw3 = Mat()
        Imgproc.cvtColor(bgw, bgw3, Imgproc.COLOR_GRAY2RGB)
        val num = Mat()
        Core.multiply(img, bgw3, num)
        fun blur(sig: Double): FloatArray {
            val nb = Mat()
            Imgproc.GaussianBlur(num, nb, Size(0.0, 0.0), sig)
            val db = Mat()
            Imgproc.GaussianBlur(bgw, db, Size(0.0, 0.0), sig)
            Core.max(db, Scalar(0.02), db)
            val d3 = Mat()
            Imgproc.cvtColor(db, d3, Imgproc.COLOR_GRAY2RGB)
            val out = Mat()
            Core.divide(nb, d3, out)
            val arr = FloatArray(sw * sh * 3)
            out.get(0, 0, arr)
            nb.release(); db.release(); d3.release(); out.release()
            return arr
        }
        val near = blur(sigmaBase * 0.35)
        val far = blur(sigmaBase)
        val dArr = FloatArray(sw * sh)
        dist.get(0, 0, dArr)
        img.release(); bgw.release(); bgw3.release(); num.release(); dist.release()

        val reach = 0.10f * max(sw, sh)
        val px = IntArray(sw * sh)
        for (i in px.indices) {
            val t = smooth(0f, reach, dArr[i])
            var r = near[i * 3] * (1 - t) + far[i * 3] * t
            var g = near[i * 3 + 1] * (1 - t) + far[i * 3 + 1] * t
            var b = near[i * 3 + 2] * (1 - t) + far[i * 3 + 2] * t
            r = r.coerceIn(0f, 1f); g = g.coerceIn(0f, 1f); b = b.coerceIn(0f, 1f)
            px[i] = (255 shl 24) or ((r * 255f).toInt() shl 16) or ((g * 255f).toInt() shl 8) or (b * 255f).toInt()
        }
        val sb = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        sb.setPixels(px, 0, sw, 0, 0, sw, sh)
        val big = Bitmap.createScaledBitmap(sb, w, h, true)
        sb.recycle()
        val out = IntArray(w * h)
        big.getPixels(out, 0, w, 0, 0, w, h)
        big.recycle()
        return out
    }

    /** [bmp] must be upright and mutable. Throws if no usable subject is found (caller falls back). */
    fun render(bmp: Bitmap, apI: Int, focus: PointF?): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val alpha = refine(bmp, person(bmp), focus)
        val bl = backgroundBlur(bmp, alpha, apI)
        val arr = IntArray(w * h)
        bmp.getPixels(arr, 0, w, 0, 0, w, h)
        val aw = alpha.w
        val ah = alpha.h
        for (y in 0 until h) {
            val fy = y * (ah - 1f) / (h - 1f)
            val y0 = fy.toInt()
            val y1 = min(y0 + 1, ah - 1)
            val ty = fy - y0
            for (x in 0 until w) {
                val fx = x * (aw - 1f) / (w - 1f)
                val x0 = fx.toInt()
                val x1 = min(x0 + 1, aw - 1)
                val tx = fx - x0
                val top = alpha.a[y0 * aw + x0] * (1 - tx) + alpha.a[y0 * aw + x1] * tx
                val bot = alpha.a[y1 * aw + x0] * (1 - tx) + alpha.a[y1 * aw + x1] * tx
                val a = smooth(0.12f, 0.88f, top * (1 - ty) + bot * ty)
                val i = y * w + x
                if (a >= 0.995f) continue
                if (a <= 0.005f) { arr[i] = bl[i]; continue }
                val p = arr[i]
                val q = bl[i]
                val r = (((p shr 16) and 255) * a + ((q shr 16) and 255) * (1 - a)).toInt()
                val g = (((p shr 8) and 255) * a + ((q shr 8) and 255) * (1 - a)).toInt()
                val b = ((p and 255) * a + (q and 255) * (1 - a)).toInt()
                arr[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bmp.setPixels(arr, 0, w, 0, 0, w, h)
        return bmp
    }
}
