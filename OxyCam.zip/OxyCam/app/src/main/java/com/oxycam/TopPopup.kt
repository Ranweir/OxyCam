package com.oxycam

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

/** Small pop-up under a top-bar button (like OPPO Find series): rows of option pills, tap one to pick it. */
object TopPopup {
    class Section(val label: String?, val options: List<String>, val selected: Int, val onPick: (Int) -> Unit)

    fun show(act: Activity, anchor: View, sections: List<Section>, closeOnPick: Boolean) {
        val acc = GlassDialog.accent(act)
        val density = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val lum = (0.299 * Color.red(acc) + 0.587 * Color.green(acc) + 0.114 * Color.blue(acc)) / 255.0
        val onAcc = if (lum > 0.5) Color.BLACK else Color.WHITE
        val screenW = act.resources.displayMetrics.widthPixels
        val screenH = act.resources.displayMetrics.heightPixels

        val panel = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(Color.argb(228, 28, 28, 32))
                setStroke(dp(1), Color.argb(70, 255, 255, 255))
            }
            elevation = dp(12).toFloat()
        }
        var pw: PopupWindow? = null

        for (sec in sections) {
            if (sec.label != null) {
                panel.addView(TextView(act).apply {
                    text = sec.label
                    textSize = 12f
                    setTextColor(Color.argb(170, 255, 255, 255))
                    setPadding(dp(4), dp(4), 0, dp(6))
                })
            }
            val pills = ArrayList<TextView>()
            fun refresh(sel: Int) {
                for ((k, p) in pills.withIndex()) {
                    val on = k == sel
                    p.setTextColor(if (on) onAcc else Color.WHITE)
                    (p.background as GradientDrawable).setColor(if (on) acc else Color.argb(55, 255, 255, 255))
                }
            }
            fun makePill(i: Int): TextView {
                val p = TextView(act).apply {
                    text = sec.options[i]
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(9), dp(12), dp(9))
                    background = GradientDrawable().apply { cornerRadius = dp(16).toFloat() }
                    setOnClickListener {
                        refresh(i)
                        sec.onPick(i)
                        if (closeOnPick) pw?.dismiss()
                    }
                }
                pills.add(p)
                return p
            }

            if (sec.options.size <= 4) {
                val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
                for (i in sec.options.indices) {
                    val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    lp.setMargins(dp(3), 0, dp(3), dp(6))
                    row.addView(makePill(i), lp)
                }
                panel.addView(row)
            } else {
                val g = GridLayout(act).apply { columnCount = 3 }
                for (i in sec.options.indices) {
                    val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
                    lp.width = 0
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                    g.addView(makePill(i), lp)
                }
                val sv = GlassDialog.MaxHeightScroll(act, (screenH * 0.5f).toInt())
                sv.isVerticalScrollBarEnabled = false
                sv.addView(g)
                panel.addView(sv)
            }
            refresh(sec.selected)
        }

        val popup = PopupWindow(panel, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)
        pw = popup
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.isOutsideTouchable = true

        panel.measure(
            View.MeasureSpec.makeMeasureSpec(screenW - dp(24), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = panel.measuredWidth
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val cx = loc[0] + anchor.width / 2
        val x = (cx - w / 2).coerceIn(dp(12), (screenW - w - dp(12)).coerceAtLeast(dp(12)))
        val y = loc[1] + anchor.height + dp(2)

        panel.alpha = 0f
        panel.scaleX = 0.85f
        panel.scaleY = 0.85f
        panel.pivotX = (cx - x).toFloat()
        panel.pivotY = 0f
        popup.showAtLocation(act.window.decorView, Gravity.NO_GRAVITY, x, y)
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190)
            .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)).start()
    }
}
