package com.oxycam

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.camera.view.PreviewView

/**
 * Wide frosted-glass pop-up under a top-bar button (OPPO Find style).
 * Each section is one row: a label and its option pills on a single line.
 * Long lists (filters) become a scrollable grid.
 */
object TopPopup {
    class Section(val label: String?, val options: List<String>, val selected: Int, val onPick: (Int) -> Unit)

    fun show(
        act: Activity, anchor: View, sections: List<Section>, closeOnPick: Boolean,
        live: PreviewView? = null, above: Boolean = false, columns: Int = 0
    ) {
        val acc = GlassDialog.accent(act)
        val dm = act.resources.displayMetrics
        fun dp(v: Int) = (v * dm.density).toInt()
        val lum = (0.299 * Color.red(acc) + 0.587 * Color.green(acc) + 0.114 * Color.blue(acc)) / 255.0
        val onAcc = if (lum > 0.5) Color.BLACK else Color.WHITE
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels
        val popupW = screenW - dp(24)

        // blurred picture of what is behind the pop-up, taken before it appears
        val frost = GlassDialog.frosted(act, live)

        val content = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        var pw: PopupWindow? = null

        for (sec in sections) {
            val pills = ArrayList<TextView>()
            fun refresh(sel: Int) {
                for ((k, p) in pills.withIndex()) {
                    val on = k == sel
                    p.setTextColor(if (on) onAcc else Color.WHITE)
                    (p.background as GradientDrawable).setColor(if (on) acc else Color.argb(60, 255, 255, 255))
                }
            }
            fun makePill(i: Int, grid: Boolean): TextView {
                val p = TextView(act).apply {
                    text = sec.options[i]
                    gravity = Gravity.CENTER
                    if (grid) {
                        textSize = 12.5f
                        maxLines = 2
                        setPadding(dp(6), dp(9), dp(6), dp(9))
                    } else {
                        textSize = 14f
                        setSingleLine(true)
                        setPadding(dp(6), dp(9), dp(6), dp(9))
                    }
                    background = GradientDrawable().apply { cornerRadius = dp(16).toFloat() }
                    setOnClickListener {
                        refresh(i)
                        sec.onPick(i)
                        if (closeOnPick) pw?.dismiss()
                    }
                }
                pills.add(p)
                return p
            }

            if (columns <= 0 && sec.options.size <= 5) {
                val row = LinearLayout(act).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                if (sec.label != null) {
                    row.addView(TextView(act).apply {
                        text = sec.label
                        textSize = 13f
                        setSingleLine(true)
                        setTextColor(Color.argb(200, 255, 255, 255))
                        minWidth = dp(96)
                    })
                }
                val box = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
                for (i in sec.options.indices) {
                    val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                    box.addView(makePill(i, false), lp)
                }
                row.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                content.addView(row)
            } else {
                if (sec.label != null) {
                    content.addView(TextView(act).apply {
                        text = sec.label
                        textSize = 13f
                        setTextColor(Color.argb(200, 255, 255, 255))
                        setPadding(dp(2), dp(2), 0, dp(4))
                    })
                }
                val cols = if (columns > 0) columns else 3
                val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
                var start = 0
                while (start < sec.options.size) {
                    val r = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
                    for (c in 0 until cols) {
                        val idx = start + c
                        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                        if (idx < sec.options.size) r.addView(makePill(idx, true), lp)
                        else r.addView(View(act), lp)
                    }
                    col.addView(r)
                    start += cols
                }
                val sv = GlassDialog.MaxHeightScroll(act, (screenH * 0.45f).toInt())
                sv.isVerticalScrollBarEnabled = false
                sv.addView(col)
                content.addView(sv)
            }
            refresh(sec.selected)
        }

        content.measure(
            View.MeasureSpec.makeMeasureSpec(popupW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = content.measuredHeight
        val x = dp(12)
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val cx = loc[0] + anchor.width / 2
        val y = if (above) (loc[1] - h - dp(8)).coerceAtLeast(dp(12)) else loc[1] + anchor.height + dp(2)

        val radius = dp(22).toFloat()
        val root = FrameLayout(act).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            elevation = dp(10).toFloat()
        }
        if (frost != null) {
            val dv = act.window.decorView
            val fx = frost.width.toFloat() / dv.width.coerceAtLeast(1)
            val fy = frost.height.toFloat() / dv.height.coerceAtLeast(1)
            val left = (x * fx).toInt().coerceIn(0, frost.width - 1)
            val top = (y * fy).toInt().coerceIn(0, frost.height - 1)
            val cw = (popupW * fx).toInt().coerceIn(1, frost.width - left)
            val ch = (h * fy).toInt().coerceIn(1, frost.height - top)
            try {
                val crop = Bitmap.createBitmap(frost, left, top, cw, ch)
                root.addView(
                    ImageView(act).apply {
                        scaleType = ImageView.ScaleType.FIT_XY
                        setImageBitmap(crop)
                    },
                    FrameLayout.LayoutParams(-1, -1)
                )
            } catch (t: Throwable) { }
        }
        root.addView(
            View(act).apply { setBackgroundColor(Color.argb(if (frost != null) 105 else 235, 24, 24, 30)) },
            FrameLayout.LayoutParams(-1, -1)
        )
        root.addView(content, FrameLayout.LayoutParams(popupW, FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(
            View(act).apply {
                background = GradientDrawable().apply {
                    cornerRadius = radius
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(1), Color.argb(90, 255, 255, 255))
                }
            },
            FrameLayout.LayoutParams(-1, -1)
        )

        val popup = PopupWindow(root, popupW, h, true)
        pw = popup
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.isOutsideTouchable = true

        root.alpha = 0f
        root.scaleX = 0.9f
        root.scaleY = 0.9f
        root.pivotX = (cx - x).toFloat()
        root.pivotY = if (above) h.toFloat() else 0f
        popup.showAtLocation(act.window.decorView, Gravity.NO_GRAVITY, x, y)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200)
            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f)).start()
    }
}
