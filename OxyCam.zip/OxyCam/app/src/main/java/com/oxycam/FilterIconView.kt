package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.util.AttributeSet
import android.widget.TextView
import kotlin.math.min

/**
 * Round filter button for the right side of the viewfinder: dark translucent disc with three overlapping rings.
 * The ring colour follows the view's text colour (white normally, theme colour while a filter is active).
 * It extends TextView only so the rest of the code can keep treating it like the old top-bar button.
 */
class FilterIconView(context: Context, attrs: AttributeSet?) : TextView(context, attrs) {
    private val density = resources.displayMetrics.density
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(110, 0, 0, 0) }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
        color = Color.argb(50, 255, 255, 255)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = min(width, height) / 2f
        canvas.drawCircle(cx, cy, rad, disc)
        canvas.drawCircle(cx, cy, rad - edge.strokeWidth / 2f, edge)
        ring.color = currentTextColor
        val r = rad * 0.36f
        val d = r * 0.95f
        canvas.drawCircle(cx, cy - d * 0.62f, r, ring)
        canvas.drawCircle(cx - d * 0.7f, cy + d * 0.45f, r, ring)
        canvas.drawCircle(cx + d * 0.7f, cy + d * 0.45f, r, ring)
    }
}
