package com.oxycam

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.MediaActionSound
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        NIGHT("Night"), PORTRAIT("Portrait"), PHOTO("Photo"), VIDEO("Video"), PRO("Pro")
    }

    private val accent = Color.parseColor("#FFCC00")
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var previewView: PreviewView
    private lateinit var previewContainer: View
    private lateinit var grid: View
    private lateinit var focusRing: View
    private lateinit var countdown: TextView
    private lateinit var recTimer: TextView
    private lateinit var zoomRow: LinearLayout
    private lateinit var proPanel: LinearLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var thumb: ImageView
    private lateinit var shutterInner: View
    private lateinit var btnFlash: TextView
    private lateinit var btnHdr: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var prefs: android.content.SharedPreferences

    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recStart = 0L
    private var counting = false

    private var mode = Mode.PHOTO
    private var front = false
    private var flashMode = 0 // 0 off, 1 auto, 2 on
    private var timerSec = 0
    private var ratio43 = true
    private var hdr = false

    private var proIso = 0
    private var proShutter = 0
    private var proWb = 0
    private var proMf = 0

    private val chips = ArrayList<Pair<Float, TextView>>()
    private var zoomLive: androidx.lifecycle.LiveData<androidx.camera.core.ZoomState>? = null
    private val sound = MediaActionSound()

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPerm(Manifest.permission.CAMERA)) initCamera() else {
            toast("Camera permission is required")
        }
    }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)

        previewView = findViewById(R.id.previewView)
        previewContainer = findViewById(R.id.previewContainer)
        grid = findViewById(R.id.grid)
        focusRing = findViewById(R.id.focusRing)
        countdown = findViewById(R.id.countdown)
        recTimer = findViewById(R.id.recTimer)
        zoomRow = findViewById(R.id.zoomRow)
        proPanel = findViewById(R.id.proPanel)
        modeRow = findViewById(R.id.modeRow)
        modeScroll = findViewById(R.id.modeScroll)
        thumb = findViewById(R.id.thumb)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlash = findViewById(R.id.btnFlash)
        btnHdr = findViewById(R.id.btnHdr)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)

        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        thumb.clipToOutline = true

        grid.visibility = if (prefs.getBoolean("grid", false)) View.VISIBLE else View.GONE

        buildModeRow()
        buildProPanel()
        setupTopBar()
        setupGestures()

        findViewById<View>(R.id.shutter).setOnClickListener { shutterPressed() }
        findViewById<View>(R.id.btnFlip).setOnClickListener {
            if (recording != null) return@setOnClickListener
            front = !front
            bindCamera()
        }
        thumb.setOnClickListener { openGallery() }

        val needed = ArrayList<String>()
        needed.add(Manifest.permission.CAMERA)
        needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else if (Build.VERSION.SDK_INT <= 32) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            needed.add(Manifest.permission.READ_MEDIA_IMAGES)
            needed.add(Manifest.permission.READ_MEDIA_VIDEO)
        }
        if (needed.all { hasPerm(it) }) initCamera() else permLauncher.launch(needed.toTypedArray())
    }

    // ---------------- UI setup ----------------

    private fun buildModeRow() {
        val half = resources.displayMetrics.widthPixels / 2 - dp(36)
        modeRow.setPadding(half, 0, half, 0)
        for (m in Mode.values()) {
            val tv = TextView(this).apply {
                text = m.label
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
                tag = m
                setOnClickListener { setMode(m) }
            }
            modeRow.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }
        updateModeRow()
    }

    private fun updateModeRow() {
        for (i in 0 until modeRow.childCount) {
            val tv = modeRow.getChildAt(i) as TextView
            val sel = tv.tag == mode
            tv.setTextColor(if (sel) accent else Color.argb(180, 255, 255, 255))
            if (sel) {
                modeScroll.post {
                    modeScroll.smoothScrollTo(tv.left - (modeScroll.width - tv.width) / 2, 0)
                }
            }
        }
    }

    private fun setupTopBar() {
        btnFlash.setOnClickListener {
            flashMode = (flashMode + 1) % 3
            if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == 2)
            else imageCapture?.flashMode = flashConst()
            updateTopBar()
        }
        btnHdr.setOnClickListener {
            hdr = !hdr
            updateTopBar()
            bindCamera()
        }
        btnTimer.setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            updateTopBar()
        }
        btnRatio.setOnClickListener {
            ratio43 = !ratio43
            updateTopBar()
            bindCamera()
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        updateTopBar()
    }

    private fun updateTopBar() {
        btnFlash.text = "⚡ " + listOf("Off", "Auto", "On")[flashMode]
        btnHdr.text = "HDR " + if (hdr) "On" else "Off"
        btnHdr.visibility = if (mode == Mode.PHOTO) View.VISIBLE else View.INVISIBLE
        btnTimer.text = "⏱ " + if (timerSec == 0) "Off" else "${timerSec}s"
        btnRatio.text = if (ratio43) "4:3" else "16:9"
        btnFlash.setTextColor(if (flashMode != 0) accent else Color.WHITE)
        btnHdr.setTextColor(if (hdr) accent else Color.WHITE)
        btnTimer.setTextColor(if (timerSec != 0) accent else Color.WHITE)
    }

    private fun flashConst() = when (flashMode) {
        1 -> ImageCapture.FLASH_MODE_AUTO
        2 -> ImageCapture.FLASH_MODE_ON
        else -> ImageCapture.FLASH_MODE_OFF
    }

    private fun setMode(m: Mode) {
        if (recording != null || m == mode) return
        mode = m
        updateModeRow()
        updateTopBar()
        proPanel.visibility = if (m == Mode.PRO) View.VISIBLE else View.GONE
        shutterInner.setBackgroundResource(if (m == Mode.VIDEO) R.drawable.shutter_inner_rec else R.drawable.shutter_inner)
        bindCamera()
    }

    private fun showSettings() {
        val gridOn = prefs.getBoolean("grid", false)
        val soundOn = prefs.getBoolean("sound", true)
        val vq = prefs.getInt("vq", 1)
        val vqNames = listOf("HD 720p", "FHD 1080p", "4K (if supported)")
        val items = arrayOf(
            "Grid lines: " + if (gridOn) "On" else "Off",
            "Shutter sound: " + if (soundOn) "On" else "Off",
            "Video quality: " + vqNames[vq]
        )
        AlertDialog.Builder(this)
            .setTitle("Camera settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        prefs.edit().putBoolean("grid", !gridOn).apply()
                        grid.visibility = if (!gridOn) View.VISIBLE else View.GONE
                    }
                    1 -> prefs.edit().putBoolean("sound", !soundOn).apply()
                    2 -> {
                        prefs.edit().putInt("vq", (vq + 1) % 3).apply()
                        if (mode == Mode.VIDEO) bindCamera()
                    }
                }
                showSettings()
            }
            .setPositiveButton("Close", null)
            .show()
    }

    // ---------------- Camera ----------------

    private fun initCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                provider = f.get()
            } catch (e: Exception) {
                toast("Camera init failed: ${e.message}")
                return@addListener
            }
            try {
                val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
                ef.addListener({
                    try { extMgr = ef.get() } catch (e: Exception) { extMgr = null }
                    bindCamera()
                }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                extMgr = null
                bindCamera()
            }
        }, ContextCompat.getMainExecutor(this))
        refreshThumb()
    }

    private fun videoQuality() = when (prefs.getInt("vq", 1)) {
        0 -> Quality.HD
        2 -> Quality.UHD
        else -> Quality.FHD
    }

    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()
        val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val extId = when {
            mode == Mode.NIGHT -> ExtensionMode.NIGHT
            mode == Mode.PORTRAIT -> ExtensionMode.BOKEH
            mode == Mode.PHOTO && hdr -> ExtensionMode.HDR
            else -> -1
        }
        var selector = base
        if (extId != -1) {
            val em = extMgr
            if (em != null && em.isExtensionAvailable(base, extId)) {
                selector = em.getExtensionEnabledCameraSelector(base, extId)
            } else {
                toast("${if (mode == Mode.PHOTO) "HDR" else mode.label} is not supported by this phone's camera, using normal mode")
            }
        }
        if (!doBind(p, selector)) {
            if (selector !== base) {
                toast("Special mode failed, using normal camera")
                p.unbindAll()
                doBind(p, base)
            }
        }
        applyPro()
        buildChips()
        if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == 2)
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
    }

    private fun doBind(p: ProcessCameraProvider, selector: CameraSelector): Boolean {
        return try {
            val ar = if (ratio43) AspectRatio.RATIO_4_3 else AspectRatio.RATIO_16_9
            val preview = Preview.Builder().setTargetAspectRatio(ar).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            if (mode == Mode.VIDEO) {
                val rec = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(videoQuality(), FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                    )
                    .build()
                videoCapture = VideoCapture.withOutput(rec)
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, preview, videoCapture!!)
            } else {
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setTargetAspectRatio(ar)
                    .setFlashMode(flashConst())
                    .build()
                videoCapture = null
                camera = p.bindToLifecycle(this, selector, preview, imageCapture!!)
            }
            true
        } catch (e: Exception) {
            toast("Camera error: ${e.message}")
            false
        }
    }

    // ---------------- Zoom / focus gestures ----------------

    private fun buildChips() {
        zoomRow.removeAllViews()
        chips.clear()
        zoomLive?.removeObservers(this)
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val min = zs.minZoomRatio
        val max = zs.maxZoomRatio
        val list = ArrayList<Float>()
        for (z in listOf(0.6f, 1f, 2f, 5f, 10f)) {
            if (z >= min - 0.01f && z <= max + 0.01f) list.add(z)
        }
        if (list.isEmpty()) list.add(min)
        for (z in list) {
            val tv = TextView(this).apply {
                text = chipText(z)
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setBackgroundResource(R.drawable.chip_bg)
                setOnClickListener { cam.cameraControl.setZoomRatio(z) }
            }
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.setMargins(dp(4), 0, dp(4), 0)
            zoomRow.addView(tv, lp)
            chips.add(Pair(z, tv))
        }
        zoomLive = cam.cameraInfo.zoomState
        zoomLive?.observe(this) { s -> highlightChip(s.zoomRatio) }
    }

    private fun chipText(z: Float): String =
        if (z < 1f) ".${(z * 10).toInt()}" else if (z == z.toInt().toFloat()) "${z.toInt()}x" else String.format(Locale.US, "%.1fx", z)

    private fun highlightChip(cur: Float) {
        var sel = 0
        for (i in chips.indices) if (chips[i].first <= cur + 0.02f) sel = i
        for (i in chips.indices) {
            val (z, tv) = chips[i]
            if (i == sel) {
                tv.setTextColor(accent)
                tv.text = if (abs(cur - z) < 0.05f) chipText(z) else String.format(Locale.US, "%.1fx", cur)
            } else {
                tv.setTextColor(Color.WHITE)
                tv.text = chipText(z)
            }
        }
    }

    private fun setupGestures() {
        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val zs = cam.cameraInfo.zoomState.value ?: return true
                val target = (zs.zoomRatio * detector.scaleFactor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })
        val gestureDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > dp(80) && abs(dx) > abs(dy) * 2 && abs(vx) > 600) {
                    val all = Mode.values()
                    val idx = all.indexOf(mode) + if (dx < 0) 1 else -1
                    if (idx in all.indices) setMode(all[idx])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) gestureDet.onTouchEvent(ev)
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        } catch (e: Exception) { }
        focusRing.animate().cancel()
        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction {
                focusRing.visibility = View.INVISIBLE
                focusRing.animate().setStartDelay(0)
            }.start()
        }.start()
    }

    // ---------------- Pro mode ----------------

    private fun <T> chr(key: CameraCharacteristics.Key<T>): T? {
        val c = camera ?: return null
        return try { Camera2CameraInfo.from(c.cameraInfo).getCameraCharacteristic(key) } catch (e: Exception) { null }
    }

    private fun isoValue(p: Int): Int {
        val r = chr(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val lo = (r?.lower ?: 100).toDouble()
        val hi = minOf((r?.upper ?: 1600), 3200).toDouble()
        if (p <= 0) return 200.coerceIn(lo.toInt(), hi.toInt())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toInt()
    }

    private fun shutterValue(p: Int): Long {
        val r = chr(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val lo = maxOf(r?.lower ?: 125_000L, 125_000L).toDouble()
        val hi = minOf(r?.upper ?: 1_000_000_000L, 1_000_000_000L).toDouble()
        if (p <= 0) return 16_666_666L.coerceIn(lo.toLong(), hi.toLong())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toLong()
    }

    private fun shutterLabel(p: Int): String {
        if (p == 0) return "AUTO"
        val ns = shutterValue(p)
        return if (ns >= 500_000_000L) String.format(Locale.US, "%.1fs", ns / 1e9) else "1/${(1e9 / ns).toInt()}"
    }

    private fun buildProPanel() {
        val wbNames = listOf("AUTO", "Tungsten", "Fluoresc.", "Daylight", "Cloudy")
        addProRow("ISO", 100, { if (it == 0) "AUTO" else isoValue(it).toString() }) { proIso = it }
        addProRow("S", 100, { shutterLabel(it) }) { proShutter = it }
        addProRow("WB", 4, { wbNames[it] }) { proWb = it }
        addProRow("MF", 100, { if (it == 0) "AUTO" else "$it%" }) { proMf = it }
        addProRow("EV", 12, { String.format(Locale.US, "%+.1f", (it - 6) / 3.0) }, 6) { idx ->
            camera?.cameraControl?.setExposureCompensationIndex(
                ((idx - 6) * ((camera?.cameraInfo?.exposureState?.exposureCompensationRange?.upper ?: 6) / 6.0)).toInt()
            )
        }
    }

    private fun addProRow(label: String, max: Int, fmt: (Int) -> String, start: Int = 0, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val l = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            minWidth = dp(34)
        }
        val v = TextView(this).apply {
            text = fmt(start)
            textSize = 12f
            setTextColor(accent)
            gravity = Gravity.END
            minWidth = dp(70)
        }
        val sb = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    set(p)
                    v.text = fmt(p)
                    if (fromUser) applyPro()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        row.addView(l)
        row.addView(sb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(v)
        proPanel.addView(row)
    }

    private fun applyPro() {
        val cam = camera ?: return
        val b = CaptureRequestOptions.Builder()
        if (mode == Mode.PRO) {
            if (proIso > 0 || proShutter > 0) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue(proIso))
                b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterValue(proShutter))
            }
            if (proWb > 0) {
                val modes = intArrayOf(
                    CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
                    CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
                )
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, modes[proWb - 1])
            }
            if (proMf > 0) {
                val minFocus = chr(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
                if (minFocus > 0f) {
                    b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                    b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * proMf / 100f)
                }
            }
        }
        try {
            Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
        } catch (e: Exception) { }
    }

    // ---------------- Capture ----------------

    private fun shutterPressed() {
        if (counting) return
        if (mode == Mode.VIDEO) {
            if (recording != null) toggleRecord() else withTimer { toggleRecord() }
        } else {
            withTimer { takePhoto() }
        }
    }

    private fun withTimer(action: () -> Unit) {
        if (timerSec == 0) { action(); return }
        counting = true
        var left = timerSec
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = "$left"
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    counting = false
                    action()
                }
            }
        }
        handler.post(r)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun legacyPath(name: String): String {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Camera")
        dir.mkdirs()
        return File(dir, name).absolutePath
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val name = "IMG_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath("$name.jpg"))
        }
        val meta = ImageCapture.Metadata().apply { isReversedHorizontal = front }
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        ).setMetadata(meta).build()
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.SHUTTER_CLICK)
        ic.takePicture(opts, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { refreshThumb() }
            override fun onError(e: ImageCaptureException) { toast("Photo failed: ${e.message}") }
        })
    }

    private fun toggleRecord() {
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) {
            cur.stop()
            recording = null
            return
        }
        val name = "VID_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath("$name.mp4"))
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) pr = pr.withAudioEnabled()
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    recStart = SystemClock.elapsedRealtime()
                    recTimer.visibility = View.VISIBLE
                    tickRec()
                    shutterInner.scaleX = 0.6f
                    shutterInner.scaleY = 0.6f
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    recTimer.visibility = View.GONE
                    shutterInner.scaleX = 1f
                    shutterInner.scaleY = 1f
                    if (ev.hasError()) toast("Video error code ${ev.error}")
                    refreshThumb()
                }
                else -> {}
            }
        }
    }

    private fun tickRec() {
        if (recording == null) return
        val s = (SystemClock.elapsedRealtime() - recStart) / 1000
        recTimer.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
        handler.postDelayed({ tickRec() }, 500)
    }

    // ---------------- Gallery thumbnail ----------------

    private var lastUri: Uri? = null
    private var lastIsVideo = false

    private fun refreshThumb() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!hasPerm(Manifest.permission.READ_MEDIA_IMAGES)) return
        } else if (!hasPerm(Manifest.permission.READ_EXTERNAL_STORAGE)) return
        Thread {
            try {
                val c = contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE),
                    "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)",
                    null,
                    "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
                )
                var uri: Uri? = null
                var video = false
                c?.use {
                    if (it.moveToFirst()) {
                        val id = it.getLong(0)
                        video = it.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        uri = ContentUris.withAppendedId(
                            if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                        )
                    }
                }
                val u = uri ?: return@Thread
                val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(u, Size(256, 256), null)
                } else if (video) {
                    val m = MediaMetadataRetriever()
                    m.setDataSource(this, u)
                    val f = m.frameAtTime
                    m.release()
                    f
                } else {
                    contentResolver.openInputStream(u)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 8 })
                    }
                }
                runOnUiThread {
                    lastUri = u
                    lastIsVideo = video
                    if (bmp != null) thumb.setImageBitmap(bmp)
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun openGallery() {
        val u = lastUri ?: run { toast("No photos yet"); return }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) { toast("No gallery app found") }
    }

    override fun onStop() {
        super.onStop()
        recording?.stop()
        recording = null
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        sound.release()
    }
}
