package com.oxycam

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.ExifInterface
import android.media.MediaActionSound
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        NIGHT("Night"), PORTRAIT("Portrait"), PHOTO("Photo"), VIDEO("Video"), PRO("Pro")
    }

    private val accent = Color.parseColor("#FFCC00")
    private val handler = Handler(Looper.getMainLooper())
    private val apNames = listOf("1.4", "2.0", "2.8", "4.0")

    private lateinit var previewView: PreviewView
    private lateinit var grid: GridOverlay
    private lateinit var level: LevelView
    private lateinit var dial: ZoomDial
    private lateinit var focusRing: View
    private lateinit var countdown: TextView
    private lateinit var recTimer: TextView
    private lateinit var statusText: TextView
    private lateinit var zoomRow: LinearLayout
    private lateinit var proPanel: LinearLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var filterScroll: HorizontalScrollView
    private lateinit var filterRow: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var shutterInner: View
    private lateinit var btnFlash: TextView
    private lateinit var btnHdr: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var btnFilter: TextView
    private lateinit var prefs: android.content.SharedPreferences

    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recStart = 0L
    private var counting = false
    private var busy = false
    private var lastVq = -1

    private var mode = Mode.PHOTO
    private var front = false
    private var flashMode = 0 // 0 off, 1 auto, 2 on
    private var timerSec = 0
    private var ratio43 = true
    private var hdr = false
    private var filterIdx = 0
    private var apIdx = 1

    private var proIso = 0
    private var proShutter = 0
    private var proWb = 0
    private var proMf = 0

    private val chips = ArrayList<Pair<Float, TextView>>()
    private var selChip = 0
    private var zoomLive: androidx.lifecycle.LiveData<androidx.camera.core.ZoomState>? = null
    private val sound = MediaActionSound()
    private val hideDialRunnable = Runnable { hideDial() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPerm(Manifest.permission.CAMERA)) initCamera() else toast("Camera permission is required")
    }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)

        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        grid = findViewById(R.id.grid)
        level = findViewById(R.id.level)
        dial = findViewById(R.id.zoomDial)
        focusRing = findViewById(R.id.focusRing)
        countdown = findViewById(R.id.countdown)
        recTimer = findViewById(R.id.recTimer)
        statusText = findViewById(R.id.statusText)
        zoomRow = findViewById(R.id.zoomRow)
        proPanel = findViewById(R.id.proPanel)
        modeRow = findViewById(R.id.modeRow)
        modeScroll = findViewById(R.id.modeScroll)
        filterScroll = findViewById(R.id.filterScroll)
        filterRow = findViewById(R.id.filterRow)
        thumb = findViewById(R.id.thumb)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlash = findViewById(R.id.btnFlash)
        btnHdr = findViewById(R.id.btnHdr)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)
        btnFilter = findViewById(R.id.btnFilter)
        lastVq = prefs.getInt("vq", 1)

        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        thumb.clipToOutline = true

        dial.onZoom = { z -> camera?.cameraControl?.setZoomRatio(z) }
        dial.onTouching = { scheduleHideDial() }

        buildModeRow()
        buildProPanel()
        buildFilterRow()
        setupTopBar()
        setupGestures()

        findViewById<View>(R.id.shutter).setOnClickListener { shutterPressed() }
        findViewById<View>(R.id.btnFlip).setOnClickListener {
            if (recording != null || busy) return@setOnClickListener
            front = !front
            bindCamera()
        }
        thumb.setOnClickListener { openGallery() }

        val needed = ArrayList<String>()
        needed.add(Manifest.permission.CAMERA)
        needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else if (Build.VERSION.SDK_INT <= 32) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            needed.add(Manifest.permission.READ_MEDIA_IMAGES)
            needed.add(Manifest.permission.READ_MEDIA_VIDEO)
        }
        if (needed.all { hasPerm(it) }) initCamera() else permLauncher.launch(needed.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        grid.style = prefs.getInt("grid", 0)
        grid.visibility = if (grid.style == 0) View.GONE else View.VISIBLE
        if (prefs.getBoolean("level", false)) {
            level.visibility = View.VISIBLE
            level.start()
        } else {
            level.visibility = View.GONE
            level.stop()
        }
        val vq = prefs.getInt("vq", 1)
        if (vq != lastVq) {
            lastVq = vq
            if (mode == Mode.VIDEO && provider != null) bindCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        level.stop()
    }

    // ---------------- UI setup ----------------

    private fun buildModeRow() {
        val half = resources.displayMetrics.widthPixels / 2 - dp(36)
        modeRow.setPadding(half, 0, half, 0)
        for (m in Mode.values()) {
            val tv = TextView(this).apply {
                text = m.label
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
                tag = m
                setOnClickListener { setMode(m) }
            }
            modeRow.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT))
        }
        updateModeRow()
    }

    private fun updateModeRow() {
        for (i in 0 until modeRow.childCount) {
            val tv = modeRow.getChildAt(i) as TextView
            val sel = tv.tag == mode
            tv.setTextColor(if (sel) accent else Color.argb(180, 255, 255, 255))
            if (sel) {
                modeScroll.post {
                    modeScroll.smoothScrollTo(tv.left - (modeScroll.width - tv.width) / 2, 0)
                }
            }
        }
    }

    private fun buildFilterRow() {
        for (i in Filters.names.indices) {
            val tv = TextView(this).apply {
                text = Filters.names[i]
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundResource(R.drawable.pro_bg)
                setOnClickListener {
                    filterIdx = i
                    updateFilterRow()
                    applyFilterPreview()
                    updateTopBar()
                }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), 0, dp(4), 0)
            filterRow.addView(tv, lp)
        }
        updateFilterRow()
    }

    private fun updateFilterRow() {
        for (i in 0 until filterRow.childCount) {
            (filterRow.getChildAt(i) as TextView).setTextColor(if (i == filterIdx) accent else Color.WHITE)
        }
    }

    private fun setupTopBar() {
        btnFlash.setOnClickListener {
            flashMode = (flashMode + 1) % 3
            if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == 2)
            else imageCapture?.flashMode = flashConst()
            updateTopBar()
        }
        btnHdr.setOnClickListener {
            if (mode == Mode.PORTRAIT) {
                apIdx = (apIdx + 1) % apNames.size
                updateTopBar()
            } else {
                hdr = !hdr
                updateTopBar()
                bindCamera()
            }
        }
        btnTimer.setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            updateTopBar()
        }
        btnRatio.setOnClickListener {
            ratio43 = !ratio43
            updateTopBar()
            bindCamera()
        }
        btnFilter.setOnClickListener {
            filterScroll.visibility = if (filterScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        updateTopBar()
    }

    private fun updateTopBar() {
        btnFlash.text = "⚡ " + listOf("Off", "Auto", "On")[flashMode]
        if (mode == Mode.PORTRAIT) {
            btnHdr.text = "ƒ" + apNames[apIdx]
            btnHdr.setTextColor(accent)
        } else {
            btnHdr.text = "HDR " + if (hdr) "On" else "Off"
            btnHdr.setTextColor(if (hdr) accent else Color.WHITE)
        }
        btnHdr.visibility = if (mode == Mode.PHOTO || mode == Mode.PORTRAIT) View.VISIBLE else View.INVISIBLE
        btnTimer.text = "⏱ " + if (timerSec == 0) "Off" else "${timerSec}s"
        btnRatio.text = if (ratio43) "4:3" else "16:9"
        btnFilter.text = "◐ " + if (filterIdx == 0) "Filter" else Filters.names[filterIdx]
        btnFilter.visibility = if (mode == Mode.VIDEO) View.INVISIBLE else View.VISIBLE
        btnFlash.setTextColor(if (flashMode != 0) accent else Color.WHITE)
        btnTimer.setTextColor(if (timerSec != 0) accent else Color.WHITE)
        btnFilter.setTextColor(if (filterIdx != 0) accent else Color.WHITE)
    }

    private fun flashConst() = when (flashMode) {
        1 -> ImageCapture.FLASH_MODE_AUTO
        2 -> ImageCapture.FLASH_MODE_ON
        else -> ImageCapture.FLASH_MODE_OFF
    }

    private fun setMode(m: Mode) {
        if (recording != null || busy || m == mode) return
        mode = m
        updateModeRow()
        updateTopBar()
        if (m == Mode.VIDEO) filterScroll.visibility = View.GONE
        proPanel.visibility = if (m == Mode.PRO) View.VISIBLE else View.GONE
        shutterInner.setBackgroundResource(if (m == Mode.VIDEO) R.drawable.shutter_inner_rec else R.drawable.shutter_inner)
        bindCamera()
    }

    // ---------------- Camera ----------------

    private fun initCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                provider = f.get()
            } catch (e: Exception) {
                toast("Camera init failed: ${e.message}")
                return@addListener
            }
            try {
                val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
                ef.addListener({
                    try { extMgr = ef.get() } catch (e: Exception) { extMgr = null }
                    bindCamera()
                }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                extMgr = null
                bindCamera()
            }
        }, ContextCompat.getMainExecutor(this))
        refreshThumb()
    }

    private fun videoQuality() = when (prefs.getInt("vq", 1)) {
        0 -> Quality.HD
        2 -> Quality.UHD
        else -> Quality.FHD
    }

    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()
        val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        var selector = base
        if (mode == Mode.PHOTO && hdr) {
            val em = extMgr
            if (em != null && em.isExtensionAvailable(base, ExtensionMode.HDR)) {
                selector = em.getExtensionEnabledCameraSelector(base, ExtensionMode.HDR)
            } else {
                toast("Hardware HDR is not supported on this phone")
            }
        }
        if (!doBind(p, selector)) {
            if (selector !== base) {
                p.unbindAll()
                doBind(p, base)
            }
        }
        try {
            val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange
            camera?.cameraControl?.setExposureCompensationIndex(if (mode == Mode.NIGHT) (r?.upper ?: 0) else 0)
        } catch (e: Exception) { }
        applyPro()
        buildChips()
        if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == 2)
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        previewView.postDelayed({ applyFilterPreview() }, 200)
        previewView.postDelayed({ applyFilterPreview() }, 800)
    }

    private fun doBind(p: ProcessCameraProvider, selector: CameraSelector): Boolean {
        return try {
            val ar = if (ratio43) AspectRatio.RATIO_4_3 else AspectRatio.RATIO_16_9
            val preview = Preview.Builder().setTargetAspectRatio(ar).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            if (mode == Mode.VIDEO) {
                val rec = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(videoQuality(), FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                    )
                    .build()
                videoCapture = VideoCapture.withOutput(rec)
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, preview, videoCapture!!)
            } else {
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setTargetAspectRatio(ar)
                    .setFlashMode(if (mode == Mode.NIGHT) ImageCapture.FLASH_MODE_OFF else flashConst())
                    .build()
                videoCapture = null
                camera = p.bindToLifecycle(this, selector, preview, imageCapture!!)
            }
            true
        } catch (e: Exception) {
            toast("Camera error: ${e.message}")
            false
        }
    }

    // ---------------- Live filter preview ----------------

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val t = findTexture(v.getChildAt(i))
                if (t != null) return t
            }
        }
        return null
    }

    private fun applyFilterPreview() {
        val tv = findTexture(previewView) ?: return
        val m = if (mode == Mode.VIDEO) null else Filters.matrix(filterIdx)
        if (m == null) {
            tv.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            tv.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        }
    }

    // ---------------- Zoom chips / wheel / gestures ----------------

    private fun buildChips() {
        zoomRow.removeAllViews()
        chips.clear()
        zoomLive?.removeObservers(this)
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val min = zs.minZoomRatio
        val max = zs.maxZoomRatio
        dial.minZ = min
        dial.maxZ = max
        val list = ArrayList<Float>()
        for (z in listOf(0.6f, 1f, 2f, 5f, 10f)) {
            if (z >= min - 0.01f && z <= max + 0.01f) list.add(z)
        }
        if (list.isEmpty()) list.add(min)
        for ((idx, z) in list.withIndex()) {
            val tv = TextView(this).apply {
                text = chipText(z)
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setBackgroundResource(R.drawable.chip_bg)
                setOnClickListener {
                    if (idx == selChip) showDial() else cam.cameraControl.setZoomRatio(z)
                }
                setOnLongClickListener { showDial(); true }
            }
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.setMargins(dp(4), 0, dp(4), 0)
            zoomRow.addView(tv, lp)
            chips.add(Pair(z, tv))
        }
        zoomLive = cam.cameraInfo.zoomState
        zoomLive?.observe(this) { s ->
            highlightChip(s.zoomRatio)
            dial.zoom = s.zoomRatio
        }
    }

    private fun chipText(z: Float): String =
        if (z < 1f) ".${(z * 10).toInt()}" else if (z == z.toInt().toFloat()) "${z.toInt()}x" else String.format(Locale.US, "%.1fx", z)

    private fun highlightChip(cur: Float) {
        var sel = 0
        for (i in chips.indices) if (chips[i].first <= cur + 0.02f) sel = i
        selChip = sel
        for (i in chips.indices) {
            val (z, tv) = chips[i]
            if (i == sel) {
                tv.setTextColor(accent)
                tv.text = if (abs(cur - z) < 0.05f) chipText(z) else String.format(Locale.US, "%.1fx", cur)
            } else {
                tv.setTextColor(Color.WHITE)
                tv.text = chipText(z)
            }
        }
    }

    private fun showDial() {
        val zs = camera?.cameraInfo?.zoomState?.value
        if (zs != null) dial.zoom = zs.zoomRatio
        zoomRow.visibility = View.INVISIBLE
        dial.visibility = View.VISIBLE
        scheduleHideDial()
    }

    private fun hideDial() {
        dial.visibility = View.GONE
        zoomRow.visibility = View.VISIBLE
    }

    private fun scheduleHideDial() {
        handler.removeCallbacks(hideDialRunnable)
        handler.postDelayed(hideDialRunnable, 2500)
    }

    private fun zoomStep(up: Boolean) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val t = (zs.zoomRatio * (if (up) 1.25f else 0.8f)).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        cam.cameraControl.setZoomRatio(t)
        showDial()
    }

    private fun setupGestures() {
        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val zs = cam.cameraInfo.zoomState.value ?: return true
                val target = (zs.zoomRatio * detector.scaleFactor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })
        val gestureDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > dp(80) && abs(dx) > abs(dy) * 2 && abs(vx) > 600) {
                    val all = Mode.values()
                    val idx = all.indexOf(mode) + if (dx < 0) 1 else -1
                    if (idx in all.indices) setMode(all[idx])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) gestureDet.onTouchEvent(ev)
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        } catch (e: Exception) { }
        focusRing.animate().cancel()
        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction {
                focusRing.visibility = View.INVISIBLE
                focusRing.animate().setStartDelay(0)
            }.start()
        }.start()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (prefs.getInt("volkey", 0)) {
                0 -> {
                    if (event?.repeatCount == 0) shutterPressed()
                    return true
                }
                1 -> {
                    zoomStep(keyCode == KeyEvent.KEYCODE_VOLUME_UP)
                    return true
                }
                3 -> return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------- Pro mode + night camera tuning ----------------

    private fun <T> chr(key: CameraCharacteristics.Key<T>): T? {
        val c = camera ?: return null
        return try { Camera2CameraInfo.from(c.cameraInfo).getCameraCharacteristic(key) } catch (e: Exception) { null }
    }

    private fun isoValue(p: Int): Int {
        val r = chr(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val lo = (r?.lower ?: 100).toDouble()
        val hi = minOf((r?.upper ?: 1600), 3200).toDouble()
        if (p <= 0) return 200.coerceIn(lo.toInt(), hi.toInt())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toInt()
    }

    private fun shutterValue(p: Int): Long {
        val r = chr(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val lo = maxOf(r?.lower ?: 125_000L, 125_000L).toDouble()
        val hi = minOf(r?.upper ?: 1_000_000_000L, 1_000_000_000L).toDouble()
        if (p <= 0) return 16_666_666L.coerceIn(lo.toLong(), hi.toLong())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toLong()
    }

    private fun shutterLabel(p: Int): String {
        if (p == 0) return "AUTO"
        val ns = shutterValue(p)
        return if (ns >= 500_000_000L) String.format(Locale.US, "%.1fs", ns / 1e9) else "1/${(1e9 / ns).toInt()}"
    }

    private fun buildProPanel() {
        val wbNames = listOf("AUTO", "Tungsten", "Fluoresc.", "Daylight", "Cloudy")
        addProRow("ISO", 100, { if (it == 0) "AUTO" else isoValue(it).toString() }) { proIso = it }
        addProRow("S", 100, { shutterLabel(it) }) { proShutter = it }
        addProRow("WB", 4, { wbNames[it] }) { proWb = it }
        addProRow("MF", 100, { if (it == 0) "AUTO" else "$it%" }) { proMf = it }
        addProRow("EV", 12, { String.format(Locale.US, "%+.1f", (it - 6) / 3.0) }, 6) { idx ->
            camera?.cameraControl?.setExposureCompensationIndex(
                ((idx - 6) * ((camera?.cameraInfo?.exposureState?.exposureCompensationRange?.upper ?: 6) / 6.0)).toInt()
            )
        }
    }

    private fun addProRow(label: String, max: Int, fmt: (Int) -> String, start: Int = 0, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val l = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            minWidth = dp(34)
        }
        val v = TextView(this).apply {
            text = fmt(start)
            textSize = 12f
            setTextColor(accent)
            gravity = Gravity.END
            minWidth = dp(70)
        }
        val sb = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    set(p)
                    v.text = fmt(p)
                    if (fromUser) applyPro()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        row.addView(l)
        row.addView(sb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(v)
        proPanel.addView(row)
    }

    private fun applyPro() {
        val cam = camera ?: return
        val b = CaptureRequestOptions.Builder()
        if (mode == Mode.NIGHT) {
            // allow long exposures: pick the slowest frame-rate range the sensor offers
            val ranges = chr(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val slow = ranges?.minWithOrNull(compareBy<android.util.Range<Int>>({ it.upper }, { it.lower }))
            if (slow != null) b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, slow)
        }
        if (mode == Mode.PRO) {
            if (proIso > 0 || proShutter > 0) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue(proIso))
                b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterValue(proShutter))
            }
            if (proWb > 0) {
                val modes = intArrayOf(
                    CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
                    CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
                )
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, modes[proWb - 1])
            }
            if (proMf > 0) {
                val minFocus = chr(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
                if (minFocus > 0f) {
                    b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                    b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * proMf / 100f)
                }
            }
        }
        try {
            Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
        } catch (e: Exception) { }
    }

    // ---------------- Capture ----------------

    private fun shutterPressed() {
        if (counting || busy) return
        if (mode == Mode.VIDEO) {
            if (recording != null) toggleRecord() else withTimer { toggleRecord() }
        } else {
            withTimer { takePhoto() }
        }
    }

    private fun withTimer(action: () -> Unit) {
        if (timerSec == 0) { action(); return }
        counting = true
        var left = timerSec
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = "$left"
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    counting = false
                    action()
                }
            }
        }
        handler.post(r)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun legacyPath(name: String): String {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Camera")
        dir.mkdirs()
        return File(dir, name).absolutePath
    }

    private fun setStatus(t: String?) {
        if (t == null) statusText.visibility = View.GONE
        else {
            statusText.text = t
            statusText.visibility = View.VISIBLE
        }
    }

    private fun takePhoto() {
        val m = mode
        val n = if (m == Mode.NIGHT) 5 else 1
        busy = true
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.SHUTTER_CLICK)
        val filter = filterIdx
        val ap = apIdx
        val wm = prefs.getInt("watermark", 0)
        captureSeq(n, 0, ArrayList()) { files ->
            val heavy = m == Mode.PORTRAIT || m == Mode.NIGHT || filter != 0 || wm != 0
            if (heavy) setStatus(if (m == Mode.NIGHT) "Processing night shot…" else "Processing…") else busy = false
            runPipeline(files, m, filter, wm, ap)
        }
    }

    private fun captureSeq(n: Int, i: Int, files: ArrayList<File>, done: (List<File>) -> Unit) {
        val ic = imageCapture
        if (ic == null) {
            busy = false
            setStatus(null)
            return
        }
        val f = File(cacheDir, "frame_${System.currentTimeMillis()}_$i.jpg")
        val meta = ImageCapture.Metadata().apply { isReversedHorizontal = front && prefs.getBoolean("mirror", true) }
        if (n > 1) setStatus("Hold still… ${i + 1}/$n")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).setMetadata(meta).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    files.add(f)
                    if (i + 1 < n) captureSeq(n, i + 1, files, done) else done(files)
                }

                override fun onError(e: ImageCaptureException) {
                    toast("Photo failed: ${e.message}")
                    if (files.isNotEmpty()) done(files) else {
                        busy = false
                        setStatus(null)
                    }
                }
            })
    }

    private fun newImageUri(): Uri? {
        val name = "IMG_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath("$name.jpg"))
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
    }

    private fun runPipeline(files: List<File>, m: Mode, filter: Int, wm: Int, ap: Int) {
        Thread {
            try {
                val uri = newImageUri() ?: throw IllegalStateException("cannot create file")
                val plain = (m == Mode.PHOTO || m == Mode.PRO) && filter == 0 && wm == 0
                if (plain) {
                    contentResolver.openOutputStream(uri)!!.use { o ->
                        files[0].inputStream().use { it.copyTo(o) }
                    }
                } else {
                    var extra: ColorMatrix? = null
                    var bmp: Bitmap = when (m) {
                        Mode.PORTRAIT -> portrait(files[0], ap)
                        Mode.NIGHT -> {
                            extra = Filters.cm(sat = 1.12f, contrast = 1.04f)
                            night(files)
                        }
                        else -> decodeUpright(files[0], 4200)
                    }
                    bmp = finish(bmp, filter, wm, extra)
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    bmp.recycle()
                }
                files.forEach { it.delete() }
                runOnUiThread {
                    busy = false
                    setStatus(null)
                    refreshThumb()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    busy = false
                    setStatus(null)
                    toast("Processing failed: ${t.message}")
                }
            }
        }.start()
    }

    // ---------------- Image processing (portrait / night / filters) ----------------

    private fun decodeUpright(f: File, maxSide: Int): Bitmap {
        var bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inMutable = true })
            ?: throw IllegalStateException("decode failed")
        val ori = ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val mtx = Matrix()
        when (ori) {
            ExifInterface.ORIENTATION_ROTATE_90 -> mtx.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> mtx.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> mtx.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> mtx.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> mtx.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
        }
        val sc = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
        if (sc < 1f) mtx.postScale(sc, sc)
        if (!mtx.isIdentity) {
            val nb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mtx, true)
            if (nb !== bmp) bmp.recycle()
            bmp = nb
        }
        if (!bmp.isMutable || bmp.config != Bitmap.Config.ARGB_8888) {
            val c = bmp.copy(Bitmap.Config.ARGB_8888, true)
            bmp.recycle()
            bmp = c
        }
        return bmp
    }

    private fun finish(src: Bitmap, filter: Int, wm: Int, extra: ColorMatrix?): Bitmap {
        var out = src
        val fm = Filters.matrix(filter)
        val m: ColorMatrix? = when {
            fm != null && extra != null -> ColorMatrix(extra).also { it.postConcat(fm) }
            fm != null -> fm
            else -> extra
        }
        if (m != null) {
            val o = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
            Canvas(o).drawBitmap(out, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
            out.recycle()
            out = o
        }
        if (wm > 0) {
            if (!out.isMutable) out = out.copy(Bitmap.Config.ARGB_8888, true)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = out.width / 38f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setShadowLayer(out.width / 300f, 0f, 0f, Color.BLACK)
            }
            var t = "Shot on ${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
            if (wm == 2) t += "  •  " + SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.US).format(Date())
            c.drawText(t, out.width / 2f, out.height - out.width * 0.04f, p)
        }
        return out
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun boxBlur(src: IntArray, w: Int, h: Int, r: Int): IntArray {
        var a = src.copyOf()
        val b = IntArray(w * h)
        val d = 2 * r + 1
        repeat(2) {
            for (y in 0 until h) {
                val row = y * w
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) {
                    val p = a[row + i.coerceIn(0, w - 1)]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                }
                for (x in 0 until w) {
                    b[row + x] = (255 shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                    val add = a[row + minOf(x + r + 1, w - 1)]
                    val rem = a[row + maxOf(x - r, 0)]
                    sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                    sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) {
                    val p = b[i.coerceIn(0, h - 1) * w + x]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                }
                for (y in 0 until h) {
                    a[y * w + x] = (255 shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                    val add = b[minOf(y + r + 1, h - 1) * w + x]
                    val rem = b[maxOf(y - r, 0) * w + x]
                    sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                    sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
        }
        return a
    }

    /** Software portrait: person mask from ML Kit selfie segmentation (or a centre spot as fallback) + background blur. */
    private fun portrait(f: File, apI: Int): Bitmap {
        val bmp = decodeUpright(f, 3200)
        val w = bmp.width
        val h = bmp.height

        // 1) foreground mask
        var mask: FloatArray? = null
        var mw = 0
        var mh = 0
        try {
            val sc = 640f / maxOf(w, h)
            val small = Bitmap.createScaledBitmap(bmp, (w * sc).toInt(), (h * sc).toInt(), true)
            val seg = Segmentation.getClient(
                SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
            )
            val res = Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
            val buf = res.buffer
            buf.rewind()
            mw = res.width
            mh = res.height
            val m = FloatArray(mw * mh)
            var cnt = 0
            for (i in m.indices) {
                m[i] = buf.float
                if (m[i] > 0.5f) cnt++
            }
            seg.close()
            small.recycle()
            val cover = cnt.toFloat() / m.size
            if (cover in 0.03f..0.92f) mask = m
        } catch (t: Throwable) {
            mask = null
        }

        // 2) blurred background
        val bs = maxOf(w / 8, 16)
        val bh = maxOf(h * bs / w, 16)
        val sm = Bitmap.createScaledBitmap(bmp, bs, bh, true)
        val smPx = IntArray(bs * bh)
        sm.getPixels(smPx, 0, bs, 0, 0, bs, bh)
        sm.recycle()
        val radius = intArrayOf(10, 7, 5, 3)[apI.coerceIn(0, 3)]
        val blurredSmall = boxBlur(smPx, bs, bh, radius)
        val bb = Bitmap.createBitmap(bs, bh, Bitmap.Config.ARGB_8888)
        bb.setPixels(blurredSmall, 0, bs, 0, 0, bs, bh)
        val bigBlur = Bitmap.createScaledBitmap(bb, w, h, true)
        bb.recycle()
        val bl = IntArray(w * h)
        bigBlur.getPixels(bl, 0, w, 0, 0, w, h)
        bigBlur.recycle()
        val arr = IntArray(w * h)
        bmp.getPixels(arr, 0, w, 0, 0, w, h)

        // 3) composite
        val m = mask
        for (y in 0 until h) {
            val ny = (y - h / 2f) / (h / 2f)
            var y0 = 0; var y1 = 0; var ty = 0f
            if (m != null) {
                val fy = y * (mh - 1f) / (h - 1f)
                y0 = fy.toInt(); y1 = minOf(y0 + 1, mh - 1); ty = fy - y0
            }
            for (x in 0 until w) {
                val a: Float
                if (m != null) {
                    val fx = x * (mw - 1f) / (w - 1f)
                    val x0 = fx.toInt()
                    val x1 = minOf(x0 + 1, mw - 1)
                    val tx = fx - x0
                    val top = m[y0 * mw + x0] * (1 - tx) + m[y0 * mw + x1] * tx
                    val bot = m[y1 * mw + x0] * (1 - tx) + m[y1 * mw + x1] * tx
                    a = smooth(0.3f, 0.7f, top * (1 - ty) + bot * ty)
                } else {
                    val nx = (x - w / 2f) / (w / 2f)
                    a = 1f - smooth(0.35f, 0.9f, sqrt(nx * nx + ny * ny))
                }
                val i = y * w + x
                if (a >= 0.99f) continue
                if (a <= 0.01f) { arr[i] = bl[i]; continue }
                val p = arr[i]
                val q = bl[i]
                val r = (((p shr 16) and 255) * a + ((q shr 16) and 255) * (1 - a)).toInt()
                val g = (((p shr 8) and 255) * a + ((q shr 8) and 255) * (1 - a)).toInt()
                val b = ((p and 255) * a + (q and 255) * (1 - a)).toInt()
                arr[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bmp.setPixels(arr, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Software night mode: average several frames (less noise) taken with long exposure + bright tone curve. */
    private fun night(files: List<File>): Bitmap {
        val base = decodeUpright(files[0], 3200)
        val w = base.width
        val h = base.height
        val avg = IntArray(w * h)
        base.getPixels(avg, 0, w, 0, 0, w, h)
        var n = 1
        for (i in 1 until files.size) {
            val b = try { decodeUpright(files[i], 3200) } catch (t: Throwable) { continue }
            if (b.width != w || b.height != h) { b.recycle(); continue }
            val px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            b.recycle()
            n++
            for (k in px.indices) {
                val a = avg[k]
                val c = px[k]
                val r = ((((a shr 16) and 255) * (n - 1)) + ((c shr 16) and 255)) / n
                val g = ((((a shr 8) and 255) * (n - 1)) + ((c shr 8) and 255)) / n
                val bl = (((a and 255) * (n - 1)) + (c and 255)) / n
                avg[k] = (255 shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        val lut = IntArray(256) { i ->
            val x = i / 255.0
            var y = x.pow(0.62)
            y = (y - 0.5) * 1.06 + 0.5
            (y * 255.0).toInt().coerceIn(0, 255)
        }
        for (k in avg.indices) {
            val a = avg[k]
            avg[k] = (255 shl 24) or (lut[(a shr 16) and 255] shl 16) or (lut[(a shr 8) and 255] shl 8) or lut[a and 255]
        }
        base.setPixels(avg, 0, w, 0, 0, w, h)
        return base
    }

    // ---------------- Video ----------------

    private fun toggleRecord() {
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) {
            cur.stop()
            recording = null
            return
        }
        val name = "VID_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath("$name.mp4"))
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) pr = pr.withAudioEnabled()
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    recStart = SystemClock.elapsedRealtime()
                    recTimer.visibility = View.VISIBLE
                    tickRec()
                    shutterInner.scaleX = 0.6f
                    shutterInner.scaleY = 0.6f
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    recTimer.visibility = View.GONE
                    shutterInner.scaleX = 1f
                    shutterInner.scaleY = 1f
                    if (ev.hasError()) toast("Video error code ${ev.error}")
                    refreshThumb()
                }
                else -> {}
            }
        }
    }

    private fun tickRec() {
        if (recording == null) return
        val s = (SystemClock.elapsedRealtime() - recStart) / 1000
        recTimer.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
        handler.postDelayed({ tickRec() }, 500)
    }

    // ---------------- Gallery thumbnail ----------------

    private var lastUri: Uri? = null
    private var lastIsVideo = false

    private fun refreshThumb() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!hasPerm(Manifest.permission.READ_MEDIA_IMAGES)) return
        } else if (!hasPerm(Manifest.permission.READ_EXTERNAL_STORAGE)) return
        Thread {
            try {
                val c = contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE),
                    "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)",
                    null,
                    "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
                )
                var uri: Uri? = null
                var video = false
                c?.use {
                    if (it.moveToFirst()) {
                        val id = it.getLong(0)
                        video = it.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        uri = ContentUris.withAppendedId(
                            if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                        )
                    }
                }
                val u = uri ?: return@Thread
                val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(u, Size(256, 256), null)
                } else if (video) {
                    val m = MediaMetadataRetriever()
                    m.setDataSource(this, u)
                    val fr = m.frameAtTime
                    m.release()
                    fr
                } else {
                    contentResolver.openInputStream(u)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 8 })
                    }
                }
                runOnUiThread {
                    lastUri = u
                    lastIsVideo = video
                    if (bmp != null) thumb.setImageBitmap(bmp)
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun openGallery() {
        val u = lastUri ?: run { toast("No photos yet"); return }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) { toast("No gallery app found") }
    }

    override fun onStop() {
        super.onStop()
        recording?.stop()
        recording = null
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        sound.release()
    }
}
