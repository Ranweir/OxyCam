package com.oxycam

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.Rect
import android.graphics.Paint
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.location.Location
import android.location.LocationManager
import android.media.ExifInterface
import android.media.MediaActionSound
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Choreographer
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String, val more: Boolean = false) {
        NIGHT("Night"), PORTRAIT("Portrait"), PHOTO("Photo"), VIDEO("Video"), PRO("Pro"),
        AI("AI Camera", true), ULTRA("UltraHD", true), XPAN("XPAN", true), MDR("MDR", true)
    }

    private val mainModes = listOf(Mode.PRO, Mode.VIDEO, Mode.PHOTO, Mode.PORTRAIT, Mode.NIGHT)
    private var accent = Color.parseColor("#FFCC00")
    private val handler = Handler(Looper.getMainLooper())
    private val apNames = listOf("1.4", "2.0", "2.8", "4.0")
    private val ratioNames = listOf("4:3", "1:1", "16:9", "Full")

    private lateinit var previewView: PreviewView
    private lateinit var previewContainer: FrameLayout
    private lateinit var grid: GridOverlay
    private lateinit var analysis: AnalysisOverlay
    private lateinit var level: LevelView
    private lateinit var dial: ZoomDial
    private lateinit var focusRing: View
    private lateinit var countdown: TextView
    private lateinit var recTimer: TextView
    private lateinit var statusText: TextView
    private lateinit var zoomRow: LinearLayout
    private lateinit var proPanel: LinearLayout
    private lateinit var modeRow: LinearLayout
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var filterScroll: HorizontalScrollView
    private lateinit var filterRow: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var filterStrip: FilterStrip
    private var stripBmp: Bitmap? = null
    private lateinit var shutterInner: View
    private lateinit var btnFlash: TextView
    private lateinit var btnHdr: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var btnFilter: TextView
    private lateinit var hsPreview: TextureView
    private lateinit var prefs: android.content.SharedPreferences

    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recStart = 0L
    private var counting = false
    private var busy = false
    private var lastVq = -1
    private var lastFps = 1
    private var lastKey = ""
    private var lastStab = 0
    private var lastVolDown = 0L
    private var askedLoc = false
    private var lastBindError = ""

    private var mode = Mode.PHOTO
    private var front = false
    private var flashMode = 0 // 0 off, 1 auto, 2 on
    private var timerSec = 0
    private var ratioMode = 0 // 0 4:3, 1 1:1, 2 16:9, 3 full
    private var hdr = false
    private var filterIdx = 0
    private var apIdx = 1

    private var proIso = 0
    private var proShutter = 0
    private var proWb = 0
    private var proMf = 0

    private val chips = ArrayList<Pair<Float, TextView>>()
    private var selChip = 0
    private var zoomLive: androidx.lifecycle.LiveData<androidx.camera.core.ZoomState>? = null
    private val sound = MediaActionSound()
    private val hideDialRunnable = Runnable { hideDial() }
    private val analysisExec = Executors.newSingleThreadExecutor()

    private class Job(
        val files: List<File>, val mode: Mode, val look: Int, val wm: Int, val wmText: String,
        val cropHW: Float?, val loc: Location?, val ap: Int, val aiBoost: Boolean, val sharp: Float
    )

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPerm(Manifest.permission.CAMERA)) initCamera() else toast("Camera permission is required")
    }
    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun themeColor(): Int = ThemeColors.color(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)
        accent = themeColor()
        ratioMode = prefs.getInt("ratio", 0)

        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewContainer = findViewById(R.id.previewContainer)
        grid = findViewById(R.id.grid)
        analysis = findViewById(R.id.analysis)
        level = findViewById(R.id.level)
        dial = findViewById(R.id.zoomDial)
        focusRing = findViewById(R.id.focusRing)
        countdown = findViewById(R.id.countdown)
        recTimer = findViewById(R.id.recTimer)
        statusText = findViewById(R.id.statusText)
        zoomRow = findViewById(R.id.zoomRow)
        proPanel = findViewById(R.id.proPanel)
        modeRow = findViewById(R.id.modeRow)
        modeScroll = findViewById(R.id.modeScroll)
        filterScroll = findViewById(R.id.filterScroll)
        filterRow = findViewById(R.id.filterRow)
        thumb = findViewById(R.id.thumb)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlash = findViewById(R.id.btnFlash)
        btnHdr = findViewById(R.id.btnHdr)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)
        btnFilter = findViewById(R.id.btnFilter)
        lastVq = prefs.getInt("vq", 1)
        lastFps = fpsIdx()
        hsPreview = findViewById(R.id.hsPreview)

        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
            }
        }
        thumb.clipToOutline = true

        dial.onZoom = { z ->
            stopSmoothZoom()
            camera?.cameraControl?.setZoomRatio(z)
        }
        dial.onTouching = { scheduleHideDial() }

        buildModeRow()
        buildProPanel()
        buildFilterRow()
        filterStrip = FilterStrip(this)
        filterStrip.visibility = View.GONE
        filterStrip.onSelect = { i ->
            filterIdx = i
            applyFilterPreview()
            updateTopBar()
        }
        val stripLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(122))
        stripLp.setMargins(dp(10), 0, dp(10), dp(8))
        (filterScroll.parent as LinearLayout).addView(filterStrip, 0, stripLp)
        setupTopBar()
        setupGestures()

        findViewById<View>(R.id.shutter).setOnClickListener { shutterPressed() }
        findViewById<View>(R.id.btnFlip).setOnClickListener {
            if (recording != null || hsActive || busy) return@setOnClickListener
            front = !front
            bindCamera()
        }
        thumb.setOnClickListener { openGallery() }

        val needed = ArrayList<String>()
        needed.add(Manifest.permission.CAMERA)
        needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else if (Build.VERSION.SDK_INT <= 32) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            needed.add(Manifest.permission.READ_MEDIA_IMAGES)
            needed.add(Manifest.permission.READ_MEDIA_VIDEO)
        }
        if (needed.all { hasPerm(it) }) initCamera() else permLauncher.launch(needed.toTypedArray())
    }

    private fun analysisKey() =
        "${prefs.getBoolean("hist", false)}${prefs.getBoolean("zebra", false)}${prefs.getBoolean("peak", false)}"

    override fun onResume() {
        super.onResume()
        accent = themeColor()
        dial.setAccent(accent)
        statusText.setTextColor(accent)
        updateModeRow()
        updateShutterStyle()
        updateTopBar()
        updateFilterRow()
        lastChipKey = -1
        camera?.cameraInfo?.zoomState?.value?.let { highlightChip(it.zoomRatio) }

        grid.style = prefs.getInt("grid", 0)
        grid.visibility = if (grid.style == 0) View.GONE else View.VISIBLE
        if (prefs.getBoolean("level", false)) {
            level.visibility = View.VISIBLE
            level.start()
        } else {
            level.visibility = View.GONE
            level.stop()
        }
        analysis.showHist = prefs.getBoolean("hist", false)
        analysis.showZebra = prefs.getBoolean("zebra", false)
        analysis.showPeak = prefs.getBoolean("peak", false)

        if (prefs.getBoolean("geotag", false) && !hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) && !askedLoc) {
            askedLoc = true
            locLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        var rebind = false
        val vq = prefs.getInt("vq", 1)
        if (vq != lastVq) {
            lastVq = vq
            if (mode == Mode.VIDEO) rebind = true
        }
        val fi = fpsIdx()
        if (fi != lastFps) {
            lastFps = fi
            if (mode == Mode.VIDEO) rebind = true
        }
        val r = prefs.getInt("ratio", 0)
        if (r != ratioMode) {
            ratioMode = r
            updateTopBar()
            rebind = true
        }
        val sk = prefs.getInt("stabmode", 0)
        if (sk != lastStab) {
            lastStab = sk
        }
        val k = analysisKey()
        if (k != lastKey) {
            lastKey = k
            if (mode == Mode.PRO) rebind = true
        }
        if (rebind && provider != null && !busy && recording == null && !hsActive) bindCamera() else applyPro()
    }

    override fun onPause() {
        super.onPause()
        hideFilterStrip()
        level.stop()
    }

    // ---------------- UI setup ----------------

    private var photoTab: TextView? = null

    private fun buildModeRow() {
        for (m in mainModes) {
            val tv = TextView(this).apply {
                textSize = 13.5f
                gravity = Gravity.CENTER
                setPadding(dp(13), 0, dp(13), 0)
                tag = m
                setOnClickListener { onModeTab(m) }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38))
            lp.setMargins(dp(2), 0, dp(2), 0)
            modeRow.addView(tv, lp)
            if (m == Mode.PHOTO) photoTab = tv
        }
        updateModeRow()
        updateShutterStyle()
    }

    /** Photo tab: first tap selects Photo; when Photo (or one of its extra modes) is active, tapping it opens the extra modes. */
    private fun onModeTab(m: Mode) {
        if (m == Mode.PHOTO && (mode == Mode.PHOTO || mode.more)) showPhotoModes() else setMode(m)
    }

    private fun showPhotoModes() {
        val anchor = photoTab ?: return
        if (recording != null || busy) return
        val names = listOf("Photo", "AI Camera", "UltraHD", "XPAN", "MDR")
        val modes = listOf(Mode.PHOTO, Mode.AI, Mode.ULTRA, Mode.XPAN, Mode.MDR)
        popupShow(
            this, anchor,
            listOf(TopPopup.Section("Photo modes", names, modes.indexOf(mode).coerceAtLeast(0)) { i -> setMode(modes[i]) }),
            true, true, 3
        )
    }

    private fun updateModeRow() {
        for (i in 0 until modeRow.childCount) {
            val tv = modeRow.getChildAt(i) as TextView
            val m = tv.tag as Mode
            val isPhotoTab = m == Mode.PHOTO
            val sel = m == mode || (isPhotoTab && mode.more)
            val name = if (isPhotoTab && mode.more) mode.label else m.label
            tv.text = name.uppercase() + if (isPhotoTab && sel) "  ▲" else ""
            tv.setTextColor(if (sel) accent else Color.WHITE)
            tv.background = if (sel) GradientDrawable().apply {
                cornerRadius = dp(19).toFloat()
                setColor(Color.argb(255, 42, 42, 46))
            } else null
            if (sel) {
                modeScroll.post {
                    modeScroll.smoothScrollTo(tv.left - (modeScroll.width - tv.width) / 2, 0)
                }
            }
        }
    }

    /** Shutter: white ring with a filled centre in the accent colour (red for video). */
    private fun updateShutterStyle() {
        val c = if (mode == Mode.VIDEO) Color.parseColor("#FF3B30") else accent
        shutterInner.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c)
        }
    }

    private fun buildFilterRow() {
        for (i in Filters.names.indices) {
            val tv = TextView(this).apply {
                text = Filters.names[i]
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundResource(R.drawable.pro_bg)
                setOnClickListener {
                    filterIdx = i
                    updateFilterRow()
                    applyFilterPreview()
                    updateTopBar()
                }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), 0, dp(4), 0)
            filterRow.addView(tv, lp)
        }
        updateFilterRow()
    }

    private fun updateFilterRow() {
        for (i in 0 until filterRow.childCount) {
            (filterRow.getChildAt(i) as TextView).setTextColor(if (i == filterIdx) accent else Color.WHITE)
        }
    }

    // ---- live filter strip ----
    private val stripTick = object : Runnable {
        override fun run() {
            if (filterStrip.visibility != View.VISIBLE) return
            updateStripFrames()
            handler.postDelayed(this, 110)
        }
    }

    private fun showFilterStrip() {
        filterStrip.show(filterIdx, accent)
        handler.removeCallbacks(stripTick)
        handler.post(stripTick)
    }

    private fun hideFilterStrip() {
        handler.removeCallbacks(stripTick)
        if (this::filterStrip.isInitialized) filterStrip.hide()
    }

    private fun updateStripFrames() {
        val tv = findTexture(previewView) ?: return
        if (tv.width == 0 || tv.height == 0) return
        val w = 96
        val h = (96f * tv.height / tv.width).toInt().coerceAtLeast(16)
        var b = stripBmp
        if (b == null || b.width != w || b.height != h) {
            b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            stripBmp = b
            filterStrip.setSource(b)
        }
        try {
            tv.getBitmap(b)
        } catch (t: Throwable) {
            return
        }
        val a = IntArray(2)
        val c = IntArray(2)
        filterStrip.getLocationOnScreen(a)
        tv.getLocationOnScreen(c)
        val fx0 = (a[0] - c[0]).toFloat() / tv.width
        val fy0 = (a[1] - c[1]).toFloat() / tv.height
        filterStrip.frameUpdated(b, fx0, fy0, fx0 + filterStrip.width.toFloat() / tv.width, fy0 + filterStrip.height.toFloat() / tv.height)
    }

    private fun popupShow(
        act: android.app.Activity, anchor: View, sections: List<TopPopup.Section>, closeOnPick: Boolean,
        above: Boolean = false, columns: Int = 0
    ) {
        hideFilterStrip()
        TopPopup.show(act, anchor, sections, closeOnPick, previewView, above, columns)
    }

    private fun setupTopBar() {
        btnFlash.setOnClickListener {
            val vid = mode == Mode.VIDEO
            val opts = if (vid) listOf("Off", "On") else listOf("Off", "Auto", "On")
            val sel = if (vid) (if (flashMode == 2) 1 else 0) else flashMode
            popupShow(this, btnFlash, listOf(TopPopup.Section("Flash", opts, sel) { i ->
                flashMode = if (vid) (if (i == 1) 2 else 0) else i
                if (vid) camera?.cameraControl?.enableTorch(flashMode == 2)
                else imageCapture?.flashMode = flashConst()
                updateTopBar()
            }), true)
        }
        btnHdr.setOnClickListener {
            when (mode) {
                Mode.VIDEO -> {
                    if (recording != null || hsActive) return@setOnClickListener
                    val vq = prefs.getInt("vq", 1).coerceIn(0, 2)
                    val fpsSel = if (effFps() >= 60) 0 else 1
                    popupShow(
                        this, btnHdr, listOf(
                            TopPopup.Section("Quality", listOf("720", "1080", "4K"), vq) { i ->
                                setQuality(i)
                            },
                            TopPopup.Section("FPS", listOf("60", "30"), fpsSel) { i ->
                                setFps(if (i == 0) 60 else 30)
                            }
                        ), false
                    )
                }
                Mode.PORTRAIT -> {
                    popupShow(
                        this, btnHdr,
                        listOf(TopPopup.Section("Aperture", apNames.map { "ƒ$it" }, apIdx) { i ->
                            apIdx = i
                            updateTopBar()
                        }), true
                    )
                }
                else -> {
                    popupShow(
                        this, btnHdr,
                        listOf(TopPopup.Section("HDR", listOf("Off", "On"), if (hdr) 1 else 0) { i ->
                            hdr = i == 1
                            updateTopBar()
                            bindCamera()
                        }), true
                    )
                }
            }
        }
        btnTimer.setOnClickListener {
            if (mode == Mode.VIDEO) {
                if (recording != null) return@setOnClickListener
                popupShow(
                    this, btnTimer,
                    listOf(TopPopup.Section("Gyro EIS", listOf("Off", "GYRO", "GYRO+", "GYRO++"), prefs.getInt("stabmode", 0)) { i ->
                        prefs.edit().putInt("stabmode", i).apply()
                        updateTopBar()
                        if (i > 0 && front) toast("Gyro stabilisation works with the rear camera only")
                    }), true
                )
            } else {
                val cur = when (timerSec) { 3 -> 1; 10 -> 2; else -> 0 }
                popupShow(
                    this, btnTimer,
                    listOf(TopPopup.Section("Timer", listOf("Off", "3s", "10s"), cur) { i ->
                        timerSec = when (i) { 1 -> 3; 2 -> 10; else -> 0 }
                        updateTopBar()
                    }), true
                )
            }
        }
        btnRatio.setOnClickListener {
            if (mode == Mode.XPAN) {
                toast("XPAN uses a fixed 65:24 frame")
                return@setOnClickListener
            }
            if (busy || recording != null) return@setOnClickListener
            popupShow(
                this, btnRatio,
                listOf(TopPopup.Section("Aspect ratio", ratioNames, ratioMode) { i ->
                    ratioMode = i
                    prefs.edit().putInt("ratio", i).apply()
                    updateTopBar()
                    bindCamera()
                }), true
            )
        }
        btnFilter.setOnClickListener {
            if (filterStrip.visibility == View.VISIBLE) hideFilterStrip() else showFilterStrip()
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        updateTopBar()
    }

    private fun updateTopBar() {
        val vid = mode == Mode.VIDEO
        btnFlash.text = "⚡ " + if (vid) (if (flashMode == 2) "On" else "Off") else listOf("Off", "Auto", "On")[flashMode]
        if (vid) {
            val fps = effFps()
            btnHdr.text = listOf("720p", "1080p", "4K")[prefs.getInt("vq", 1).coerceIn(0, 2)] + " " + fps
            btnHdr.setTextColor(accent)
        } else if (mode == Mode.PORTRAIT) {
            btnHdr.text = "ƒ" + apNames[apIdx]
            btnHdr.setTextColor(accent)
        } else {
            btnHdr.text = "HDR " + if (hdr) "On" else "Off"
            btnHdr.setTextColor(if (hdr) accent else Color.WHITE)
        }
        btnHdr.visibility = if (mode == Mode.PHOTO || mode == Mode.PORTRAIT || vid) View.VISIBLE else View.INVISIBLE
        if (vid) {
            val sm = prefs.getInt("stabmode", 0)
            btnTimer.text = if (sm == 0) "Gyro Off" else listOf("", "G-EIS", "G-EIS+", "G-EIS++")[sm]
            btnTimer.setTextColor(if (sm != 0) accent else Color.WHITE)
        } else {
            btnTimer.text = "⏱ " + if (timerSec == 0) "Off" else "${timerSec}s"
            btnTimer.setTextColor(if (timerSec != 0) accent else Color.WHITE)
        }
        btnRatio.text = if (mode == Mode.XPAN) "65:24" else ratioNames[ratioMode]
        btnRatio.visibility = if (vid) View.GONE else View.VISIBLE // video is locked to 16:9
        btnFilter.text = "◐ " + if (filterIdx == 0) "Filter" else "On"
        btnFilter.visibility = View.VISIBLE
        btnFlash.setTextColor(if (flashMode != 0) accent else Color.WHITE)
        btnFilter.setTextColor(if (filterIdx != 0) accent else Color.WHITE)
    }

    private fun flashConst() = when (flashMode) {
        1 -> ImageCapture.FLASH_MODE_AUTO
        2 -> ImageCapture.FLASH_MODE_ON
        else -> ImageCapture.FLASH_MODE_OFF
    }

    private fun setMode(m: Mode) {
        if (recording != null || hsActive || busy || m == mode) return
        hideFilterStrip()
        mode = m
        updateModeRow()
        updateTopBar()
        proPanel.visibility = if (m == Mode.PRO) View.VISIBLE else View.GONE
        updateShutterStyle()
        bindCamera()
    }

    // ---------------- Viewfinder shape / resolution ----------------

    private fun viewHW(): Float? = if (mode == Mode.VIDEO) 16f / 9f else if (mode == Mode.XPAN) 24f / 65f else when (ratioMode) {
        0 -> 4f / 3f
        1 -> 1f
        2 -> 16f / 9f
        else -> null
    }

    /** Capture stream aspect: 4:3 for 4:3 / 1:1 / XPAN, 16:9 for 16:9 / Full. */
    private fun bound43(): Boolean {
        val hw = viewHW() ?: return false
        return hw <= 1.45f
    }

    private fun applyPreviewShape() {
        previewContainer.post {
            val cw = previewContainer.width
            val ch = previewContainer.height
            if (cw == 0 || ch == 0) return@post
            val hw = viewHW()
            fun lp(): FrameLayout.LayoutParams {
                if (hw == null) return FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                var w = cw
                var h = (cw * hw).toInt()
                if (h > ch) {
                    h = ch
                    w = (ch / hw).toInt()
                }
                return FrameLayout.LayoutParams(w, h, Gravity.CENTER)
            }
            val plp = lp()
            previewView.layoutParams = plp
            grid.layoutParams = lp()
            analysis.layoutParams = lp()
            val inset = if (plp.height > 0) ((ch - plp.height) / 2).coerceAtLeast(0) else 0
            (filterScroll.parent as? LinearLayout)?.let { st ->
                val sl = st.layoutParams as FrameLayout.LayoutParams
                sl.bottomMargin = inset + dp(8)
                st.layoutParams = sl
            }
            val dl = dial.layoutParams as FrameLayout.LayoutParams
            dl.bottomMargin = inset
            dial.layoutParams = dl
            for (v in listOf(recTimer, statusText)) {
                val l = v.layoutParams as FrameLayout.LayoutParams
                l.topMargin = inset + dp(12)
                v.layoutParams = l
            }
            previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    /** Ask CameraX for the biggest stream the phone allows with this aspect ratio (4032x3024 on a 12MP sensor). */
    private fun resSel(b43: Boolean): ResolutionSelector = ResolutionSelector.Builder()
        .setAspectRatioStrategy(
            if (b43) AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY else AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        )
        .setResolutionStrategy(ResolutionStrategy(Size(4032, 3024), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
        .build()

    private fun analysisSel(b43: Boolean): ResolutionSelector = ResolutionSelector.Builder()
        .setAspectRatioStrategy(
            if (b43) AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY else AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        )
        .setResolutionStrategy(ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
        .build()

    // ---------------- Camera ----------------

    private fun initCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                provider = f.get()
            } catch (e: Exception) {
                toast("Camera init failed: ${e.message}")
                return@addListener
            }
            try {
                val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
                ef.addListener({
                    try { extMgr = ef.get() } catch (e: Exception) { extMgr = null }
                    bindCamera()
                }, ContextCompat.getMainExecutor(this))
            } catch (e: Exception) {
                extMgr = null
                bindCamera()
            }
        }, ContextCompat.getMainExecutor(this))
        refreshThumb()
    }

    private fun videoQuality() = when (prefs.getInt("vq", 1)) {
        0 -> Quality.HD
        2 -> Quality.UHD
        else -> Quality.FHD
    }

    private fun bindCamera() {
        val p = provider ?: return
        applyPreviewShape()
        p.unbindAll()
        val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        var selector = base
        if (mode == Mode.PHOTO && (hdr || prefs.getBoolean("autohdr", false))) {
            val em = extMgr
            if (em != null && em.isExtensionAvailable(base, ExtensionMode.HDR)) {
                selector = em.getExtensionEnabledCameraSelector(base, ExtensionMode.HDR)
            } else if (hdr) {
                toast("Hardware HDR is not supported on this phone")
            }
        }
        val analysisOn = mode == Mode.PRO && (analysis.showHist || analysis.showZebra || analysis.showPeak)
        var ok = doBind(p, selector, analysisOn)
        if (!ok) {
            p.unbindAll()
            ok = doBind(p, selector, false)
        }
        if (!ok && selector !== base) {
            p.unbindAll()
            ok = doBind(p, base, false)
        }
        if (!ok) toast("Camera error: $lastBindError")
        analysis.visibility = if (analysisOn && ok) View.VISIBLE else View.GONE
        try {
            val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange
            camera?.cameraControl?.setExposureCompensationIndex(if (mode == Mode.NIGHT) (r?.upper ?: 0) else 0)
        } catch (e: Exception) { }
        applyPro()
        buildChips()
        if (mode == Mode.VIDEO) camera?.cameraControl?.enableTorch(flashMode == 2)
        previewView.postDelayed({ applyFilterPreview() }, 200)
        previewView.postDelayed({ applyFilterPreview() }, 800)
    }

    private fun doBind(p: ProcessCameraProvider, selector: CameraSelector, withAnalysis: Boolean): Boolean {
        return try {
            val b43 = bound43()
            val sel = resSel(b43)
            val preview = Preview.Builder().setResolutionSelector(sel).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val ucs = ArrayList<UseCase>()
            ucs.add(preview)
            if (mode == Mode.VIDEO) {
                val rec = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(videoQuality(), FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                    )
                    .build()
                val vb = VideoCapture.Builder(rec)
                val fpsHint = effFps().let { if (it >= 120) 30 else it }
                try {
                    vb.javaClass.getMethod("setTargetFrameRate", Range::class.java).invoke(vb, Range(fpsHint, fpsHint))
                } catch (t: Throwable) { }
                videoCapture = vb.build()
                imageCapture = null
                ucs.add(videoCapture!!)
            } else {
                val icb = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setResolutionSelector(sel)
                    .setFlashMode(if (mode == Mode.NIGHT || mode == Mode.MDR) ImageCapture.FLASH_MODE_OFF else flashConst())
                try {
                    icb.javaClass.getMethod("setJpegQuality", Integer.TYPE).invoke(icb, 98)
                } catch (t: Throwable) { }
                imageCapture = icb.build()
                videoCapture = null
                ucs.add(imageCapture!!)
                if (withAnalysis) {
                    val ia = ImageAnalysis.Builder()
                        .setResolutionSelector(analysisSel(b43))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    ia.setAnalyzer(analysisExec, analyzer)
                    ucs.add(ia)
                }
            }
            camera = p.bindToLifecycle(this, selector, *ucs.toTypedArray())
            true
        } catch (e: Exception) {
            lastBindError = e.message ?: "unknown"
            false
        }
    }

    // ---------------- Analysis (histogram / zebra / focus peaking) ----------------

    private val analyzer = ImageAnalysis.Analyzer { image ->
        try {
            val pl = image.planes[0]
            val buf = pl.buffer
            val rs = pl.rowStride
            val ps = pl.pixelStride
            val w = image.width
            val h = image.height
            val rot = image.imageInfo.rotationDegrees
            val cols = 60
            val rows = 80
            val lum = IntArray(cols * rows)
            for (cy in 0 until rows) for (cx in 0 until cols) {
                val u = (cx + 0.5f) / cols
                val v = (cy + 0.5f) / rows
                val sx: Float
                val sy: Float
                when (rot) {
                    90 -> { sx = v * w; sy = (1 - u) * h }
                    180 -> { sx = (1 - u) * w; sy = (1 - v) * h }
                    270 -> { sx = (1 - v) * w; sy = u * h }
                    else -> { sx = u * w; sy = v * h }
                }
                val ix = sx.toInt().coerceIn(0, w - 1)
                val iy = sy.toInt().coerceIn(0, h - 1)
                lum[cy * cols + cx] = buf.get(iy * rs + ix * ps).toInt() and 255
            }
            val hist = IntArray(64)
            val zebra = BooleanArray(cols * rows)
            val peak = BooleanArray(cols * rows)
            for (i in lum.indices) {
                hist[lum[i] shr 2]++
                zebra[i] = lum[i] >= 235
                val x = i % cols
                val y = i / cols
                if (x < cols - 1 && y < rows - 1) {
                    val g = abs(lum[i] - lum[i + 1]) + abs(lum[i] - lum[i + cols])
                    peak[i] = g > 45
                }
            }
            analysis.update(hist, zebra, peak, cols, rows)
        } catch (t: Throwable) {
        } finally {
            image.close()
        }
    }

    // ---------------- Live filter preview ----------------

    private fun effLook(): Int {
        if (mode == Mode.PRO && filterIdx == 0 && prefs.getBoolean("hncs", false)) return Filters.indexOf("Hasselblad HNCS")
        return filterIdx
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val t = findTexture(v.getChildAt(i))
                if (t != null) return t
            }
        }
        return null
    }

    private fun applyFilterPreview() {
        val tv = findTexture(previewView) ?: return
        val m = Filters.matrix(effLook())
        if (m == null) {
            tv.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            tv.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
        }
    }

    // ---------------- Zoom chips / wheel / gestures ----------------

    private fun buildChips() {
        zoomRow.removeAllViews()
        chips.clear()
        lastChipKey = -1
        zoomLive?.removeObservers(this)
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val min = zs.minZoomRatio
        val max = zs.maxZoomRatio
        dial.minZ = min
        dial.maxZ = max
        dial.setAccent(accent)
        val list = ArrayList<Float>()
        for (z in listOf(0.6f, 1f, 2f, 5f, 10f)) {
            if (z >= min - 0.01f && z <= max + 0.01f) list.add(z)
        }
        if (list.isEmpty()) list.add(min)
        for ((idx, z) in list.withIndex()) {
            val tv = TextView(this).apply {
                text = chipText(z)
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setBackgroundResource(R.drawable.chip_bg)
                setOnClickListener {
                    if (idx == selChip) showDial() else smoothZoomTo(z)
                }
                setOnLongClickListener { showDial(); true }
            }
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.setMargins(dp(4), 0, dp(4), 0)
            zoomRow.addView(tv, lp)
            chips.add(Pair(z, tv))
        }
        zoomLive = cam.cameraInfo.zoomState
        zoomLive?.observe(this) { s ->
            highlightChip(s.zoomRatio)
            if (!dial.dragging) dial.zoom = s.zoomRatio
        }
    }

    private fun chipText(z: Float): String =
        if (z < 1f) ".${(z * 10).toInt()}" else if (z == z.toInt().toFloat()) "${z.toInt()}x" else String.format(Locale.US, "%.1fx", z)

    private var lastChipKey = -1

    private fun highlightChip(cur: Float) {
        val key = (cur * 20f).toInt() * 64 + chips.size
        if (key == lastChipKey) return
        lastChipKey = key
        var sel = 0
        for (i in chips.indices) if (chips[i].first <= cur + 0.02f) sel = i
        selChip = sel
        for (i in chips.indices) {
            val (z, tv) = chips[i]
            if (i == sel) {
                tv.setTextColor(accent)
                tv.text = if (abs(cur - z) < 0.05f) chipText(z) else String.format(Locale.US, "%.1fx", cur)
            } else {
                tv.setTextColor(Color.WHITE)
                tv.text = chipText(z)
            }
        }
    }

    // --- iPhone-style zoom glide -------------------------------------------------------------
    // The zoom (in log space) is chased by a critically damped spring whose own target is low-pass
    // filtered. That gives a soft start, a long soft landing, and keeps velocity when you tap again
    // mid-glide, so there is never a visible jump.
    private var zoomRunning = false
    private var zoomTargetLn = 0f
    private var zoomX = 0f
    private var zoomY = 0f
    private var zoomV = 0f
    private var zoomLast = 0L

    private val zoomFrame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!zoomRunning) return
            val cam = camera
            val zs = cam?.cameraInfo?.zoomState?.value
            if (cam == null || zs == null) {
                zoomRunning = false
                zoomLast = 0L
                return
            }
            var dt = if (zoomLast == 0L) 1f / 60f else (frameTimeNanos - zoomLast) / 1e9f
            zoomLast = frameTimeNanos
            dt = dt.coerceIn(0.004f, 0.034f)
            zoomY = zoomTargetLn
            val w = 11.5f
            val acc = w * w * (zoomY - zoomX) - 2f * w * zoomV
            zoomV += acc * dt
            zoomX += zoomV * dt
            cam.cameraControl.setZoomRatio(exp(zoomX).coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
            if (abs(zoomTargetLn - zoomX) < 0.0006f && abs(zoomV) < 0.002f) {
                cam.cameraControl.setZoomRatio(exp(zoomTargetLn).coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
                zoomRunning = false
                zoomLast = 0L
                return
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun stopSmoothZoom() {
        zoomRunning = false
        zoomLast = 0L
    }

    /** Glides to the new zoom ratio instead of jumping. Safe to call again while a glide is running. */
    private fun smoothZoomTo(target: Float) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        zoomTargetLn = ln(target.coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
        if (!zoomRunning) {
            zoomX = ln(zs.zoomRatio)
            zoomY = zoomX
            zoomV = 0f
            zoomLast = 0L
            zoomRunning = true
            Choreographer.getInstance().postFrameCallback(zoomFrame)
        }
    }

    private fun showDial() {
        val zs = camera?.cameraInfo?.zoomState?.value
        if (zs != null) dial.zoom = zs.zoomRatio
        zoomRow.visibility = View.INVISIBLE
        dial.visibility = View.VISIBLE
        scheduleHideDial()
    }

    private fun hideDial() {
        dial.visibility = View.GONE
        zoomRow.visibility = View.VISIBLE
    }

    private fun scheduleHideDial() {
        handler.removeCallbacks(hideDialRunnable)
        handler.postDelayed(hideDialRunnable, 2500)
    }

    private fun zoomStep(up: Boolean) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val t = (zs.zoomRatio * (if (up) 1.25f else 0.8f)).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        smoothZoomTo(t)
        showDial()
    }

    private fun setupGestures() {
        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val zs = cam.cameraInfo.zoomState.value ?: return true
                stopSmoothZoom()
                val target = (zs.zoomRatio * detector.scaleFactor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                return true
            }
        })
        val gestureDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (filterStrip.visibility == View.VISIBLE) hideFilterStrip()
                focusAt(e.x, e.y)
                if (prefs.getBoolean("touchcap", false)) shutterPressed()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > dp(80) && abs(dx) > abs(dy) * 2 && abs(vx) > 600) {
                    val cur = if (mode.more) mainModes.indexOf(Mode.PHOTO) else mainModes.indexOf(mode)
                    if (cur < 0) return false
                    val idx = cur + if (dx < 0) 1 else -1
                    if (idx in mainModes.indices) setMode(mainModes[idx])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            if (!scaleDet.isInProgress) gestureDet.onTouchEvent(ev)
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
        } catch (e: Exception) { }
        // ring is positioned in container coordinates
        val ox = previewView.left.toFloat()
        val oy = previewView.top.toFloat()
        focusRing.animate().cancel()
        focusRing.x = ox + x - focusRing.width / 2f
        focusRing.y = oy + y - focusRing.height / 2f
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction {
                focusRing.visibility = View.INVISIBLE
                focusRing.animate().setStartDelay(0)
            }.start()
        }.start()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            val vk = prefs.getInt("volkey", 0)
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && prefs.getBoolean("quick", false) && vk != 0) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastVolDown < 500) {
                    lastVolDown = 0
                    shutterPressed()
                    return true
                }
                lastVolDown = now
            }
            when (vk) {
                0 -> {
                    if (event?.repeatCount == 0) shutterPressed()
                    return true
                }
                1 -> {
                    zoomStep(keyCode == KeyEvent.KEYCODE_VOLUME_UP)
                    return true
                }
                3 -> return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------- Pro mode + night / video camera tuning ----------------

    private fun <T> chr(key: CameraCharacteristics.Key<T>): T? {
        val c = camera ?: return null
        return try { Camera2CameraInfo.from(c.cameraInfo).getCameraCharacteristic(key) } catch (e: Exception) { null }
    }

    private fun isoValue(p: Int): Int {
        val r = chr(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val lo = (r?.lower ?: 100).toDouble()
        val hi = minOf((r?.upper ?: 1600), 3200).toDouble()
        if (p <= 0) return 200.coerceIn(lo.toInt(), hi.toInt())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toInt()
    }

    private fun shutterValue(p: Int): Long {
        val r = chr(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val lo = maxOf(r?.lower ?: 125_000L, 125_000L).toDouble()
        val hi = minOf(r?.upper ?: 1_000_000_000L, 1_000_000_000L).toDouble()
        if (p <= 0) return 16_666_666L.coerceIn(lo.toLong(), hi.toLong())
        return (lo * (hi / lo).pow((p - 1) / 99.0)).toLong()
    }

    private fun shutterLabel(p: Int): String {
        if (p == 0) return "AUTO"
        val ns = shutterValue(p)
        return if (ns >= 500_000_000L) String.format(Locale.US, "%.1fs", ns / 1e9) else "1/${(1e9 / ns).toInt()}"
    }

    private fun buildProPanel() {
        val wbNames = listOf("AUTO", "Tungsten", "Fluoresc.", "Daylight", "Cloudy")
        addProRow("ISO", 100, { if (it == 0) "AUTO" else isoValue(it).toString() }) { proIso = it }
        addProRow("S", 100, { shutterLabel(it) }) { proShutter = it }
        addProRow("WB", 4, { wbNames[it] }) { proWb = it }
        addProRow("MF", 100, { if (it == 0) "AUTO" else "$it%" }) { proMf = it }
        addProRow("EV", 12, { String.format(Locale.US, "%+.1f", (it - 6) / 3.0) }, 6) { idx ->
            camera?.cameraControl?.setExposureCompensationIndex(
                ((idx - 6) * ((camera?.cameraInfo?.exposureState?.exposureCompensationRange?.upper ?: 6) / 6.0)).toInt()
            )
        }
    }

    private fun addProRow(label: String, max: Int, fmt: (Int) -> String, start: Int = 0, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val l = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            minWidth = dp(34)
        }
        val v = TextView(this).apply {
            text = fmt(start)
            textSize = 12f
            setTextColor(Color.parseColor("#FFCC00"))
            gravity = Gravity.END
            minWidth = dp(70)
        }
        val sb = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    set(p)
                    v.text = fmt(p)
                    if (fromUser) applyPro()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        row.addView(l)
        row.addView(sb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(v)
        proPanel.addView(row)
    }

    private fun applyPro() {
        val cam = camera ?: return
        val b = CaptureRequestOptions.Builder()
        if (mode == Mode.NIGHT) {
            val ranges = chr(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val slow = ranges?.minWithOrNull(compareBy<android.util.Range<Int>>({ it.upper }, { it.lower }))
            if (slow != null) b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, slow)
        }
        if (mode != Mode.VIDEO && mode != Mode.NIGHT) {
            val edges = chr(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
            if (edges != null && edges.contains(CaptureRequest.EDGE_MODE_HIGH_QUALITY)) {
                b.setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            }
            val nr = chr(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
            if (nr != null && nr.contains(CaptureRequest.NOISE_REDUCTION_MODE_FAST)) {
                b.setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_FAST)
            }
        }
        if (mode == Mode.VIDEO) {
            if (prefs.getBoolean("fullsensor", false) && Build.VERSION.SDK_INT >= 30) {
                val ar = chr(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                if (ar != null) {
                    val cw = ar.width()
                    val chh = cw * 9 / 16
                    val y0 = ar.top + (ar.height() - chh) / 2
                    b.setCaptureRequestOption(CaptureRequest.SCALER_CROP_REGION, Rect(ar.left, y0, ar.left + cw, y0 + chh))
                }
            }
            val want = effFps()
            val target = if (want >= 120) 30 else want
            val ranges = chr(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val pick = ranges?.filter { it.upper == target }?.maxByOrNull { it.lower }
            if (pick != null) b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pick)
        }
        if (mode == Mode.PRO) {
            if (proIso > 0 || proShutter > 0) {
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoValue(proIso))
                b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterValue(proShutter))
            }
            if (proWb > 0) {
                val modes = intArrayOf(
                    CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
                    CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
                    CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
                )
                b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, modes[proWb - 1])
            }
            if (proMf > 0) {
                val minFocus = chr(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
                if (minFocus > 0f) {
                    b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                    b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * proMf / 100f)
                }
            }
        }
        try {
            Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
        } catch (e: Exception) { }
    }

    // ---------------- Capture ----------------

    private fun shutterPressed() {
        if (counting || busy) return
        if (mode == Mode.VIDEO) {
            if (recording != null || hsActive) toggleRecord() else withTimer { toggleRecord() }
        } else {
            withTimer { takePhoto() }
        }
    }

    private fun withTimer(action: () -> Unit) {
        if (timerSec == 0) { action(); return }
        counting = true
        var left = timerSec
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = "$left"
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    counting = false
                    action()
                }
            }
        }
        handler.post(r)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun legacyPath(name: String): String {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "Camera")
        dir.mkdirs()
        return File(dir, name).absolutePath
    }

    private fun setStatus(t: String?) {
        if (t == null) statusText.visibility = View.GONE
        else {
            statusText.text = t
            statusText.visibility = View.VISIBLE
        }
    }

    private fun cropHW(): Float? = if (mode == Mode.XPAN) 24f / 65f else when (ratioMode) {
        1 -> 1f
        3 -> previewContainer.height.toFloat() / previewContainer.width.coerceAtLeast(1)
        else -> null
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Location? {
        if (!prefs.getBoolean("geotag", false) || !hasPerm(Manifest.permission.ACCESS_FINE_LOCATION)) return null
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
        } catch (e: Exception) { null }
    }

    private fun takePhoto() {
        val m = mode
        val n = when (m) { Mode.NIGHT -> 5; Mode.AI -> 3; Mode.MDR -> 5; else -> 1 }
        busy = true
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.SHUTTER_CLICK)
        val look = effLook()
        val wm = prefs.getInt("wmstyle", 0)
        val txt = prefs.getString("wmtext", "").orEmpty()
        val crop = cropHW()
        val loc = lastLocation()
        val ai = prefs.getBoolean("aiboost", false) && m == Mode.PHOTO
        val sharpOn = m != Mode.NIGHT && m != Mode.AI
        val sharp = if (sharpOn) floatArrayOf(0f, 0.5f, 0.9f, 1.4f)[prefs.getInt("sharp", 2).coerceIn(0, 3)] else 0f
        val ap = apIdx
        val onFiles: (List<File>) -> Unit = { files ->
            val job = Job(files, m, look, wm, txt, crop, loc, ap, ai, sharp)
            val heavy = !((m == Mode.PHOTO || m == Mode.PRO) && look == 0 && wm == 0 && crop == null && !ai && sharp == 0f)
            if (heavy) setStatus(if (m == Mode.NIGHT || m == Mode.AI || m == Mode.MDR) "Processing…" else "Saving…") else busy = false
            runPipeline(job)
        }
        when (m) {
            Mode.MDR -> captureBracket(onFiles)
            Mode.NIGHT, Mode.AI -> captureQueued(n, onFiles)
            else -> captureSeq(n, 0, ArrayList(), onFiles)
        }
    }

    /** All frames are requested at once, so CameraX fires them back-to-back with no wait between shots. */
    private fun captureQueued(n: Int, done: (List<File>) -> Unit) {
        val ic = imageCapture
        if (ic == null) {
            busy = false
            setStatus(null)
            return
        }
        val files = ArrayList<File>()
        var left = n
        val ex = ContextCompat.getMainExecutor(this)
        val t0 = System.currentTimeMillis()
        setStatus("Hold still…")
        fun finishOne() {
            left--
            if (left == 0) {
                if (files.isEmpty()) {
                    busy = false
                    setStatus(null)
                    toast("Photo failed")
                } else done(files.sortedBy { it.name })
            }
        }
        for (i in 0 until n) {
            val f = File(cacheDir, "frame_${t0}_$i.jpg")
            val meta = ImageCapture.Metadata().apply { isReversedHorizontal = front && prefs.getBoolean("mirror", true) }
            ic.takePicture(
                ImageCapture.OutputFileOptions.Builder(f).setMetadata(meta).build(), ex,
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                        files.add(f)
                        finishOne()
                    }

                    override fun onError(e: ImageCaptureException) {
                        finishOne()
                    }
                })
        }
    }

    /** MDR: 5 frames at -2, -1, 0, +1, +2 EV (changing exposure compensation between shots). */
    private fun captureBracket(done: (List<File>) -> Unit) {
        val cam = camera
        val ic = imageCapture
        if (cam == null || ic == null) {
            busy = false
            setStatus(null)
            return
        }
        val es = cam.cameraInfo.exposureState
        val range = es.exposureCompensationRange
        val stepEv = es.exposureCompensationStep.toFloat()
        val evs = floatArrayOf(-2f, -1f, 0f, 1f, 2f)
        val idxs = evs.map { if (stepEv > 0f) Math.round(it / stepEv).coerceIn(range.lower, range.upper) else 0 }
        val files = ArrayList<File>()
        val ex = ContextCompat.getMainExecutor(this)
        val meta = ImageCapture.Metadata().apply { isReversedHorizontal = front && prefs.getBoolean("mirror", true) }
        fun step(i: Int) {
            if (i >= idxs.size) {
                try { cam.cameraControl.setExposureCompensationIndex(0) } catch (e: Exception) { }
                if (files.size >= 2) done(files) else {
                    busy = false
                    setStatus(null)
                    toast("MDR needs at least 2 frames")
                }
                return
            }
            setStatus("MDR ${i + 1}/${idxs.size} – hold still")
            val fut = cam.cameraControl.setExposureCompensationIndex(idxs[i])
            fut.addListener({
                handler.postDelayed({
                    val f = File(cacheDir, "mdr_${System.currentTimeMillis()}_$i.jpg")
                    ic.takePicture(
                        ImageCapture.OutputFileOptions.Builder(f).setMetadata(meta).build(), ex,
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                                files.add(f)
                                step(i + 1)
                            }

                            override fun onError(e: ImageCaptureException) {
                                step(i + 1)
                            }
                        })
                }, 220)
            }, ex)
        }
        step(0)
    }

    private fun captureSeq(n: Int, i: Int, files: ArrayList<File>, done: (List<File>) -> Unit) {
        val ic = imageCapture
        if (ic == null) {
            busy = false
            setStatus(null)
            return
        }
        val f = File(cacheDir, "frame_${System.currentTimeMillis()}_$i.jpg")
        val meta = ImageCapture.Metadata().apply { isReversedHorizontal = front && prefs.getBoolean("mirror", true) }
        if (n > 1) setStatus("Hold still… ${i + 1}/$n")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).setMetadata(meta).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    files.add(f)
                    if (i + 1 < n) captureSeq(n, i + 1, files, done) else done(files)
                }

                override fun onError(e: ImageCaptureException) {
                    toast("Photo failed: ${e.message}")
                    if (files.isNotEmpty()) done(files) else {
                        busy = false
                        setStatus(null)
                    }
                }
            })
    }

    private fun newMediaUri(video: Boolean): Uri? {
        val name = (if (video) "VID_" else "IMG_") + stamp()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath(name + if (video) ".mp4" else ".jpg"))
        }
        return contentResolver.insert(
            if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        )
    }

    private fun dms(v: Double): String {
        val a = abs(v)
        val d = a.toInt()
        val mf = (a - d) * 60.0
        val m = mf.toInt()
        val sec = ((mf - m) * 60.0 * 1000.0).toInt()
        return "$d/1,$m/1,$sec/1000"
    }

    private fun setGeo(f: File, l: Location) {
        try {
            val e = ExifInterface(f.path)
            e.setAttribute("GPSLatitude", dms(l.latitude))
            e.setAttribute("GPSLatitudeRef", if (l.latitude >= 0) "N" else "S")
            e.setAttribute("GPSLongitude", dms(l.longitude))
            e.setAttribute("GPSLongitudeRef", if (l.longitude >= 0) "E" else "W")
            e.saveAttributes()
        } catch (t: Throwable) { }
    }

    private fun runPipeline(job: Job) {
        Thread {
            try {
                val uri = newMediaUri(false) ?: throw IllegalStateException("cannot create file")
                val m = job.mode
                val plain = (m == Mode.PHOTO || m == Mode.PRO) && job.look == 0 && job.wm == 0 && job.cropHW == null && !job.aiBoost && job.sharp == 0f
                if (plain) {
                    job.loc?.let { setGeo(job.files[0], it) }
                    contentResolver.openOutputStream(uri)!!.use { o ->
                        job.files[0].inputStream().use { it.copyTo(o) }
                    }
                } else {
                    var extra: ColorMatrix? = null
                    val ex = Processor.readExif(job.files[0])
                    var bmp: Bitmap = when (m) {
                        Mode.PORTRAIT -> Processor.portrait(job.files[0], job.ap)
                        Mode.NIGHT -> {
                            extra = Filters.cm(sat = 1.12f, contrast = 1.04f)
                            Processor.night(job.files)
                        }
                        Mode.AI -> {
                            extra = Filters.cm(sat = 1.04f)
                            Processor.ai(job.files)
                        }
                        Mode.MDR -> {
                            extra = Filters.cm(sat = 1.06f, contrast = 1.03f)
                            Processor.mdr(job.files)
                        }
                        Mode.ULTRA -> {
                            Processor.decodeUpright(job.files[0], 9000)
                        }
                        else -> Processor.decodeUpright(job.files[0], 4200)
                    }
                    if (job.aiBoost) Processor.boost(bmp)
                    val chw = job.cropHW
                    if (chw != null) bmp = Processor.cropToRatio(bmp, chw)
                    if (job.sharp > 0f) Processor.sharpen(bmp, job.sharp)
                    bmp = Processor.finish(bmp, job.look, extra, job.wm, job.wmText, ex)
                    val tmp = File(cacheDir, "out_${System.nanoTime()}.jpg")
                    FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                    bmp.recycle()
                    job.loc?.let { setGeo(tmp, it) }
                    contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                    tmp.delete()
                }
                job.files.forEach { it.delete() }
                runOnUiThread {
                    busy = false
                    setStatus(null)
                    refreshThumb()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    busy = false
                    setStatus(null)
                    toast("Processing failed: ${t.message}")
                }
            }
        }.start()
    }

    // ---------------- Video ----------------

    private fun toggleRecord() {
        if (hsActive) {
            stopHighSpeed()
            return
        }
        if (recording == null && effFps() >= 120) {
            startHighSpeed(effFps())
            return
        }
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) {
            cur.stop()
            recording = null
            return
        }
        val name = "VID_${stamp()}"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
            else put(MediaStore.MediaColumns.DATA, legacyPath("$name.mp4"))
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) pr = pr.withAudioEnabled()
        if (prefs.getBoolean("sound", true)) sound.play(MediaActionSound.START_VIDEO_RECORDING)
        val look = effLook()
        val stabLevel = if (front) 0 else prefs.getInt("stabmode", 0)
        if (front && prefs.getInt("stabmode", 0) > 0) toast("Gyro stabilisation works with the rear camera only")
        var glog: GyroLog? = null
        if (stabLevel > 0) {
            val g = GyroLog(this)
            if (g.start()) glog = g else toast("This phone has no gyroscope")
        }
        val zoom0 = camera?.cameraInfo?.zoomState?.value?.zoomRatio?.toDouble() ?: 1.0
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    recStart = SystemClock.elapsedRealtime()
                    recTimer.visibility = View.VISIBLE
                    tickRec()
                    shutterInner.scaleX = 0.6f
                    shutterInner.scaleY = 0.6f
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    recTimer.visibility = View.GONE
                    shutterInner.scaleX = 1f
                    shutterInner.scaleY = 1f
                    val gyroData = glog?.stop()
                    if (ev.hasError()) toast("Video error code ${ev.error}")
                    else if (look != 0 || (stabLevel > 0 && gyroData != null)) {
                        postProcessVideo(ev.outputResults.outputUri, look, stabLevel, gyroData, zoom0)
                    }
                    refreshThumb()
                }
                else -> {}
            }
        }
    }

    /** After recording: gyro stabilisation and/or colour look are baked into the video. */
    private fun postProcessVideo(src: Uri, look: Int, level: Int, data: GyroData?, zoom0: Double) {
        busy = true
        val stab = level > 0 && data != null
        setStatus(if (stab) "Stabilising video…" else "Applying filter to video…")
        val out = File(cacheDir, "vf_${stamp()}.mp4")
        Thread {
            try {
                var effect: androidx.media3.effect.GlMatrixTransformation? = null
                var info = ""
                if (stab && data != null) {
                    val plan = Stabilizer.prepare(this, src, data, level, zoom0, prefs)
                    effect = plan.effect
                    info = plan.info
                }
                runOnUiThread {
                    try {
                        VideoFilter.apply(this, src, if (look != 0) Filters.looks[look] else null, effect, out) { ok, err ->
                            runOnUiThread {
                                if (ok) {
                                    if (info.isNotEmpty()) toast(info)
                                    saveFilteredVideo(out, src)
                                } else {
                                    toast("Video processing failed: $err")
                                    busy = false
                                    setStatus(null)
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        toast("Video processing failed: ${t.message}")
                        busy = false
                        setStatus(null)
                    }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    toast("Stabilisation failed: ${t.message}")
                    busy = false
                    setStatus(null)
                }
            }
        }.start()
    }

    private fun saveFilteredVideo(f: File, old: Uri) {
        Thread {
            try {
                val u = newMediaUri(true) ?: throw IllegalStateException("cannot create video")
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                f.delete()
                try { contentResolver.delete(old, null, null) } catch (e: Exception) { }
            } catch (t: Throwable) {
                runOnUiThread { toast("Saving filtered video failed: ${t.message}") }
            }
            runOnUiThread {
                busy = false
                setStatus(null)
                refreshThumb()
            }
        }.start()
    }

    // ---------------- Frame rate / quality support ----------------

    /** 0 = 30 fps, 1 = 60 fps. Old installs stored an index into a longer list (24/30/60/120/240), so convert once. */
    private fun fpsIdx(): Int {
        if (!prefs.contains("fpsidx2")) {
            prefs.edit().putInt("fpsidx2", if (prefs.getInt("fpsidx", 1) == 2) 1 else 0).apply()
        }
        return prefs.getInt("fpsidx2", 0).coerceIn(0, 1)
    }

    private val fpsList = listOf(30, 60)

    private fun maxFpsFor(q: Int) = 60

    private fun hsSize(q: Int): Size? = when (q) {
        0 -> Size(1280, 720)
        1 -> Size(1920, 1080)
        else -> null
    }

    private fun fpsOk(q: Int, f: Int): Boolean {
        if (f > maxFpsFor(q)) return false
        if (f >= 120) {
            val s = hsSize(q) ?: return false
            return HighSpeedRecorder.supports(this, s, f)
        }
        val ranges = chr(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: return true
        return ranges.any { it.upper == f }
    }

    /** The frame rate that will really be used: the chosen one, stepped down until the phone supports it. */
    private fun effFps(): Int {
        val q = prefs.getInt("vq", 1).coerceIn(0, 2)
        var f = fpsList[fpsIdx().coerceIn(0, fpsList.size - 1)]
        while (fpsList.indexOf(f) > 0 && !fpsOk(q, f)) f = fpsList[fpsList.indexOf(f) - 1]
        return f
    }

    private fun setQuality(q: Int) {
        prefs.edit().putInt("vq", q).apply()
        lastVq = q
        updateTopBar()
        bindCamera()
    }

    private fun setFps(f: Int) {
        val q = prefs.getInt("vq", 1).coerceIn(0, 2)
        if (!fpsOk(q, f)) {
            toast("$f fps is not supported at ${listOf("720p", "1080p", "4K")[q]} on this phone")
            return
        }
        prefs.edit().putInt("fpsidx2", fpsList.indexOf(f)).apply()
        lastFps = fpsList.indexOf(f)
        updateTopBar()
        bindCamera()
    }

    private var vpop: PopupWindow? = null

    private fun popRow(label: String, items: List<String>, enabled: List<Boolean>, sel: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.argb(170, 255, 255, 255))
            minWidth = dp(54)
        })
        for ((i, t) in items.withIndex()) {
            val chip = TextView(this).apply {
                text = t
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setTextColor(if (i == sel) accent else Color.WHITE)
                alpha = if (enabled[i]) 1f else 0.3f
                if (i == sel) {
                    background = GradientDrawable().apply {
                        cornerRadius = dp(16).toFloat()
                        setColor(Color.argb(55, 255, 255, 255))
                    }
                }
                setOnClickListener { onPick(i) }
            }
            row.addView(chip)
        }
        return row
    }

    /** Small glass window under the top bar: quality row + frame-rate row (like the Find X camera). */
    private fun showVideoPopup() {
        if (recording != null || hsActive) return
        vpop?.dismiss()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(225, 52, 52, 60), Color.argb(215, 24, 24, 30))
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.argb(80, 255, 255, 255))
            }
        }
        val fpsDesc = fpsList.reversed()
        fun rebuild() {
            panel.removeAllViews()
            val q = prefs.getInt("vq", 1).coerceIn(0, 2)
            val cur = effFps()
            panel.addView(popRow("Quality", listOf("720", "1080", "4K"), listOf(true, true, true), q) { i ->
                setQuality(i)
                rebuild()
            })
            panel.addView(popRow("FPS", fpsDesc.map { it.toString() }, fpsDesc.map { fpsOk(q, it) }, fpsDesc.indexOf(cur)) { i ->
                setFps(fpsDesc[i])
                rebuild()
            })
        }
        rebuild()
        val pw = PopupWindow(panel, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = dp(12).toFloat()
        val loc = IntArray(2)
        previewContainer.getLocationOnScreen(loc)
        panel.alpha = 0f
        panel.scaleX = 0.85f
        panel.scaleY = 0.85f
        pw.showAtLocation(previewContainer, Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, loc[1] + dp(6))
        panel.post {
            panel.pivotX = panel.width / 2f
            panel.pivotY = 0f
            panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)).start()
        }
        vpop = pw
    }

    // ---------------- 120 / 240 fps (Camera2 high-speed session) ----------------

    private val hs by lazy { HighSpeedRecorder(this) }
    private var hsActive = false
    private var hsFile: File? = null

    private fun startHighSpeed(fps: Int) {
        if (front) {
            toast("120 / 240 fps works on the rear camera only")
            return
        }
        val q = prefs.getInt("vq", 1).coerceIn(0, 2)
        val size = hsSize(q) ?: return
        hsActive = true
        previewView.visibility = View.INVISIBLE
        val cw = previewContainer.width
        val chh = previewContainer.height
        var w = cw
        var h = (cw * size.width.toFloat() / size.height).toInt()
        if (h > chh) {
            h = chh
            w = (chh * size.height.toFloat() / size.width).toInt()
        }
        hsPreview.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
        hsPreview.visibility = View.VISIBLE
        provider?.unbindAll()
        val out = File(cacheDir, "hs_${stamp()}.mp4")
        hsFile = out
        // give CameraX a moment to let go of the camera before Camera2 opens it
        handler.postDelayed({
            hs.start(
                hsPreview, size, fps, out,
                onStarted = {
                    runOnUiThread {
                        recStart = SystemClock.elapsedRealtime()
                        recTimer.visibility = View.VISIBLE
                        tickRec()
                        shutterInner.scaleX = 0.6f
                        shutterInner.scaleY = 0.6f
                    }
                },
                errCb = { msg ->
                    runOnUiThread {
                        toast("High-speed video failed: $msg")
                        endHighSpeedUi()
                        handler.postDelayed({ bindCamera() }, 350)
                    }
                }
            )
        }, 400)
    }

    private fun stopHighSpeed() {
        val f = hsFile
        hs.stop {
            runOnUiThread {
                endHighSpeedUi()
                if (f != null && f.exists() && f.length() > 0) saveHsVideo(f)
                handler.postDelayed({ bindCamera() }, 350)
            }
        }
    }

    private fun endHighSpeedUi() {
        hsActive = false
        hsPreview.visibility = View.GONE
        previewView.visibility = View.VISIBLE
        recTimer.visibility = View.GONE
        shutterInner.scaleX = 1f
        shutterInner.scaleY = 1f
    }

    private fun saveHsVideo(f: File) {
        Thread {
            try {
                val u = newMediaUri(true) ?: return@Thread
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                f.delete()
                runOnUiThread { refreshThumb() }
            } catch (t: Throwable) {
                runOnUiThread { toast("Saving video failed: ${t.message}") }
            }
        }.start()
    }

    private fun tickRec() {
        if (recording == null && !hsActive) return
        val s = (SystemClock.elapsedRealtime() - recStart) / 1000
        recTimer.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
        handler.postDelayed({ tickRec() }, 500)
    }

    // ---------------- Gallery thumbnail ----------------

    private var lastUri: Uri? = null
    private var lastIsVideo = false

    private fun refreshThumb() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (!hasPerm(Manifest.permission.READ_MEDIA_IMAGES)) return
        } else if (!hasPerm(Manifest.permission.READ_EXTERNAL_STORAGE)) return
        Thread {
            try {
                val c = contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE),
                    "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)",
                    null,
                    "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
                )
                var uri: Uri? = null
                var video = false
                c?.use {
                    if (it.moveToFirst()) {
                        val id = it.getLong(0)
                        video = it.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        uri = ContentUris.withAppendedId(
                            if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                        )
                    }
                }
                val u = uri ?: return@Thread
                val bmp: Bitmap? = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(u, Size(256, 256), null)
                } else if (video) {
                    val m = MediaMetadataRetriever()
                    m.setDataSource(this, u)
                    val fr = m.frameAtTime
                    m.release()
                    fr
                } else {
                    contentResolver.openInputStream(u)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 8 })
                    }
                }
                runOnUiThread {
                    lastUri = u
                    lastIsVideo = video
                    if (bmp != null) thumb.setImageBitmap(bmp)
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun openGallery() {
        val u = lastUri ?: run { toast("No photos yet"); return }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) { toast("No gallery app found") }
    }

    override fun onStop() {
        super.onStop()
        if (hsActive) stopHighSpeed()
        recording?.stop()
        recording = null
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        analysisExec.shutdown()
        sound.release()
    }
}
