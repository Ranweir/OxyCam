package com.oxycam.eis

import kotlin.math.exp
import kotlin.math.tanh

/**
 * Adaptive SLERP low-pass filter for the camera path (causal, so it works live).
 *
 * The virtual (stabilised) camera chases the real one with a time constant tau:
 *  - steady hand  : tau = tauMax  -> hand shake is absorbed, the picture sits still like on a gimbal
 *  - deliberate pan: the slow component of the angular rate rises, tau falls to tauMin -> the view glides after you
 * A soft clamp keeps the real-vs-virtual difference inside what the crop can hide, so black borders never appear.
 */
class EisSmoother(
    private val tauMax: Double = 0.45,
    private val tauMin: Double = 0.06,
    private val panRate: Double = 0.18   // rad/s of *sustained* rotation that counts as a pan
) {
    private val qs = Quat.identity()
    private val prev = Quat.identity()
    private val rel = DoubleArray(4)
    private val tmp = DoubleArray(4)
    private val rv = DoubleArray(3)
    private val wLp = DoubleArray(3)
    private var lastT = 0L
    private var inited = false

    fun reset() { inited = false; wLp[0] = 0.0; wLp[1] = 0.0; wLp[2] = 0.0 }

    private fun smoothstep(e0: Double, e1: Double, x: Double): Double {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0)
        return t * t * (3 - 2 * t)
    }

    private fun softClamp(v: Double, m: Double): Double = m * tanh(v / m)

    /**
     * @param qNow real camera orientation at frame time
     * @param maxX/maxY/maxZ largest rotation (rad) about the camera x/y/z axes the crop can hide
     * @param out receives the virtual camera orientation
     */
    fun update(tNs: Long, qNow: DoubleArray, maxX: Double, maxY: Double, maxZ: Double, out: DoubleArray) {
        if (!inited) {
            Quat.set(qs, qNow); Quat.set(prev, qNow)
            lastT = tNs
            inited = true
            Quat.set(out, qs)
            return
        }
        val dt = ((tNs - lastT) * 1e-9).coerceIn(0.001, 0.1)
        lastT = tNs

        // angular velocity from consecutive orientations (in the previous camera frame)
        Quat.conj(prev, tmp)
        Quat.mul(tmp, qNow, rel)
        Quat.toRotVec(rel, rv)
        val a = 1.0 - exp(-dt / 0.25)
        for (i in 0..2) wLp[i] += (rv[i] / dt - wLp[i]) * a
        Quat.set(prev, qNow)

        val pan = Math.sqrt(wLp[0] * wLp[0] + wLp[1] * wLp[1] + wLp[2] * wLp[2])
        val k = smoothstep(0.5 * panRate, 2.0 * panRate, pan)
        val tau = tauMax + (tauMin - tauMax) * k
        Quat.slerp(qs, qNow, 1.0 - exp(-dt / tau), qs)

        // soft boundary clamp: qNow = qs * exp(r); limit r, then rebuild qs = qNow * exp(-r)
        Quat.conj(qs, tmp)
        Quat.mul(tmp, qNow, rel)
        Quat.toRotVec(rel, rv)
        val cx = softClamp(rv[0], maxX)
        val cy = softClamp(rv[1], maxY)
        val cz = softClamp(rv[2], maxZ)
        Quat.fromRotVec(-cx, -cy, -cz, tmp)
        Quat.mul(qNow, tmp, qs)
        Quat.normalize(qs)
        Quat.set(out, qs)
    }
}
