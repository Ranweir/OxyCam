package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class GridOverlay(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    // 0 off, 1 grid 3x3, 2 golden ratio, 3 diagonal
    var style: Int = 0
        set(v) {
            field = v
            invalidate()
        }

    private val p = Paint().apply {
        color = 0x88FFFFFF.toInt()
        strokeWidth = 2f
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        when (style) {
            1, 3 -> {
                for (i in 1..2) {
                    canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
                    canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
                }
                if (style == 3) {
                    canvas.drawLine(0f, 0f, w, h, p)
                    canvas.drawLine(w, 0f, 0f, h, p)
                }
            }
            4 -> {
                canvas.drawLine(w / 2f, h / 2f - 40f, w / 2f, h / 2f + 40f, p)
                canvas.drawLine(w / 2f - 40f, h / 2f, w / 2f + 40f, h / 2f, p)
            }
            2 -> {
                for (f in floatArrayOf(0.382f, 0.618f)) {
                    canvas.drawLine(w * f, 0f, w * f, h, p)
                    canvas.drawLine(0f, h * f, w, h * f, p)
                }
            }
        }
    }
}
