package com.oxycam

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.core.TermCriteria
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import org.opencv.video.Video
import java.io.File

/**
 * Multi-frame engine built on OpenCV (CPU, NEON optimised):
 *  - mdr():  different exposures -> AlignMTB alignment -> Mertens exposure fusion
 *  - fuse(): same exposure burst -> ECC alignment (rotation + shift) -> ghost-aware weighted average
 */
object MultiFrame {
    @Volatile
    private var ready = false

    fun init(): Boolean {
        if (!ready) ready = try { OpenCVLoader.initLocal() } catch (t: Throwable) { false }
        return ready
    }

    private fun toRgb(f: File, maxSide: Int): Mat {
        val bmp = Processor.decodeUpright(f, maxSide)
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        bmp.recycle()
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        return rgb
    }

    private fun toBitmap(rgb: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
        val bmp = Bitmap.createBitmap(rgb.cols(), rgb.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        rgba.release()
        return bmp
    }

    /** Bracketed frames (e.g. -2..+2 EV) -> one wide-dynamic-range picture. */
    fun mdr(files: List<File>, maxSide: Int): Bitmap {
        if (!init()) throw IllegalStateException("OpenCV failed to load")
        val src = ArrayList<Mat>()
        for (f in files) {
            val m = toRgb(f, maxSide)
            if (src.isNotEmpty() && (m.cols() != src[0].cols() || m.rows() != src[0].rows())) {
                m.release()
                continue
            }
            src.add(m)
        }
        if (src.size < 2) throw IllegalStateException("not enough frames")
        val aligned = ArrayList<Mat>()
        Photo.createAlignMTB(6, 4, false).process(src, aligned)
        src.forEach { it.release() }
        val fused = Mat()
        Photo.createMergeMertens(1f, 1f, 1f).process(aligned, fused)
        aligned.forEach { it.release() }
        val out = Mat()
        fused.convertTo(out, CvType.CV_8UC3, 255.0)
        fused.release()
        val bmp = toBitmap(out)
        out.release()
        return bmp
    }

    /** Same-exposure burst -> aligned, de-ghosted, noise-averaged picture. */
    fun fuse(files: List<File>, maxSide: Int): Bitmap {
        if (!init()) throw IllegalStateException("OpenCV failed to load")
        val ref = toRgb(files[0], maxSide)
        val w = ref.cols()
        val h = ref.rows()
        val s = 640.0 / w
        val refGray = Mat()
        Imgproc.cvtColor(ref, refGray, Imgproc.COLOR_RGB2GRAY)
        val refSmall = Mat()
        Imgproc.resize(refGray, refSmall, Size(640.0, h * s), 0.0, 0.0, Imgproc.INTER_AREA)
        val refBlur = Mat()
        Imgproc.GaussianBlur(refGray, refBlur, Size(9.0, 9.0), 0.0)
        refGray.release()
        val acc = Mat()
        ref.convertTo(acc, CvType.CV_32FC3)
        ref.release()
        val wsum = Mat(h, w, CvType.CV_32FC1, Scalar(1.0))

        for (i in 1 until files.size) {
            try {
                val cur = toRgb(files[i], maxSide)
                if (cur.cols() != w || cur.rows() != h) {
                    cur.release()
                    continue
                }
                val g = Mat()
                Imgproc.cvtColor(cur, g, Imgproc.COLOR_RGB2GRAY)
                val gs = Mat()
                Imgproc.resize(g, gs, refSmall.size(), 0.0, 0.0, Imgproc.INTER_AREA)
                g.release()

                var warp = Mat.eye(2, 3, CvType.CV_32F)
                try {
                    val est = Mat.eye(2, 3, CvType.CV_32F)
                    Video.findTransformECC(
                        refSmall, gs, est, Video.MOTION_EUCLIDEAN,
                        TermCriteria(TermCriteria.COUNT + TermCriteria.EPS, 60, 1e-5), Mat(), 5
                    )
                    est.put(0, 2, est.get(0, 2)[0] / s)
                    est.put(1, 2, est.get(1, 2)[0] / s)
                    warp = est
                } catch (t: Throwable) {
                    // alignment failed for this frame: use it unaligned (ghost mask will down-weight it)
                }
                gs.release()

                val aligned = Mat()
                Imgproc.warpAffine(
                    cur, aligned, warp, Size(w.toDouble(), h.toDouble()),
                    Imgproc.INTER_LINEAR + Imgproc.WARP_INVERSE_MAP, Core.BORDER_REPLICATE
                )
                cur.release()
                warp.release()

                // ghost / motion rejection weight: 1 where aligned frame agrees with reference, 0 where it does not
                val ag = Mat()
                Imgproc.cvtColor(aligned, ag, Imgproc.COLOR_RGB2GRAY)
                Imgproc.GaussianBlur(ag, ag, Size(9.0, 9.0), 0.0)
                val diff = Mat()
                Core.absdiff(refBlur, ag, diff)
                ag.release()
                val df = Mat()
                diff.convertTo(df, CvType.CV_32F)
                diff.release()
                Core.subtract(df, Scalar(10.0), df)
                Core.multiply(df, Scalar(-1.0 / 25.0), df)
                Core.add(df, Scalar(1.0), df)
                Imgproc.threshold(df, df, 1.0, 1.0, Imgproc.THRESH_TRUNC)
                Imgproc.threshold(df, df, 0.0, 0.0, Imgproc.THRESH_TOZERO)

                val w3 = Mat()
                Imgproc.cvtColor(df, w3, Imgproc.COLOR_GRAY2RGB)
                val af = Mat()
                aligned.convertTo(af, CvType.CV_32FC3)
                aligned.release()
                Core.multiply(af, w3, af)
                Core.add(acc, af, acc)
                Core.add(wsum, df, wsum)
                af.release()
                w3.release()
                df.release()
            } catch (t: Throwable) {
                // skip a bad frame, keep the others
            }
        }
        refSmall.release()
        refBlur.release()
        val w3 = Mat()
        Imgproc.cvtColor(wsum, w3, Imgproc.COLOR_GRAY2RGB)
        wsum.release()
        val res = Mat()
        Core.divide(acc, w3, res)
        acc.release()
        w3.release()
        val out = Mat()
        res.convertTo(out, CvType.CV_8UC3)
        res.release()
        val bmp = toBitmap(out)
        out.release()
        return bmp
    }
}
