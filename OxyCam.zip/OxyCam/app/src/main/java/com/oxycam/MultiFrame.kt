package com.oxycam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.core.TermCriteria
import org.opencv.imgproc.Imgproc
import org.opencv.video.Video
import java.io.File

/**
 * Multi-frame engine built on OpenCV (CPU, NEON optimised):
 *  - mdr():  different exposures -> AlignMTB alignment -> Mertens exposure fusion
 *  - fuse(): same exposure burst -> ECC alignment (rotation + shift) -> ghost-aware weighted average
 */
object MultiFrame {
    @Volatile
    private var ready = false

    fun init(): Boolean {
        if (!ready) ready = try { OpenCVLoader.initLocal() } catch (t: Throwable) { false }
        return ready
    }

    private fun toRgb(f: File, maxSide: Int): Mat {
        val bmp = Processor.decodeUpright(f, maxSide)
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        bmp.recycle()
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        return rgb
    }

    private fun toBitmap(rgb: Mat): Bitmap {
        val rgba = Mat()
        Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
        val bmp = Bitmap.createBitmap(rgb.cols(), rgb.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        rgba.release()
        return bmp
    }

    /** Orders a burst so the sharpest frame (least hand shake) comes first and becomes the reference. */
    fun sortBySharpness(files: List<File>): List<File> {
        if (files.size < 2 || !init()) return files
        val scores = DoubleArray(files.size)
        for ((i, f) in files.withIndex()) {
            try {
                val o = BitmapFactory.Options()
                o.inSampleSize = 4
                val bmp = BitmapFactory.decodeFile(f.path, o) ?: continue
                val rgba = Mat()
                Utils.bitmapToMat(bmp, rgba)
                bmp.recycle()
                val g = Mat()
                Imgproc.cvtColor(rgba, g, Imgproc.COLOR_RGBA2GRAY)
                rgba.release()
                val lap = Mat()
                Imgproc.Laplacian(g, lap, CvType.CV_64F)
                g.release()
                val mean = MatOfDouble()
                val std = MatOfDouble()
                Core.meanStdDev(lap, mean, std)
                lap.release()
                val sd = std.toArray()[0]
                scores[i] = sd * sd
                mean.release()
                std.release()
            } catch (t: Throwable) { }
        }
        return files.indices.sortedByDescending { scores[it] }.map { files[it] }
    }

    /**
     * Same-exposure burst -> aligned, de-ghosted, noise-averaged picture.
     * Heavy maths is done in bands of rows so a full 12 MP burst does not need hundreds of MB at once.
     */
    /**
     * Super-resolution zoom: a burst taken at 1x-2x zoom is aligned more precisely (finer sub-pixel alignment, cubic
     * resampling so the merge does not soften the picture), averaged to remove noise, and the sharpness that the
     * camera's digital zoom upscaling took away is restored on the brightness channel only.
     */
    fun superRes(files: List<File>, maxSide: Int, zoom: Float): Bitmap =
        fuse(files, maxSide, 960.0, Imgproc.INTER_CUBIC, zoom)

    fun fuse(
        files: List<File>, maxSide: Int,
        alignWidth: Double = 640.0, interp: Int = Imgproc.INTER_LINEAR, srZoom: Float = 0f
    ): Bitmap {
        if (!init()) throw IllegalStateException("OpenCV failed to load")
        val ref = toRgb(files[0], maxSide)
        val w = ref.cols()
        val h = ref.rows()
        val s = alignWidth / w
        val refGray = Mat()
        Imgproc.cvtColor(ref, refGray, Imgproc.COLOR_RGB2GRAY)
        val refSmall = Mat()
        Imgproc.resize(refGray, refSmall, Size(alignWidth, h * s), 0.0, 0.0, Imgproc.INTER_AREA)
        val refBlur = Mat()
        Imgproc.GaussianBlur(refGray, refBlur, Size(9.0, 9.0), 0.0)
        refGray.release()
        val acc = Mat()
        ref.convertTo(acc, CvType.CV_32FC3)
        ref.release()
        val wsum = Mat(h, w, CvType.CV_32FC1, Scalar(1.0))
        val band = 256

        for (i in 1 until files.size) {
            try {
                val cur = toRgb(files[i], maxSide)
                if (cur.cols() != w || cur.rows() != h) {
                    cur.release()
                    continue
                }
                val g = Mat()
                Imgproc.cvtColor(cur, g, Imgproc.COLOR_RGB2GRAY)
                val gs = Mat()
                Imgproc.resize(g, gs, refSmall.size(), 0.0, 0.0, Imgproc.INTER_AREA)
                g.release()

                var warp = Mat.eye(2, 3, CvType.CV_32F)
                try {
                    val est = Mat.eye(2, 3, CvType.CV_32F)
                    Video.findTransformECC(
                        refSmall, gs, est, Video.MOTION_EUCLIDEAN,
                        TermCriteria(TermCriteria.COUNT + TermCriteria.EPS, if (srZoom > 0f) 100 else 60, 1e-6), Mat(), 5
                    )
                    est.put(0, 2, est.get(0, 2)[0] / s)
                    est.put(1, 2, est.get(1, 2)[0] / s)
                    warp = est
                } catch (t: Throwable) {
                    // alignment failed for this frame: use it unaligned (the ghost weights will down-weight it)
                }
                gs.release()

                val aligned = Mat()
                Imgproc.warpAffine(
                    cur, aligned, warp, Size(w.toDouble(), h.toDouble()),
                    interp + Imgproc.WARP_INVERSE_MAP, Core.BORDER_REPLICATE
                )
                cur.release()
                warp.release()

                val ag = Mat()
                Imgproc.cvtColor(aligned, ag, Imgproc.COLOR_RGB2GRAY)
                Imgproc.GaussianBlur(ag, ag, Size(9.0, 9.0), 0.0)

                var r0 = 0
                while (r0 < h) {
                    val r1 = minOf(h, r0 + band)
                    // ghost / motion rejection: weight 1 where this frame agrees with the reference, 0 where it does not
                    val diff = Mat()
                    Core.absdiff(refBlur.rowRange(r0, r1), ag.rowRange(r0, r1), diff)
                    val df = Mat()
                    diff.convertTo(df, CvType.CV_32F)
                    diff.release()
                    Core.subtract(df, Scalar(10.0), df)
                    Core.multiply(df, Scalar(-1.0 / 25.0), df)
                    Core.add(df, Scalar(1.0), df)
                    Imgproc.threshold(df, df, 1.0, 1.0, Imgproc.THRESH_TRUNC)
                    Imgproc.threshold(df, df, 0.0, 0.0, Imgproc.THRESH_TOZERO)
                    val w3 = Mat()
                    Imgproc.cvtColor(df, w3, Imgproc.COLOR_GRAY2RGB)
                    val af = Mat()
                    aligned.rowRange(r0, r1).convertTo(af, CvType.CV_32FC3)
                    Core.multiply(af, w3, af)
                    val accB = acc.rowRange(r0, r1)
                    Core.add(accB, af, accB)
                    val wsB = wsum.rowRange(r0, r1)
                    Core.add(wsB, df, wsB)
                    af.release()
                    w3.release()
                    df.release()
                    r0 = r1
                }
                ag.release()
                aligned.release()
            } catch (t: Throwable) {
                // skip a bad frame, keep the others
            }
        }
        refSmall.release()
        refBlur.release()

        var out = Mat(h, w, CvType.CV_8UC3)
        var r0 = 0
        while (r0 < h) {
            val r1 = minOf(h, r0 + band)
            val w3 = Mat()
            Imgproc.cvtColor(wsum.rowRange(r0, r1), w3, Imgproc.COLOR_GRAY2RGB)
            val res = Mat()
            Core.divide(acc.rowRange(r0, r1), w3, res)
            res.convertTo(out.rowRange(r0, r1), CvType.CV_8UC3)
            w3.release()
            res.release()
            r0 = r1
        }
        acc.release()
        wsum.release()
        if (srZoom > 0f) {
            try {
                val t = (srZoom - 1f).coerceIn(0f, 1f).toDouble()
                val sigma = 0.7 + 0.6 * t
                val amount = 0.5 + 0.7 * t
                val ycc = Mat()
                Imgproc.cvtColor(out, ycc, Imgproc.COLOR_RGB2YCrCb)
                val ch = ArrayList<Mat>()
                Core.split(ycc, ch)
                val y = ch[0]
                val blur = Mat()
                Imgproc.GaussianBlur(y, blur, Size(0.0, 0.0), sigma)
                Core.addWeighted(y, 1.0 + amount, blur, -amount, 0.0, y)
                blur.release()
                Core.merge(ch, ycc)
                ch.forEach { it.release() }
                val sharp = Mat()
                Imgproc.cvtColor(ycc, sharp, Imgproc.COLOR_YCrCb2RGB)
                ycc.release()
                out.release()
                out = sharp
            } catch (t: Throwable) {
                // keep the merged picture without the extra sharpening
            }
        }
        val bmp = toBitmap(out)
        out.release()
        return bmp
    }
}
