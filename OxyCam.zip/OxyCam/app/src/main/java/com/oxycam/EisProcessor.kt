package com.oxycam

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/** What the processor needs to know about the back camera. */
class EisCamInfo(
    val focalMm: Double,
    val sensorWidthMm: Double,
    val sensorOrientation: Int,
    val realtimeClock: Boolean
) {
    companion object {
        fun readBack(ctx: Context): EisCamInfo {
            try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                for (id in cm.cameraIdList) {
                    val c = cm.getCameraCharacteristics(id)
                    if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                    val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 4.0f
                    val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                    val w = if (s != null) maxOf(s.width, s.height) else 5.6f
                    val o = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                    val src = c.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE)
                    return EisCamInfo(f.toDouble(), w.toDouble(), o, src == CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME)
                }
            } catch (t: Throwable) { }
            return EisCamInfo(4.0, 5.6, 90, false)
        }
    }
}

/**
 * Maps camera frame timestamps (SENSOR_TIMESTAMP) onto the gyro clock (elapsedRealtime).
 * If the camera clock is "realtime" nothing is needed. Otherwise the camera uses CLOCK_MONOTONIC and the offset
 * is measured. Then the real frame latency is checked on the first frames and the offset is corrected if it looks wrong.
 */
class ClockSync(realtime: Boolean) {
    private var delta: Long = if (realtime) 0L else SystemClock.elapsedRealtimeNanos() - System.nanoTime()
    private val lat = LongArray(32)
    private var n = 0
    private var done = false

    fun toGyro(sensorTs: Long): Long = sensorTs + delta

    fun observe(sensorTs: Long, arrivalElapsedNs: Long) {
        if (done) return
        lat[n++] = arrivalElapsedNs - (sensorTs + delta)
        if (n == lat.size) {
            lat.sort()
            val med = lat[lat.size / 2]
            // a camera frame normally reaches us 15..150 ms after it was exposed
            if (med < 0L || med > 250_000_000L) delta += med - 45_000_000L
            done = true
        }
    }
}

/**
 * The EIS brain (runs on the GL thread, once per camera frame):
 *  - converts gyro orientation into the camera sensor frame,
 *  - smooths it with an adaptive SLERP low-pass filter (heavy smoothing when still, quick when you pan),
 *  - keeps the smoothed path inside the crop margin (soft clamp, so no black borders),
 *  - produces one rotation vector per rolling-shutter strip boundary (33 values for 32 strips).
 */
class EisProcessor(private val cam: EisCamInfo, private val buf: GyroEisBuffer) {
    companion object {
        const val STRIPS = 32
        const val CROP = 0.85
    }

    @Volatile var zoom = 1.0
    @Volatile var userOffsetNs = 0L
    @Volatile var expectedFrameNs = 33_333_333L
    var onFrameDrops: (() -> Unit)? = null

    private val clock = ClockSync(cam.realtimeClock)
    private val qdc: DoubleArray

    // frame meta from CaptureResult
    private val metaLock = Any()
    private val mTs = LongArray(24)
    private val mSkew = LongArray(24)
    private val mExp = LongArray(24)
    private var mN = 0
    private var lastSkew = 25_000_000L
    private var lastExp = 12_000_000L

    // filter state
    private val qs = DoubleArray(4)
    private val qPrevNow = DoubleArray(4)
    private val lpw = DoubleArray(3)
    private var haveState = false
    private var lastMid = 0L

    // scratch
    private val qDev = DoubleArray(4)
    private val qNow = DoubleArray(4)
    private val tmp = DoubleArray(4)
    private val tmp2 = DoubleArray(4)
    private val v3 = DoubleArray(3)

    // drop detection
    private var lastFrameTs = 0L
    private var gapSum = 0L
    private var gapN = 0
    private var dropReported = false

    init {
        // camera sensor axes (x right, y down, z forward) written in device axes (x right, y up, z out of screen)
        val th = Math.toRadians(cam.sensorOrientation.toDouble())
        val xu = doubleArrayOf(1.0, 0.0, 0.0)
        val yu = doubleArrayOf(0.0, -1.0, 0.0)
        val zu = doubleArrayOf(0.0, 0.0, -1.0)
        val xs = DoubleArray(3) { cos(th) * xu[it] + sin(th) * yu[it] }
        val ys = DoubleArray(3) { -sin(th) * xu[it] + cos(th) * yu[it] }
        // columns = xs, ys, zu
        val m = doubleArrayOf(
            xs[0], ys[0], zu[0],
            xs[1], ys[1], zu[1],
            xs[2], ys[2], zu[2]
        )
        qdc = QuatMath.fromMatrix(m)
        QuatMath.identity(qs)
        QuatMath.identity(qPrevNow)
    }

    fun onCaptureResult(ts: Long, skew: Long, exp: Long) {
        synchronized(metaLock) {
            val i = mN % mTs.size
            mTs[i] = ts; mSkew[i] = skew; mExp[i] = exp
            mN++
            if (skew in 1_000_000L..80_000_000L) lastSkew = skew
            if (exp in 100_000L..120_000_000L) lastExp = exp
        }
    }

    private fun skewFor(ts: Long): Long = synchronized(metaLock) {
        for (k in 0 until min(mN, mTs.size)) if (abs(mTs[k] - ts) < 2_000_000L && mSkew[k] > 0L) return@synchronized mSkew[k]
        lastSkew
    }

    private fun expFor(ts: Long): Long = synchronized(metaLock) {
        for (k in 0 until min(mN, mTs.size)) if (abs(mTs[k] - ts) < 2_000_000L && mExp[k] > 0L) return@synchronized mExp[k]
        lastExp
    }

    /** Focal length in uv units for the buffer: ray.x = (u-0.5) * invF[0], ray.y = -(v-0.5) * invF[1]. */
    fun invFocal(bufW: Int, bufH: Int, out: FloatArray) {
        val z = zoom.coerceAtLeast(1.0)
        out[0] = (cam.sensorWidthMm / (cam.focalMm * z)).toFloat()
        out[1] = (bufH.toDouble() / bufW * cam.sensorWidthMm / (cam.focalMm * z)).toFloat()
    }

    private fun softClamp(v: Double, m: Double) = m * tanh(v / m)

    /**
     * Fill rv with 33 rotation vectors (x,y,z each, camera sensor frame). outT = list of per-output matrices
     * T = original^-1 * updated (column-major 4x4) that tell how much of the sensor each output shows.
     * Returns false if there is no gyro data yet (rv is then all zero = no correction).
     */
    fun update(ts: Long, arrivalNs: Long, bufW: Int, bufH: Int, outT: List<FloatArray>, rv: FloatArray): Boolean {
        java.util.Arrays.fill(rv, 0f)
        noteFrame(ts)
        clock.observe(ts, arrivalNs)
        val skew = skewFor(ts)
        val expT = expFor(ts)
        val off = userOffsetNs
        val tStart = clock.toGyro(ts) + off
        val tMid = tStart + skew / 2 + expT / 2

        if (!buf.quatAt(tMid, qDev)) return false
        QuatMath.mul(qDev, qdc, qNow)

        if (!haveState) {
            qs[0] = qNow[0]; qs[1] = qNow[1]; qs[2] = qNow[2]; qs[3] = qNow[3]
            qPrevNow[0] = qNow[0]; qPrevNow[1] = qNow[1]; qPrevNow[2] = qNow[2]; qPrevNow[3] = qNow[3]
            lpw[0] = 0.0; lpw[1] = 0.0; lpw[2] = 0.0
            lastMid = tMid
            haveState = true
        }
        val dt = ((tMid - lastMid) * 1e-9).coerceIn(0.001, 0.1)
        lastMid = tMid

        // angular velocity of the real camera (camera frame), low-passed: shake averages out, a pan stays
        QuatMath.conj(qPrevNow, tmp)
        QuatMath.mul(tmp, qNow, tmp)
        QuatMath.log(tmp, v3)
        val k = 1.0 - exp(-dt / 0.3)
        for (i in 0..2) lpw[i] += (v3[i] / dt - lpw[i]) * k
        qPrevNow[0] = qNow[0]; qPrevNow[1] = qNow[1]; qPrevNow[2] = qNow[2]; qPrevNow[3] = qNow[3]
        val pan = hypot(hypot(lpw[0], lpw[1]), lpw[2])

        // adaptive SLERP low-pass: tau 0.30 s while steady, 0.07 s during a deliberate pan
        val tau = 0.30 + (0.07 - 0.30) * QuatMath.smoothstep(0.10, 0.70, pan)
        val alpha = 1.0 - exp(-dt / tau)
        QuatMath.slerp(qs, qNow, alpha, qs)

        // keep the smooth path inside the crop margin
        val fPx = cam.focalMm / cam.sensorWidthMm * bufW * zoom.coerceAtLeast(1.0)
        var ru = bufW.toDouble()
        var rvv = bufH.toDouble()
        for (t in outT) {
            ru = min(ru, (abs(t[0]) + abs(t[4])) * bufW.toDouble())
            rvv = min(rvv, (abs(t[1]) + abs(t[5])) * bufH.toDouble())
        }
        val half = (1.0 - CROP) / 2.0
        val mu = half * ru * 0.9
        val mv = half * rvv * 0.9
        val limX = atan(mv / fPx)                     // about sensor x: moves the picture up/down
        val limY = atan(mu / fPx)                     // about sensor y: moves it left/right
        val limZ = min(mu, mv) / (0.5 * hypot(ru, rvv))
        QuatMath.conj(qNow, tmp)
        QuatMath.mul(tmp, qs, tmp)
        QuatMath.log(tmp, v3)
        v3[0] = softClamp(v3[0], limX)
        v3[1] = softClamp(v3[1], limY)
        v3[2] = softClamp(v3[2], limZ)
        QuatMath.exp(v3, tmp)
        QuatMath.mul(qNow, tmp, qs)
        QuatMath.normalize(qs)

        // per-strip rotation: where was the sensor when this row was exposed, relative to the smooth path
        for (j in 0..STRIPS) {
            val tRow = tStart + (skew.toDouble() * j / STRIPS).toLong() + expT / 2
            if (!buf.quatAt(tRow, tmp2)) continue
            QuatMath.mul(tmp2, qdc, tmp2)
            QuatMath.conj(tmp2, tmp2)
            QuatMath.mul(tmp2, qs, tmp)
            QuatMath.log(tmp, v3)
            rv[j * 3] = v3[0].toFloat()
            rv[j * 3 + 1] = v3[1].toFloat()
            rv[j * 3 + 2] = v3[2].toFloat()
        }
        return true
    }

    private fun noteFrame(ts: Long) {
        if (lastFrameTs != 0L) {
            gapSum += ts - lastFrameTs
            gapN++
            if (gapN == 30) {
                val mean = gapSum / gapN
                if (!dropReported && mean > expectedFrameNs * 1.45) {
                    dropReported = true
                    onFrameDrops?.invoke()
                }
                gapSum = 0
                gapN = 0
            }
        }
        lastFrameTs = ts
    }

    fun reset() {
        haveState = false
    }
}
