package com.oxycam

import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executor

/**
 * Applies the vibrancy colour matrix to the recorded video (the viewfinder gets the same matrix separately).
 * Camera frames go into an OpenGL shader and are drawn into the video encoder's surface.
 */
object VideoStyle : SurfaceProcessor {
    private val thread = HandlerThread("OxyCamGL").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { r -> handler.post(r) }

    /** The effect to attach to the VideoCapture use case. */
    val effect: CameraEffect by lazy { StyleEffect(executor, VideoStyle) }

    /** CameraX 1.3 has no CameraEffect builder, so the effect is a small subclass that targets video only. */
    private class StyleEffect(executor: Executor, processor: SurfaceProcessor) :
        CameraEffect(
            VIDEO_CAPTURE, executor, processor,
            androidx.core.util.Consumer<Throwable> { }
        )

    /** EIS+ effect: one shared GL stream that feeds the viewfinder (Preview) and the recording (VideoCapture). */
    val plusEffect: CameraEffect by lazy { PlusEffect(executor, VideoStyle) }

    private class PlusEffect(executor: Executor, processor: SurfaceProcessor) :
        CameraEffect(
            PREVIEW or VIDEO_CAPTURE, executor, processor,
            androidx.core.util.Consumer<Throwable> { }
        )

    @Volatile private var plus = false
    @Volatile private var appCtx: Context? = null

    /** Context used to start the gyroscope for EIS+. */
    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    /** Switches the gyro stabilization (EIS+) on or off for the next bind. */
    fun setPlus(on: Boolean) {
        plus = on
    }

    @Volatile private var colour: FloatArray? = null

    /** Sets the colour matrix used for the next frames (null = no change). */
    fun setMatrix(m: ColorMatrix?) {
        colour = m?.array?.copyOf()
    }

    // ---- everything below runs on the GL thread ----

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uTexMat = 0
    private var uR = 0
    private var uG = 0
    private var uB = 0
    private var uO = 0

    // EIS+ program (16-strip mesh, per-strip homography)
    private var pProgram = 0
    private var pPos = 0
    private var pTex = 0
    private var pM0 = 0
    private var pM1 = 0
    private var pM2 = 0
    private var pTexMat = 0
    private var pR = 0
    private var pG = 0
    private var pB = 0
    private var pO = 0
    private var inW = 0
    private var inH = 0
    private var gyroOk = false

    private const val ROWS = GyroStab.STRIPS + 1
    private const val VERTS = ROWS * 2
    private const val STRIDE = 13
    private val plusVerts = FloatArray(VERTS * STRIDE)
    private val plusBuf: FloatBuffer =
        ByteBuffer.allocateDirect(VERTS * STRIDE * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private var inputTex = 0
    private var inputSt: SurfaceTexture? = null
    private val outputs = LinkedHashMap<SurfaceOutput, EGLSurface>()
    private val texMat = FloatArray(16)
    private val outMat = FloatArray(16)

    private val posBuf: FloatBuffer = floatBuf(
        floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )
    private val texBuf: FloatBuffer = floatBuf(
        floatArrayOf(0f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )

    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(a)
            it.position(0)
        }

    private const val VERTEX = """
attribute vec4 aPos;
attribute vec4 aTex;
uniform mat4 uTexMat;
varying vec2 vTex;
void main() {
    gl_Position = aPos;
    vTex = (uTexMat * aTex).xy;
}
"""

    private const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
varying vec2 vTex;
uniform samplerExternalOES sTex;
uniform vec3 uR;
uniform vec3 uG;
uniform vec3 uB;
uniform vec3 uO;
void main() {
    vec3 c = texture2D(sTex, vTex).rgb;
    vec3 o = vec3(dot(c, uR), dot(c, uG), dot(c, uB)) + uO;
    gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    private const val VERTEX_PLUS = """
attribute vec2 aPos;
attribute vec2 aTex;
attribute vec3 aM0;
attribute vec3 aM1;
attribute vec3 aM2;
uniform mat4 uTexMat;
varying vec2 vTex;
varying vec3 vM0;
varying vec3 vM1;
varying vec3 vM2;
void main() {
    gl_Position = vec4(aPos, 0.0, 1.0);
    vTex = (uTexMat * vec4(aTex, 0.0, 1.0)).xy;
    vM0 = aM0;
    vM1 = aM1;
    vM2 = aM2;
}
"""

    private const val FRAGMENT_PLUS = """
#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vTex;
varying vec3 vM0;
varying vec3 vM1;
varying vec3 vM2;
uniform samplerExternalOES sTex;
uniform vec3 uR;
uniform vec3 uG;
uniform vec3 uB;
uniform vec3 uO;
void main() {
    vec3 p = vec3(vTex, 1.0);
    vec3 h = vec3(dot(vM0, p), dot(vM1, p), dot(vM2, p));
    vec2 t = h.xy / h.z;
    vec3 c = texture2D(sTex, t).rgb;
    vec3 o = vec3(dot(c, uR), dot(c, uG), dot(c, uB)) + uO;
    gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun initGl() {
        if (context != EGL14.EGL_NO_CONTEXT) return
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(display, ver, 0, ver, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(display, attrs, 0, cfgs, 0, 1, n, 0)
        config = cfgs[0] ?: throw RuntimeException("no EGL config")
        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        pbuffer = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link failed")
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")
        uR = GLES20.glGetUniformLocation(program, "uR")
        uG = GLES20.glGetUniformLocation(program, "uG")
        uB = GLES20.glGetUniformLocation(program, "uB")
        uO = GLES20.glGetUniformLocation(program, "uO")
        try {
            val pvs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_PLUS)
            val pfs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_PLUS)
            val pp = GLES20.glCreateProgram()
            GLES20.glAttachShader(pp, pvs)
            GLES20.glAttachShader(pp, pfs)
            GLES20.glLinkProgram(pp)
            val pok = IntArray(1)
            GLES20.glGetProgramiv(pp, GLES20.GL_LINK_STATUS, pok, 0)
            if (pok[0] == 0) throw RuntimeException("link failed")
            pPos = GLES20.glGetAttribLocation(pp, "aPos")
            pTex = GLES20.glGetAttribLocation(pp, "aTex")
            pM0 = GLES20.glGetAttribLocation(pp, "aM0")
            pM1 = GLES20.glGetAttribLocation(pp, "aM1")
            pM2 = GLES20.glGetAttribLocation(pp, "aM2")
            pTexMat = GLES20.glGetUniformLocation(pp, "uTexMat")
            pR = GLES20.glGetUniformLocation(pp, "uR")
            pG = GLES20.glGetUniformLocation(pp, "uG")
            pB = GLES20.glGetUniformLocation(pp, "uB")
            pO = GLES20.glGetUniformLocation(pp, "uO")
            pProgram = pp
        } catch (t: Throwable) {
            pProgram = 0
        }
    }

    override fun onInputSurface(request: SurfaceRequest) {
        try {
            initGl()
        } catch (t: Throwable) {
            request.willNotProvideSurface()
            return
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val st = SurfaceTexture(tex[0])
        st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
        val surface = Surface(st)
        inputTex = tex[0]
        inputSt = st
        inW = request.resolution.width
        inH = request.resolution.height
        val ctx = appCtx
        val gyro = plus && pProgram != 0 && ctx != null && GyroStab.acquire(ctx)
        gyroOk = gyro
        st.setOnFrameAvailableListener(SurfaceTexture.OnFrameAvailableListener { drawFrame() }, handler)
        request.provideSurface(surface, executor) {
            st.setOnFrameAvailableListener(null)
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                GLES20.glDeleteTextures(1, intArrayOf(tex[0]), 0)
            } catch (t: Throwable) { }
            surface.release()
            st.release()
            if (gyro) GyroStab.release()
            if (inputSt === st) inputSt = null
        }
    }

    override fun onOutputSurface(output: SurfaceOutput) {
        try {
            initGl()
        } catch (t: Throwable) {
            output.close()
            return
        }
        val surf = output.getSurface(executor) { ev ->
            if (ev.eventCode == SurfaceOutput.Event.EVENT_REQUEST_CLOSE) closeOutput(output)
        }
        val es = EGL14.eglCreateWindowSurface(display, config, surf, intArrayOf(EGL14.EGL_NONE), 0)
        outputs[output] = es
    }

    private fun closeOutput(o: SurfaceOutput) {
        val es = outputs.remove(o)
        if (es != null) {
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                EGL14.eglDestroySurface(display, es)
            } catch (t: Throwable) { }
        }
        o.close()
    }

    private fun drawFrame() {
        val st = inputSt ?: return
        try {
            EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
            st.updateTexImage()
        } catch (t: Throwable) {
            return
        }
        st.getTransformMatrix(texMat)
        val ts = st.timestamp
        val a = colour
        if (plus && gyroOk && pProgram != 0 && inW > 0 && inH > 0) {
            var done = false
            try {
                done = drawPlus(ts, a)
            } catch (t: Throwable) { }
            if (done) {
                try { EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context) } catch (t: Throwable) { }
                return
            }
        }
        for ((o, es) in outputs.entries.toList()) {
            try {
                EGL14.eglMakeCurrent(display, es, es, context)
                o.updateTransformMatrix(outMat, texMat)
                val sz = o.size
                GLES20.glViewport(0, 0, sz.width, sz.height)
                GLES20.glUseProgram(program)
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glVertexAttribPointer(aPos, 4, GLES20.GL_FLOAT, false, 0, posBuf)
                GLES20.glEnableVertexAttribArray(aTex)
                GLES20.glVertexAttribPointer(aTex, 4, GLES20.GL_FLOAT, false, 0, texBuf)
                GLES20.glUniformMatrix4fv(uTexMat, 1, false, outMat, 0)
                if (a != null && a.size >= 20) {
                    GLES20.glUniform3f(uR, a[0], a[1], a[2])
                    GLES20.glUniform3f(uG, a[5], a[6], a[7])
                    GLES20.glUniform3f(uB, a[10], a[11], a[12])
                    GLES20.glUniform3f(uO, a[4] / 255f, a[9] / 255f, a[14] / 255f)
                } else {
                    GLES20.glUniform3f(uR, 1f, 0f, 0f)
                    GLES20.glUniform3f(uG, 0f, 1f, 0f)
                    GLES20.glUniform3f(uB, 0f, 0f, 1f)
                    GLES20.glUniform3f(uO, 0f, 0f, 0f)
                }
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, inputTex)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

                EGLExt.eglPresentationTimeANDROID(display, es, ts)
                EGL14.eglSwapBuffers(display, es)
            } catch (t: Throwable) { }
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
    }

    /**
     * EIS+ draw: the camera texture is drawn on a 1 x 16 strip mesh (17 rows x 2 columns, one triangle strip).
     * Every row has its own stabilizing homography (rolling shutter), interpolated across each strip.
     * Returns false if the plain path should draw this frame instead.
     */
    private fun drawPlus(ts: Long, a: FloatArray?): Boolean {
        val list = outputs.entries.toList()
        val n = list.size
        if (n == 0) return true
        val mats = Array(n) { FloatArray(16) }
        val invs = Array(n) { FloatArray(16) }
        val wins = ArrayList<DoubleArray>(n)
        val vin = FloatArray(4)
        val vout = FloatArray(4)
        for (i in 0 until n) {
            list[i].key.updateTransformMatrix(mats[i], texMat)
            if (!Matrix.invertM(invs[i], 0, mats[i], 0)) return false
            var mnx = Double.MAX_VALUE
            var mxx = -Double.MAX_VALUE
            var mny = Double.MAX_VALUE
            var mxy = -Double.MAX_VALUE
            for (c in 0..3) {
                vin[0] = (c and 1).toFloat()
                vin[1] = (c shr 1).toFloat()
                vin[2] = 0f
                vin[3] = 1f
                Matrix.multiplyMV(vout, 0, mats[i], 0, vin, 0)
                val x = (vout[0] / vout[3]).toDouble()
                val y = (vout[1] / vout[3]).toDouble()
                if (x < mnx) mnx = x
                if (x > mxx) mxx = x
                if (y < mny) mny = y
                if (y > mxy) mxy = y
            }
            wins.add(doubleArrayOf(mnx, mxx, mny, mxy))
        }
        val hs = List(n) { FloatArray(ROWS * 9) }
        if (!GyroStab.solve(ts, inW, inH, wins, hs)) {
            // no gyro data yet: identity, still cropped by the same 15% so the picture does not jump later
            for (h in hs) {
                for (k in 0 until ROWS) {
                    for (e in 0 until 9) h[k * 9 + e] = if (e == 0 || e == 4 || e == 8) 1f else 0f
                }
            }
        }
        val zc = GyroStab.CROP_ZOOM.toFloat()
        for (i in 0 until n) {
            val w = wins[i]
            val h = hs[i]
            var p = 0
            for (k in 0 until ROWS) {
                val ty = (w[2] + (w[3] - w[2]) * k / GyroStab.STRIPS).toFloat()
                for (c in 0..1) {
                    vin[0] = (if (c == 0) w[0] else w[1]).toFloat()
                    vin[1] = ty
                    vin[2] = 0f
                    vin[3] = 1f
                    Matrix.multiplyMV(vout, 0, invs[i], 0, vin, 0)
                    val u = vout[0] / vout[3]
                    val v = vout[1] / vout[3]
                    plusVerts[p++] = 2f * u - 1f
                    plusVerts[p++] = 2f * v - 1f
                    plusVerts[p++] = 0.5f + (u - 0.5f) / zc
                    plusVerts[p++] = 0.5f + (v - 0.5f) / zc
                    for (e in 0 until 9) plusVerts[p++] = h[k * 9 + e]
                }
            }
            plusBuf.position(0)
            plusBuf.put(plusVerts)

            val es = list[i].value
            EGL14.eglMakeCurrent(display, es, es, context)
            val sz = list[i].key.size
            GLES20.glViewport(0, 0, sz.width, sz.height)
            GLES20.glUseProgram(pProgram)
            val stride = STRIDE * 4
            plusBuf.position(0)
            GLES20.glEnableVertexAttribArray(pPos)
            GLES20.glVertexAttribPointer(pPos, 2, GLES20.GL_FLOAT, false, stride, plusBuf)
            plusBuf.position(2)
            GLES20.glEnableVertexAttribArray(pTex)
            GLES20.glVertexAttribPointer(pTex, 2, GLES20.GL_FLOAT, false, stride, plusBuf)
            plusBuf.position(4)
            GLES20.glEnableVertexAttribArray(pM0)
            GLES20.glVertexAttribPointer(pM0, 3, GLES20.GL_FLOAT, false, stride, plusBuf)
            plusBuf.position(7)
            GLES20.glEnableVertexAttribArray(pM1)
            GLES20.glVertexAttribPointer(pM1, 3, GLES20.GL_FLOAT, false, stride, plusBuf)
            plusBuf.position(10)
            GLES20.glEnableVertexAttribArray(pM2)
            GLES20.glVertexAttribPointer(pM2, 3, GLES20.GL_FLOAT, false, stride, plusBuf)
            GLES20.glUniformMatrix4fv(pTexMat, 1, false, mats[i], 0)
            if (a != null && a.size >= 20) {
                GLES20.glUniform3f(pR, a[0], a[1], a[2])
                GLES20.glUniform3f(pG, a[5], a[6], a[7])
                GLES20.glUniform3f(pB, a[10], a[11], a[12])
                GLES20.glUniform3f(pO, a[4] / 255f, a[9] / 255f, a[14] / 255f)
            } else {
                GLES20.glUniform3f(pR, 1f, 0f, 0f)
                GLES20.glUniform3f(pG, 0f, 1f, 0f)
                GLES20.glUniform3f(pB, 0f, 0f, 1f)
                GLES20.glUniform3f(pO, 0f, 0f, 0f)
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, inputTex)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, VERTS)
            EGLExt.eglPresentationTimeANDROID(display, es, ts)
            EGL14.eglSwapBuffers(display, es)
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        return true
    }
}
