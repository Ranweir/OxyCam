package com.oxycam

import android.graphics.ColorMatrix
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executor

/**
 * Applies the vibrancy colour matrix to the recorded video (the viewfinder gets the same matrix separately).
 * Camera frames go into an OpenGL shader and are drawn into the video encoder's surface.
 */
object VideoStyle : SurfaceProcessor {
    private val thread = HandlerThread("OxyCamGL").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { r -> handler.post(r) }

    /** The effect to attach to the VideoCapture use case. */
    val effect: CameraEffect by lazy { StyleEffect(executor, VideoStyle) }

    /** CameraX 1.3 has no CameraEffect builder, so the effect is a small subclass that targets video only. */
    private class StyleEffect(executor: Executor, processor: SurfaceProcessor) :
        CameraEffect(
            VIDEO_CAPTURE, executor, processor,
            androidx.core.util.Consumer<Throwable> { }
        )

    @Volatile private var colour: FloatArray? = null
    @Volatile private var nrLevel = 0

    /** Video noise reduction level 0 (off) .. 4 (max). */
    fun setNoise(level: Int) {
        nrLevel = level.coerceIn(0, 4)
    }

    /** Sets the colour matrix used for the next frames (null = no change). */
    fun setMatrix(m: ColorMatrix?) {
        colour = m?.array?.copyOf()
    }

    // ---- everything below runs on the GL thread ----

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uTexMat = 0
    private var uR = 0
    private var uG = 0
    private var uB = 0
    private var uO = 0

    private var inputTex = 0
    private var inputSt: SurfaceTexture? = null
    private val outputs = LinkedHashMap<SurfaceOutput, EGLSurface>()
    private val texMat = FloatArray(16)
    private val outMat = FloatArray(16)

    private val posBuf: FloatBuffer = floatBuf(
        floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )
    private val texBuf: FloatBuffer = floatBuf(
        floatArrayOf(0f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )

    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(a)
            it.position(0)
        }

    private const val VERTEX = """
attribute vec4 aPos;
attribute vec4 aTex;
uniform mat4 uTexMat;
varying vec2 vTex;
void main() {
    gl_Position = aPos;
    vTex = (uTexMat * aTex).xy;
}
"""

    private const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
varying vec2 vTex;
uniform samplerExternalOES sTex;
uniform vec3 uR;
uniform vec3 uG;
uniform vec3 uB;
uniform vec3 uO;
void main() {
    vec3 c = texture2D(sTex, vTex).rgb;
    vec3 o = vec3(dot(c, uR), dot(c, uG), dot(c, uB)) + uO;
    gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    // ---- noise reduction: pass A = denoise (bilateral + motion-aware temporal filter) into a texture, pass B = colour + output ----
    private const val NR_VERTEX = """
attribute vec4 aPos;
attribute vec4 aTex;
varying vec2 vQ;
void main() {
    gl_Position = aPos;
    vQ = aTex.xy;
}
"""

    private const val NR_FRAGMENT_A = """
#extension GL_OES_EGL_image_external : require
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vQ;
uniform samplerExternalOES sTex;
uniform sampler2D sPrev;
uniform mat4 uTexMat;
uniform vec2 uPx;
uniform float uRad;
uniform float uInv;
uniform float uSig;
uniform float uTemporal;
vec3 fetch(vec2 q) {
    return texture2D(sTex, (uTexMat * vec4(q, 0.0, 1.0)).xy).rgb;
}
void tap(vec2 q, vec3 c, float base, inout vec3 sum, inout float ws) {
    vec3 v = fetch(q);
    vec3 d = v - c;
    float w = base * exp(-dot(d, d) * uInv);
    sum += v * w;
    ws += w;
}
void main() {
    vec3 c = fetch(vQ);
    vec3 sum = c;
    float ws = 1.0;
    vec2 o = uPx * uRad;
    tap(vQ + vec2(o.x, 0.0), c, 1.0, sum, ws);
    tap(vQ - vec2(o.x, 0.0), c, 1.0, sum, ws);
    tap(vQ + vec2(0.0, o.y), c, 1.0, sum, ws);
    tap(vQ - vec2(0.0, o.y), c, 1.0, sum, ws);
    tap(vQ + o, c, 0.7, sum, ws);
    tap(vQ - o, c, 0.7, sum, ws);
    tap(vQ + vec2(o.x, -o.y), c, 0.7, sum, ws);
    tap(vQ + vec2(-o.x, o.y), c, 0.7, sum, ws);
    vec3 s = sum / ws;
    vec3 p = texture2D(sPrev, vQ).rgb;
    vec3 ad = abs(s - p);
    float diff = max(ad.r, max(ad.g, ad.b));
    float m = 1.0 - smoothstep(uSig, uSig * 3.0 + 0.04, diff);
    gl_FragColor = vec4(mix(s, p, uTemporal * m), 1.0);
}
"""

    private const val NR_FRAGMENT_B = """
precision mediump float;
varying vec2 vQ;
uniform sampler2D sTex;
uniform vec3 uR;
uniform vec3 uG;
uniform vec3 uB;
uniform vec3 uO;
void main() {
    vec3 c = texture2D(sTex, vQ).rgb;
    vec3 o = vec3(dot(c, uR), dot(c, uG), dot(c, uB)) + uO;
    gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    private var progA = 0
    private var aPosA = 0
    private var aTexA = 0
    private var uTexMatA = 0
    private var uPxA = 0
    private var uRadA = 0
    private var uInvA = 0
    private var uSigA = 0
    private var uTemporalA = 0
    private var sTexA = 0
    private var sPrevA = 0
    private var progB = 0
    private var aPosB = 0
    private var aTexB = 0
    private var uRB = 0
    private var uGB = 0
    private var uBB = 0
    private var uOB = 0
    private var sTexB = 0
    private var nrBroken = false

    private class NrState(val w: Int, val h: Int) {
        val tex = IntArray(2)
        val fbo = IntArray(2)
        var cur = 0
        var hasPrev = false
    }

    private val nrStates = HashMap<SurfaceOutput, NrState>()

    private fun buildProgram(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        val pr = GLES20.glCreateProgram()
        GLES20.glAttachShader(pr, v)
        GLES20.glAttachShader(pr, f)
        GLES20.glLinkProgram(pr)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link failed")
        return pr
    }

    private fun initNr() {
        try {
            progA = buildProgram(NR_VERTEX, NR_FRAGMENT_A)
            aPosA = GLES20.glGetAttribLocation(progA, "aPos")
            aTexA = GLES20.glGetAttribLocation(progA, "aTex")
            uTexMatA = GLES20.glGetUniformLocation(progA, "uTexMat")
            uPxA = GLES20.glGetUniformLocation(progA, "uPx")
            uRadA = GLES20.glGetUniformLocation(progA, "uRad")
            uInvA = GLES20.glGetUniformLocation(progA, "uInv")
            uSigA = GLES20.glGetUniformLocation(progA, "uSig")
            uTemporalA = GLES20.glGetUniformLocation(progA, "uTemporal")
            sTexA = GLES20.glGetUniformLocation(progA, "sTex")
            sPrevA = GLES20.glGetUniformLocation(progA, "sPrev")
            progB = buildProgram(NR_VERTEX, NR_FRAGMENT_B)
            aPosB = GLES20.glGetAttribLocation(progB, "aPos")
            aTexB = GLES20.glGetAttribLocation(progB, "aTex")
            uRB = GLES20.glGetUniformLocation(progB, "uR")
            uGB = GLES20.glGetUniformLocation(progB, "uG")
            uBB = GLES20.glGetUniformLocation(progB, "uB")
            uOB = GLES20.glGetUniformLocation(progB, "uO")
            sTexB = GLES20.glGetUniformLocation(progB, "sTex")
        } catch (t: Throwable) {
            progA = 0
            progB = 0
        }
    }

    private fun createNr(w: Int, h: Int): NrState {
        val st = NrState(w, h)
        GLES20.glGenTextures(2, st.tex, 0)
        GLES20.glGenFramebuffers(2, st.fbo, 0)
        for (i in 0..1) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, st.tex[i])
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, st.fbo[i])
            GLES20.glFramebufferTexture2D(
                GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, st.tex[i], 0
            )
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        return st
    }

    private fun freeNr(st: NrState) {
        GLES20.glDeleteFramebuffers(2, st.fbo, 0)
        GLES20.glDeleteTextures(2, st.tex, 0)
    }

    private fun drawDenoised(o: SurfaceOutput, w: Int, h: Int, a: FloatArray?) {
        var st = nrStates[o]
        if (st == null || st.w != w || st.h != h) {
            if (st != null) freeNr(st)
            st = createNr(w, h)
            nrStates[o] = st
        }
        val lvl = nrLevel.coerceIn(1, 4)
        val sigma = floatArrayOf(0f, 0.04f, 0.06f, 0.085f, 0.12f)[lvl]
        val rad = floatArrayOf(0f, 1f, 1.25f, 1.6f, 2f)[lvl]
        val temporal = floatArrayOf(0f, 0.35f, 0.55f, 0.7f, 0.82f)[lvl]

        // pass A: denoise into the current history texture, reading the previous one
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, st.fbo[st.cur])
        GLES20.glViewport(0, 0, w, h)
        GLES20.glUseProgram(progA)
        GLES20.glEnableVertexAttribArray(aPosA)
        GLES20.glVertexAttribPointer(aPosA, 4, GLES20.GL_FLOAT, false, 0, posBuf)
        GLES20.glEnableVertexAttribArray(aTexA)
        GLES20.glVertexAttribPointer(aTexA, 4, GLES20.GL_FLOAT, false, 0, texBuf)
        GLES20.glUniformMatrix4fv(uTexMatA, 1, false, outMat, 0)
        GLES20.glUniform2f(uPxA, 1f / w, 1f / h)
        GLES20.glUniform1f(uRadA, rad)
        GLES20.glUniform1f(uInvA, 1f / (2f * sigma * sigma))
        GLES20.glUniform1f(uSigA, sigma)
        GLES20.glUniform1f(uTemporalA, if (st.hasPrev) temporal else 0f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, inputTex)
        GLES20.glUniform1i(sTexA, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, st.tex[1 - st.cur])
        GLES20.glUniform1i(sPrevA, 1)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        // pass B: colour matrix, drawn into the video encoder surface
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glUseProgram(progB)
        GLES20.glEnableVertexAttribArray(aPosB)
        GLES20.glVertexAttribPointer(aPosB, 4, GLES20.GL_FLOAT, false, 0, posBuf)
        GLES20.glEnableVertexAttribArray(aTexB)
        GLES20.glVertexAttribPointer(aTexB, 4, GLES20.GL_FLOAT, false, 0, texBuf)
        if (a != null && a.size >= 20) {
            GLES20.glUniform3f(uRB, a[0], a[1], a[2])
            GLES20.glUniform3f(uGB, a[5], a[6], a[7])
            GLES20.glUniform3f(uBB, a[10], a[11], a[12])
            GLES20.glUniform3f(uOB, a[4] / 255f, a[9] / 255f, a[14] / 255f)
        } else {
            GLES20.glUniform3f(uRB, 1f, 0f, 0f)
            GLES20.glUniform3f(uGB, 0f, 1f, 0f)
            GLES20.glUniform3f(uBB, 0f, 0f, 1f)
            GLES20.glUniform3f(uOB, 0f, 0f, 0f)
        }
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, st.tex[st.cur])
        GLES20.glUniform1i(sTexB, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        st.cur = 1 - st.cur
        st.hasPrev = true
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun initGl() {
        if (context != EGL14.EGL_NO_CONTEXT) return
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(display, ver, 0, ver, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(display, attrs, 0, cfgs, 0, 1, n, 0)
        config = cfgs[0] ?: throw RuntimeException("no EGL config")
        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        pbuffer = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link failed")
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")
        uR = GLES20.glGetUniformLocation(program, "uR")
        uG = GLES20.glGetUniformLocation(program, "uG")
        uB = GLES20.glGetUniformLocation(program, "uB")
        uO = GLES20.glGetUniformLocation(program, "uO")
        initNr()
    }

    override fun onInputSurface(request: SurfaceRequest) {
        try {
            initGl()
        } catch (t: Throwable) {
            request.willNotProvideSurface()
            return
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val st = SurfaceTexture(tex[0])
        st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
        val surface = Surface(st)
        inputTex = tex[0]
        inputSt = st
        st.setOnFrameAvailableListener(SurfaceTexture.OnFrameAvailableListener { drawFrame() }, handler)
        request.provideSurface(surface, executor) {
            st.setOnFrameAvailableListener(null)
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                GLES20.glDeleteTextures(1, intArrayOf(tex[0]), 0)
            } catch (t: Throwable) { }
            surface.release()
            st.release()
            if (inputSt === st) inputSt = null
        }
    }

    override fun onOutputSurface(output: SurfaceOutput) {
        try {
            initGl()
        } catch (t: Throwable) {
            output.close()
            return
        }
        val surf = output.getSurface(executor) { ev ->
            if (ev.eventCode == SurfaceOutput.Event.EVENT_REQUEST_CLOSE) closeOutput(output)
        }
        val es = EGL14.eglCreateWindowSurface(display, config, surf, intArrayOf(EGL14.EGL_NONE), 0)
        outputs[output] = es
    }

    private fun closeOutput(o: SurfaceOutput) {
        val es = outputs.remove(o)
        if (es != null) {
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                nrStates.remove(o)?.let { freeNr(it) }
                EGL14.eglDestroySurface(display, es)
            } catch (t: Throwable) { }
        }
        o.close()
    }

    private fun drawFrame() {
        val st = inputSt ?: return
        try {
            EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
            st.updateTexImage()
        } catch (t: Throwable) {
            return
        }
        st.getTransformMatrix(texMat)
        val ts = st.timestamp
        val a = colour
        for ((o, es) in outputs.entries.toList()) {
            try {
                EGL14.eglMakeCurrent(display, es, es, context)
                o.updateTransformMatrix(outMat, texMat)
                val sz = o.size
                var done = false
                if (nrLevel > 0 && progA != 0 && !nrBroken) {
                    try {
                        drawDenoised(o, sz.width, sz.height, a)
                        done = true
                    } catch (t: Throwable) {
                        nrBroken = true
                        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                    }
                }
                if (!done) {
                    GLES20.glViewport(0, 0, sz.width, sz.height)
                    GLES20.glUseProgram(program)
                    GLES20.glEnableVertexAttribArray(aPos)
                    GLES20.glVertexAttribPointer(aPos, 4, GLES20.GL_FLOAT, false, 0, posBuf)
                    GLES20.glEnableVertexAttribArray(aTex)
                    GLES20.glVertexAttribPointer(aTex, 4, GLES20.GL_FLOAT, false, 0, texBuf)
                    GLES20.glUniformMatrix4fv(uTexMat, 1, false, outMat, 0)
                    if (a != null && a.size >= 20) {
                        GLES20.glUniform3f(uR, a[0], a[1], a[2])
                        GLES20.glUniform3f(uG, a[5], a[6], a[7])
                        GLES20.glUniform3f(uB, a[10], a[11], a[12])
                        GLES20.glUniform3f(uO, a[4] / 255f, a[9] / 255f, a[14] / 255f)
                    } else {
                        GLES20.glUniform3f(uR, 1f, 0f, 0f)
                        GLES20.glUniform3f(uG, 0f, 1f, 0f)
                        GLES20.glUniform3f(uB, 0f, 0f, 1f)
                        GLES20.glUniform3f(uO, 0f, 0f, 0f)
                    }
                    GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, inputTex)
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                }
                EGLExt.eglPresentationTimeANDROID(display, es, ts)
                EGL14.eglSwapBuffers(display, es)
            } catch (t: Throwable) { }
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
    }
}
