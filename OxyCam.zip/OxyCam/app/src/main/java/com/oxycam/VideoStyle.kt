package com.oxycam

import android.graphics.ColorMatrix
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executor

/**
 * Applies the vibrancy colour matrix to the recorded video (the viewfinder gets the same matrix separately).
 * Camera frames go into an OpenGL shader and are drawn into the video encoder's surface.
 */
object VideoStyle : SurfaceProcessor {
    private val thread = HandlerThread("OxyCamGL").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { r -> handler.post(r) }

    /** The effect to attach to the VideoCapture use case. */
    val effect: CameraEffect by lazy { StyleEffect(executor, VideoStyle) }

    /** CameraX 1.3 has no CameraEffect builder, so the effect is a small subclass that targets video only. */
    private class StyleEffect(executor: Executor, processor: SurfaceProcessor) :
        CameraEffect(
            VIDEO_CAPTURE, executor, processor,
            androidx.core.util.Consumer<Throwable> { }
        )

    @Volatile private var colour: FloatArray? = null

    /** Sets the colour matrix used for the next frames (null = no change). */
    fun setMatrix(m: ColorMatrix?) {
        colour = m?.array?.copyOf()
    }

    // ---- everything below runs on the GL thread ----

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uTexMat = 0
    private var uR = 0
    private var uG = 0
    private var uB = 0
    private var uO = 0

    private var inputTex = 0
    private var inputSt: SurfaceTexture? = null
    private val outputs = LinkedHashMap<SurfaceOutput, EGLSurface>()
    private val texMat = FloatArray(16)
    private val outMat = FloatArray(16)

    private val posBuf: FloatBuffer = floatBuf(
        floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )
    private val texBuf: FloatBuffer = floatBuf(
        floatArrayOf(0f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
    )

    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(a)
            it.position(0)
        }

    private const val VERTEX = """
attribute vec4 aPos;
attribute vec4 aTex;
uniform mat4 uTexMat;
varying vec2 vTex;
void main() {
    gl_Position = aPos;
    vTex = (uTexMat * aTex).xy;
}
"""

    private const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
varying vec2 vTex;
uniform samplerExternalOES sTex;
uniform vec3 uR;
uniform vec3 uG;
uniform vec3 uB;
uniform vec3 uO;
void main() {
    vec3 c = texture2D(sTex, vTex).rgb;
    vec3 o = vec3(dot(c, uR), dot(c, uG), dot(c, uB)) + uO;
    gl_FragColor = vec4(clamp(o, 0.0, 1.0), 1.0);
}
"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun initGl() {
        if (context != EGL14.EGL_NO_CONTEXT) return
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(display, ver, 0, ver, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(display, attrs, 0, cfgs, 0, 1, n, 0)
        config = cfgs[0] ?: throw RuntimeException("no EGL config")
        context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        pbuffer = EGL14.eglCreatePbufferSurface(
            display, config, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
        )
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link failed")
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uTexMat = GLES20.glGetUniformLocation(program, "uTexMat")
        uR = GLES20.glGetUniformLocation(program, "uR")
        uG = GLES20.glGetUniformLocation(program, "uG")
        uB = GLES20.glGetUniformLocation(program, "uB")
        uO = GLES20.glGetUniformLocation(program, "uO")
    }

    override fun onInputSurface(request: SurfaceRequest) {
        try {
            initGl()
        } catch (t: Throwable) {
            request.willNotProvideSurface()
            return
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[0])
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val st = SurfaceTexture(tex[0])
        st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
        val surface = Surface(st)
        inputTex = tex[0]
        inputSt = st
        st.setOnFrameAvailableListener(SurfaceTexture.OnFrameAvailableListener { drawFrame() }, handler)
        request.provideSurface(surface, executor) {
            st.setOnFrameAvailableListener(null)
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                GLES20.glDeleteTextures(1, intArrayOf(tex[0]), 0)
            } catch (t: Throwable) { }
            surface.release()
            st.release()
            if (inputSt === st) inputSt = null
        }
    }

    override fun onOutputSurface(output: SurfaceOutput) {
        try {
            initGl()
        } catch (t: Throwable) {
            output.close()
            return
        }
        val surf = output.getSurface(executor) { ev ->
            if (ev.eventCode == SurfaceOutput.Event.EVENT_REQUEST_CLOSE) closeOutput(output)
        }
        val es = EGL14.eglCreateWindowSurface(display, config, surf, intArrayOf(EGL14.EGL_NONE), 0)
        outputs[output] = es
    }

    private fun closeOutput(o: SurfaceOutput) {
        val es = outputs.remove(o)
        if (es != null) {
            try {
                EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
                EGL14.eglDestroySurface(display, es)
            } catch (t: Throwable) { }
        }
        o.close()
    }

    private fun drawFrame() {
        val st = inputSt ?: return
        try {
            EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
            st.updateTexImage()
        } catch (t: Throwable) {
            return
        }
        st.getTransformMatrix(texMat)
        val ts = st.timestamp
        val a = colour
        for ((o, es) in outputs.entries.toList()) {
            try {
                EGL14.eglMakeCurrent(display, es, es, context)
                o.updateTransformMatrix(outMat, texMat)
                val sz = o.size
                GLES20.glViewport(0, 0, sz.width, sz.height)
                GLES20.glUseProgram(program)
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glVertexAttribPointer(aPos, 4, GLES20.GL_FLOAT, false, 0, posBuf)
                GLES20.glEnableVertexAttribArray(aTex)
                GLES20.glVertexAttribPointer(aTex, 4, GLES20.GL_FLOAT, false, 0, texBuf)
                GLES20.glUniformMatrix4fv(uTexMat, 1, false, outMat, 0)
                if (a != null && a.size >= 20) {
                    GLES20.glUniform3f(uR, a[0], a[1], a[2])
                    GLES20.glUniform3f(uG, a[5], a[6], a[7])
                    GLES20.glUniform3f(uB, a[10], a[11], a[12])
                    GLES20.glUniform3f(uO, a[4] / 255f, a[9] / 255f, a[14] / 255f)
                } else {
                    GLES20.glUniform3f(uR, 1f, 0f, 0f)
                    GLES20.glUniform3f(uG, 0f, 1f, 0f)
                    GLES20.glUniform3f(uB, 0f, 0f, 1f)
                    GLES20.glUniform3f(uO, 0f, 0f, 0f)
                }
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, inputTex)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

                EGLExt.eglPresentationTimeANDROID(display, es, ts)
                EGL14.eglSwapBuffers(display, es)
            } catch (t: Throwable) { }
        }
        EGL14.eglMakeCurrent(display, pbuffer, pbuffer, context)
    }
}
