package com.oxycam

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Tiny quaternion toolbox. Quaternions are DoubleArray(4) = (w, x, y, z). Outputs may alias inputs. */
object QuatMath {
    fun identity(out: DoubleArray) {
        out[0] = 1.0; out[1] = 0.0; out[2] = 0.0; out[3] = 0.0
    }

    fun mul(a: DoubleArray, b: DoubleArray, out: DoubleArray) {
        val w = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
        val x = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2]
        val y = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1]
        val z = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
        out[0] = w; out[1] = x; out[2] = y; out[3] = z
    }

    fun conj(a: DoubleArray, out: DoubleArray) {
        val w = a[0]; val x = -a[1]; val y = -a[2]; val z = -a[3]
        out[0] = w; out[1] = x; out[2] = y; out[3] = z
    }

    fun normalize(q: DoubleArray) {
        val n = sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
        if (n < 1e-12) { identity(q); return }
        q[0] /= n; q[1] /= n; q[2] /= n; q[3] /= n
    }

    /** Spherical interpolation from a to b. */
    fun slerp(a: DoubleArray, b: DoubleArray, t: Double, out: DoubleArray) {
        var bw = b[0]; var bx = b[1]; var by = b[2]; var bz = b[3]
        var dot = a[0] * bw + a[1] * bx + a[2] * by + a[3] * bz
        if (dot < 0) { dot = -dot; bw = -bw; bx = -bx; by = -by; bz = -bz }
        val w: Double
        val x: Double
        val y: Double
        val z: Double
        if (dot > 0.9995) {
            w = a[0] + t * (bw - a[0]); x = a[1] + t * (bx - a[1])
            y = a[2] + t * (by - a[2]); z = a[3] + t * (bz - a[3])
        } else {
            val th = acos(dot.coerceIn(-1.0, 1.0))
            val s = sin(th)
            val ka = sin((1 - t) * th) / s
            val kb = sin(t * th) / s
            w = ka * a[0] + kb * bw; x = ka * a[1] + kb * bx
            y = ka * a[2] + kb * by; z = ka * a[3] + kb * bz
        }
        out[0] = w; out[1] = x; out[2] = y; out[3] = z
        normalize(out)
    }

    /** Rotation vector (axis * angle) of a unit quaternion. */
    fun log(q: DoubleArray, out3: DoubleArray) {
        var w = q[0]; var x = q[1]; var y = q[2]; var z = q[3]
        if (w < 0) { w = -w; x = -x; y = -y; z = -z }
        val vn = sqrt(x * x + y * y + z * z)
        val f = if (vn < 1e-9) 2.0 else 2.0 * atan2(vn, w) / vn
        out3[0] = x * f; out3[1] = y * f; out3[2] = z * f
    }

    /** Unit quaternion of a rotation vector. */
    fun exp(v: DoubleArray, out: DoubleArray) {
        val ang = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
        val s = if (ang < 1e-9) 0.5 else sin(ang / 2) / ang
        out[0] = cos(ang / 2); out[1] = v[0] * s; out[2] = v[1] * s; out[3] = v[2] * s
    }

    /** Row-major 3x3 rotation matrix -> quaternion. */
    fun fromMatrix(m: DoubleArray): DoubleArray {
        val tr = m[0] + m[4] + m[8]
        val q = DoubleArray(4)
        if (tr > 0) {
            val s = sqrt(tr + 1.0) * 2
            q[0] = 0.25 * s
            q[1] = (m[7] - m[5]) / s
            q[2] = (m[2] - m[6]) / s
            q[3] = (m[3] - m[1]) / s
        } else if (m[0] > m[4] && m[0] > m[8]) {
            val s = sqrt(1.0 + m[0] - m[4] - m[8]) * 2
            q[0] = (m[7] - m[5]) / s
            q[1] = 0.25 * s
            q[2] = (m[1] + m[3]) / s
            q[3] = (m[2] + m[6]) / s
        } else if (m[4] > m[8]) {
            val s = sqrt(1.0 + m[4] - m[0] - m[8]) * 2
            q[0] = (m[2] - m[6]) / s
            q[1] = (m[1] + m[3]) / s
            q[2] = 0.25 * s
            q[3] = (m[5] + m[7]) / s
        } else {
            val s = sqrt(1.0 + m[8] - m[0] - m[4]) * 2
            q[0] = (m[3] - m[1]) / s
            q[1] = (m[2] + m[6]) / s
            q[2] = (m[5] + m[7]) / s
            q[3] = 0.25 * s
        }
        normalize(q)
        return q
    }

    fun smoothstep(e0: Double, e1: Double, x: Double): Double {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0.0, 1.0)
        return t * t * (3 - 2 * t)
    }

    fun approx(a: Double, b: Double) = abs(a - b) < 1e-9
}
