package com.oxycam

import android.content.Context
import android.content.SharedPreferences
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.effect.GlMatrixTransformation
import kotlin.math.max

/** Glue: reads video + camera info, aligns the gyro clock, and builds the per-frame stabilising transform. */
object Stabilizer {
    class Plan(val effect: GlMatrixTransformation, val info: String)

    /** F = 2 * focalLength / longSensorSide for the back camera (a sane default if the phone does not say). */
    private fun intrinsicsF(ctx: Context): Double {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: continue
                val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: continue
                val long = max(s.width, s.height)
                if (long > 0f) return 2.0 * f / long
            }
        } catch (t: Throwable) { }
        return 1.45
    }

    fun prepare(ctx: Context, src: Uri, data: GyroData, level: Int, zoom0: Double, prefs: SharedPreferences): Plan {
        var w = 1080
        var h = 1920
        var rot = 0
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, src)
            w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: w
            h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: h
            rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } finally {
            try { mmr.release() } catch (t: Throwable) { }
        }
        val upW = if (rot == 90 || rot == 270) h else w
        val upH = if (rot == 90 || rot == 270) w else h
        val aspect = upW.toDouble() / upH.toDouble()
        val focal = intrinsicsF(ctx) * zoom0.coerceAtLeast(1.0)

        val invert = prefs.getInt("gyrodir", 0) == 1
        val offMs = intArrayOf(-150, -100, -50, 0, 50, 100, 150)[prefs.getInt("gyrooff", 3).coerceIn(0, 6)]
        // recording starts roughly 100 ms before the first frame reaches the encoder
        var startNs = data.startNs + 100_000_000L + offMs * 1_000_000L
        var info = "Gyro sync: default"
        if (level >= 2) {
            val lag = SyncCalibrator.estimateLagNs(ctx, src, data, startNs)
            if (lag != null) {
                startNs += lag
                info = "Gyro sync calibrated (${lag / 1_000_000} ms)"
            } else {
                info = "Gyro sync: default (not enough motion to calibrate)"
            }
        }
        val rsSign = if (prefs.getInt("rsdir", 0) == 1) -1.0 else 1.0
        return Plan(StabTransform(data, level, focal, aspect, startNs, invert, rsSign, 0.025), info)
    }
}
