package com.oxycam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import kotlin.math.sqrt

/**
 * Ring buffer of timestamped device orientations (quaternions), filled from the gyroscope
 * (integrated, default) or from TYPE_GAME_ROTATION_VECTOR, at SENSOR_DELAY_FASTEST.
 * quatAt() returns the orientation at any time inside the buffer using SLERP.
 * Timestamps are SensorEvent timestamps (elapsedRealtime clock, nanoseconds).
 */
class GyroEisBuffer(ctx: Context, private val useRotationVector: Boolean = false) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val cap = 8192
    private val ts = LongArray(cap)
    private val qs = DoubleArray(cap * 4)
    private var head = 0
    private var count = 0
    private val lock = Any()
    private var thread: HandlerThread? = null
    private val cur = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private var lastGyroT = 0L
    private val tmpQ = FloatArray(4)
    private val tmpA = DoubleArray(4)
    private val tmpB = DoubleArray(4)

    fun start(): Boolean {
        val wanted = if (useRotationVector) Sensor.TYPE_GAME_ROTATION_VECTOR else Sensor.TYPE_GYROSCOPE
        val s = sm.getDefaultSensor(wanted) ?: sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return false
        synchronized(lock) {
            head = 0
            count = 0
            lastGyroT = 0L
            QuatMath.identity(cur)
        }
        val th = HandlerThread("eis-gyro")
        th.start()
        thread = th
        return sm.registerListener(this, s, SensorManager.SENSOR_DELAY_FASTEST, Handler(th.looper))
    }

    fun stop() {
        sm.unregisterListener(this)
        thread?.quitSafely()
        thread = null
    }

    fun latestTimestamp(): Long = synchronized(lock) {
        if (count == 0) 0L else ts[(head - 1 + cap) % cap]
    }

    fun sampleCount(): Int = synchronized(lock) { count }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val t = e.timestamp
            synchronized(lock) {
                if (lastGyroT != 0L) {
                    val dt = ((t - lastGyroT) * 1e-9).coerceIn(0.0, 0.05)
                    val ax = e.values[0] * dt
                    val ay = e.values[1] * dt
                    val az = e.values[2] * dt
                    val ang = sqrt(ax * ax + ay * ay + az * az)
                    tmpA[0] = kotlin.math.cos(ang / 2)
                    val s = if (ang < 1e-9) 0.5 else kotlin.math.sin(ang / 2) / ang
                    tmpA[1] = s * ax; tmpA[2] = s * ay; tmpA[3] = s * az
                    QuatMath.mul(cur, tmpA, cur)   // body-frame rates: q = q * dq
                    QuatMath.normalize(cur)
                }
                lastGyroT = t
                push(t, cur)
            }
        } else {
            SensorManager.getQuaternionFromVector(tmpQ, e.values)
            synchronized(lock) {
                cur[0] = tmpQ[0].toDouble(); cur[1] = tmpQ[1].toDouble()
                cur[2] = tmpQ[2].toDouble(); cur[3] = tmpQ[3].toDouble()
                QuatMath.normalize(cur)
                push(e.timestamp, cur)
            }
        }
    }

    private fun push(t: Long, q: DoubleArray) {
        ts[head] = t
        val o = head * 4
        qs[o] = q[0]; qs[o + 1] = q[1]; qs[o + 2] = q[2]; qs[o + 3] = q[3]
        head = (head + 1) % cap
        if (count < cap) count++
    }

    private fun phys(i: Int) = (head - count + i + cap) % cap

    /** Orientation at time tNs (clamped to the buffer range). False if there is not enough data. */
    fun quatAt(tNs: Long, out: DoubleArray): Boolean = synchronized(lock) {
        if (count < 2) return@synchronized false
        val firstP = phys(0)
        val lastP = phys(count - 1)
        if (tNs <= ts[firstP]) { copyQ(firstP, out); return@synchronized true }
        if (tNs >= ts[lastP]) { copyQ(lastP, out); return@synchronized true }
        var lo = 0
        var hi = count - 1
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (ts[phys(m)] < tNs) lo = m + 1 else hi = m
        }
        val pb = phys(lo)
        val pa = phys(lo - 1)
        val span = (ts[pb] - ts[pa]).toDouble()
        val f = if (span <= 0) 0.0 else (tNs - ts[pa]) / span
        copyQ(pa, tmpA)
        copyQ(pb, tmpB)
        QuatMath.slerp(tmpA, tmpB, f, out)
        true
    }

    private fun copyQ(p: Int, out: DoubleArray) {
        val o = p * 4
        out[0] = qs[o]; out[1] = qs[o + 1]; out[2] = qs[o + 2]; out[3] = qs[o + 3]
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
