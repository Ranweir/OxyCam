package com.oxycam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

/** All the software image processing: portrait blur, night/AI multi-frame, sharpening, crop, looks and watermark. */
object Processor {

    fun readExif(f: File): ExifData {
        return try {
            val e = ExifInterface(f.path)
            val d = ExifData()
            val f35 = e.getAttributeInt("FocalLengthIn35mmFilm", 0)
            val fl = e.getAttributeDouble("FocalLength", 0.0)
            val fn = e.getAttributeDouble("FNumber", 0.0)
            val iso = e.getAttribute("ISOSpeedRatings")
            val et = e.getAttributeDouble("ExposureTime", 0.0)
            ExifData(
                focal35 = if (f35 > 0) "${f35}mm" else if (fl > 0) String.format(Locale.US, "%.1fmm", fl) else d.focal35,
                aperture = if (fn > 0) String.format(Locale.US, "f/%.1f", fn) else d.aperture,
                iso = if (!iso.isNullOrBlank()) "ISO $iso" else d.iso,
                shutter = if (et > 0) (if (et >= 0.5) String.format(Locale.US, "%.1fs", et) else "1/${(1.0 / et).toInt()}s") else d.shutter
            )
        } catch (t: Throwable) {
            ExifData()
        }
    }

    fun decodeUpright(f: File, maxSide: Int): Bitmap {
        var bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inMutable = true })
            ?: throw IllegalStateException("decode failed")
        val ori = ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val mtx = Matrix()
        when (ori) {
            ExifInterface.ORIENTATION_ROTATE_90 -> mtx.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> mtx.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> mtx.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> mtx.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> mtx.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { mtx.postRotate(90f); mtx.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { mtx.postRotate(270f); mtx.postScale(-1f, 1f) }
        }
        val sc = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
        if (sc < 1f) mtx.postScale(sc, sc)
        if (!mtx.isIdentity) {
            val nb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mtx, true)
            if (nb !== bmp) bmp.recycle()
            bmp = nb
        }
        if (!bmp.isMutable || bmp.config != Bitmap.Config.ARGB_8888) {
            val c = bmp.copy(Bitmap.Config.ARGB_8888, true)
            bmp.recycle()
            bmp = c
        }
        return bmp
    }

    /** Centre-crop to height/width ratio [hw]. */
    fun cropToRatio(src: Bitmap, hw: Float): Bitmap {
        val cur = src.height.toFloat() / src.width
        if (abs(cur - hw) < 0.01f) return src
        val nw: Int
        val nh: Int
        if (cur > hw) { nw = src.width; nh = (src.width * hw).toInt().coerceAtLeast(1) }
        else { nh = src.height; nw = (src.height / hw).toInt().coerceAtLeast(1) }
        val o = Bitmap.createBitmap(src, (src.width - nw) / 2, (src.height - nh) / 2, nw, nh)
        val m = if (o.isMutable && o.config == Bitmap.Config.ARGB_8888) o else o.copy(Bitmap.Config.ARGB_8888, true)
        if (m !== src) src.recycle()
        if (m !== o) o.recycle()
        return m
    }

    fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    fun boxBlur(src: IntArray, w: Int, h: Int, r: Int): IntArray {
        val a = src.copyOf()
        val b = IntArray(w * h)
        val d = 2 * r + 1
        repeat(2) {
            for (y in 0 until h) {
                val row = y * w
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) {
                    val p = a[row + i.coerceIn(0, w - 1)]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                }
                for (x in 0 until w) {
                    b[row + x] = (255 shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                    val add = a[row + minOf(x + r + 1, w - 1)]
                    val rem = a[row + maxOf(x - r, 0)]
                    sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                    sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
            for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0
                for (i in -r..r) {
                    val p = b[i.coerceIn(0, h - 1) * w + x]
                    sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                }
                for (y in 0 until h) {
                    a[y * w + x] = (255 shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                    val add = b[minOf(y + r + 1, h - 1) * w + x]
                    val rem = b[maxOf(y - r, 0) * w + x]
                    sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                    sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                    sb += (add and 255) - (rem and 255)
                }
            }
        }
        return a
    }

    private fun c255(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()

    /** Unsharp mask: clarity / de-blur boost. */
    fun unsharp(bmp: Bitmap, radius: Int, amount: Float) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val bl = boxBlur(px, w, h, radius)
        for (i in px.indices) {
            val p = px[i]
            val q = bl[i]
            val pr = (p shr 16) and 255; val pg = (p shr 8) and 255; val pb = p and 255
            val r = c255(pr + amount * (pr - ((q shr 16) and 255)))
            val g = c255(pg + amount * (pg - ((q shr 8) and 255)))
            val b = c255(pb + amount * (pb - (q and 255)))
            px[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** Auto levels + exposure balance. Returns [meanLuma, spread] measured before the correction. */
    fun autoTone(bmp: Bitmap, strength: Float): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256)
        var sum = 0L
        var n = 0
        var i = 0
        while (i < px.size) {
            val p = px[i]
            val y = (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
            hist[y]++
            sum += y
            n++
            i += 5
        }
        val mean = sum / n.toFloat()
        fun pct(f: Float): Int {
            val target = (n * f).toInt()
            var acc = 0
            for (k in 0..255) { acc += hist[k]; if (acc >= target) return k }
            return 255
        }
        val lo = pct(0.01f)
        val hi = maxOf(pct(0.99f), lo + 40)
        val gam = (ln(0.47) / ln((mean / 255f).coerceIn(0.05f, 0.95f).toDouble())).coerceIn(0.6, 1.3)
        val g = 1.0 + (gam - 1.0) * strength
        val lut = IntArray(256) { k ->
            val x = ((k - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)
            val y = x.toDouble().pow(g).toFloat()
            val mix = k / 255f + (y - k / 255f) * strength.coerceAtMost(1f)
            c255(mix * 255f)
        }
        for (k in px.indices) {
            val p = px[k]
            px[k] = (255 shl 24) or (lut[(p shr 16) and 255] shl 16) or (lut[(p shr 8) and 255] shl 8) or lut[p and 255]
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return floatArrayOf(mean, (hi - lo).toFloat())
    }

    fun averageFrames(files: List<File>, maxSide: Int): Bitmap {
        val base = decodeUpright(files[0], maxSide)
        val w = base.width
        val h = base.height
        val avg = IntArray(w * h)
        base.getPixels(avg, 0, w, 0, 0, w, h)
        var n = 1
        for (i in 1 until files.size) {
            val b = try { decodeUpright(files[i], maxSide) } catch (t: Throwable) { continue }
            if (b.width != w || b.height != h) { b.recycle(); continue }
            val px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            b.recycle()
            n++
            for (k in px.indices) {
                val a = avg[k]
                val c = px[k]
                val r = ((((a shr 16) and 255) * (n - 1)) + ((c shr 16) and 255)) / n
                val g = ((((a shr 8) and 255) * (n - 1)) + ((c shr 8) and 255)) / n
                val bl = (((a and 255) * (n - 1)) + (c and 255)) / n
                avg[k] = (255 shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        base.setPixels(avg, 0, w, 0, 0, w, h)
        return base
    }

    private fun gammaLift(bmp: Bitmap, g: Double, contrast: Double) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val lut = IntArray(256) { i ->
            var y = (i / 255.0).pow(g)
            y = (y - 0.5) * contrast + 0.5
            (y * 255.0).toInt().coerceIn(0, 255)
        }
        for (k in px.indices) {
            val a = px[k]
            px[k] = (255 shl 24) or (lut[(a shr 16) and 255] shl 16) or (lut[(a shr 8) and 255] shl 8) or lut[a and 255]
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** Aligned + de-ghosted merge (OpenCV); falls back to a plain average if OpenCV is unavailable. */
    private fun merged(files: List<File>): Bitmap =
        try { MultiFrame.fuse(files, 2800) } catch (t: Throwable) { averageFrames(files, 3200) }

    /**
     * Photo mode burst: the sharpest frame is the reference, the others are aligned onto it and merged at full
     * resolution (less noise, more real detail). Falls back to the sharpest single frame.
     */
    fun burstPhoto(files: List<File>): Bitmap {
        val ordered = MultiFrame.sortBySharpness(files)
        return try { MultiFrame.fuse(ordered, 4200) } catch (t: Throwable) { decodeUpright(ordered[0], 4200) }
    }

    /** Night mode: align + merge several long-exposure frames, lift shadows. */
    fun night(files: List<File>): Bitmap {
        val b = merged(files)
        gammaLift(b, 0.62, 1.06)
        return b
    }

    /** One-pass 3x3 box blur, cheap enough for 12 MP photos. */
    private fun blur3(src: IntArray, w: Int, h: Int): IntArray {
        val t = IntArray(w * h)
        val o = IntArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val l = src[row + maxOf(x - 1, 0)]
                val c = src[row + x]
                val r = src[row + minOf(x + 1, w - 1)]
                val rr = (((l shr 16) and 255) + ((c shr 16) and 255) + ((r shr 16) and 255)) / 3
                val gg = (((l shr 8) and 255) + ((c shr 8) and 255) + ((r shr 8) and 255)) / 3
                val bb = ((l and 255) + (c and 255) + (r and 255)) / 3
                t[row + x] = (255 shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        for (y in 0 until h) {
            val up = maxOf(y - 1, 0) * w
            val mid = y * w
            val dn = minOf(y + 1, h - 1) * w
            for (x in 0 until w) {
                val l = t[up + x]
                val c = t[mid + x]
                val r = t[dn + x]
                val rr = (((l shr 16) and 255) + ((c shr 16) and 255) + ((r shr 16) and 255)) / 3
                val gg = (((l shr 8) and 255) + ((c shr 8) and 255) + ((r shr 8) and 255)) / 3
                val bb = ((l and 255) + (c and 255) + (r and 255)) / 3
                o[mid + x] = (255 shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        return o
    }

    /** Fine-detail sharpening. Tiny differences are ignored so noise and flat areas are not boosted. */
    fun sharpen(bmp: Bitmap, amount: Float) {
        if (amount <= 0f) return
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val bl = blur3(px, w, h)
        for (i in px.indices) {
            val p = px[i]
            val q = bl[i]
            val pr = (p shr 16) and 255
            val pg = (p shr 8) and 255
            val pb = p and 255
            var dr = pr - ((q shr 16) and 255)
            var dg = pg - ((q shr 8) and 255)
            var db = pb - (q and 255)
            if (abs(dr) < 3) dr = 0
            if (abs(dg) < 3) dg = 0
            if (abs(db) < 3) db = 0
            px[i] = (255 shl 24) or (c255(pr + amount * dr) shl 16) or (c255(pg + amount * dg) shl 8) or c255(pb + amount * db)
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /**
     * Clarity / definition: local contrast on mid-tones. The picture is compared with a heavily blurred copy and the
     * difference is boosted, so textures and edges get punch without changing overall brightness.
     * Near-black and near-white pixels are protected so shadows do not crush and highlights do not clip.
     */
    fun clarity(bmp: Bitmap, amount: Float) {
        if (amount <= 0f) return
        val w = bmp.width
        val h = bmp.height
        val sw = maxOf(w / 10, 8)
        val sh = maxOf(h * sw / w, 8)
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        if (small !== bmp) small.recycle()
        val bl = boxBlur(sp, sw, sh, 3)
        val low = FloatArray(sw * sh)
        for (i in low.indices) {
            val p = bl[i]
            low[i] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val tx = FloatArray(w)
        for (x in 0 until w) {
            val fx = x * (sw - 1f) / maxOf(w - 1, 1)
            x0[x] = fx.toInt()
            x1[x] = minOf(x0[x] + 1, sw - 1)
            tx[x] = fx - x0[x]
        }
        for (y in 0 until h) {
            val fy = y * (sh - 1f) / maxOf(h - 1, 1)
            val y0 = fy.toInt()
            val y1 = minOf(y0 + 1, sh - 1)
            val ty = fy - y0
            val r0 = y0 * sw
            val r1 = y1 * sw
            val row = y * w
            for (x in 0 until w) {
                val a = low[r0 + x0[x]] * (1 - tx[x]) + low[r0 + x1[x]] * tx[x]
                val b = low[r1 + x0[x]] * (1 - tx[x]) + low[r1 + x1[x]] * tx[x]
                val lowL = a * (1 - ty) + b * ty
                val p = px[row + x]
                val pr = (p shr 16) and 255
                val pg = (p shr 8) and 255
                val pb = p and 255
                val l = 0.299f * pr + 0.587f * pg + 0.114f * pb
                val t = (l - 127.5f) / 127.5f
                val mid = 1f - t * t
                var add = amount * (l - lowL) * mid
                if (add > 45f) add = 45f else if (add < -45f) add = -45f
                px[row + x] = (255 shl 24) or (c255(pr + add) shl 16) or (c255(pg + add) shl 8) or c255(pb + add)
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** Gentle exposure balance: gamma only, no contrast stretching. Returns the mean luma it measured (0..255). */
    fun exposureBalance(bmp: Bitmap, strength: Float): Float {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var sum = 0L
        var n = 0
        var i = 0
        while (i < px.size) {
            val p = px[i]
            sum += (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
            n++
            i += 5
        }
        val mean = sum / maxOf(n, 1).toFloat()
        val gam = (ln(0.46) / ln((mean / 255f).coerceIn(0.05f, 0.95f).toDouble())).coerceIn(0.8, 1.25)
        val g = 1.0 + (gam - 1.0) * strength
        if (abs(g - 1.0) < 0.02) return mean
        val lut = IntArray(256) { k -> c255((255.0 * (k / 255.0).pow(g)).toFloat()) }
        for (k in px.indices) {
            val p = px[k]
            px[k] = (255 shl 24) or (lut[(p shr 16) and 255] shl 16) or (lut[(p shr 8) and 255] shl 8) or lut[p and 255]
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return mean
    }

    /**
     * Local tone mapping: dark regions are lifted a little and bright regions are tamed a little,
     * based on a heavily blurred copy of the picture. Overall contrast does not go up, so whites do not blow out
     * and blacks do not crush.
     */
    fun localTone(bmp: Bitmap, strength: Float) {
        val w = bmp.width
        val h = bmp.height
        val sw = maxOf(w / 16, 8)
        val sh = maxOf(h * sw / w, 8)
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val sp = IntArray(sw * sh)
        small.getPixels(sp, 0, sw, 0, 0, sw, sh)
        if (small !== bmp) small.recycle()
        val bl = boxBlur(sp, sw, sh, 3)
        val gain = FloatArray(sw * sh)
        for (i in gain.indices) {
            val p = bl[i]
            val luma = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
            gain[i] = (0.45f / maxOf(luma, 0.05f)).pow(0.5f * strength).coerceIn(0.8f, 1.6f)
        }
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val tx = FloatArray(w)
        for (x in 0 until w) {
            val fx = x * (sw - 1f) / maxOf(w - 1, 1)
            x0[x] = fx.toInt()
            x1[x] = minOf(x0[x] + 1, sw - 1)
            tx[x] = fx - x0[x]
        }
        for (y in 0 until h) {
            val fy = y * (sh - 1f) / maxOf(h - 1, 1)
            val y0 = fy.toInt()
            val y1 = minOf(y0 + 1, sh - 1)
            val ty = fy - y0
            val r0 = y0 * sw
            val r1 = y1 * sw
            val row = y * w
            for (x in 0 until w) {
                val a = gain[r0 + x0[x]] * (1 - tx[x]) + gain[r0 + x1[x]] * tx[x]
                val b = gain[r1 + x0[x]] * (1 - tx[x]) + gain[r1 + x1[x]] * tx[x]
                val g = a * (1 - ty) + b * ty
                val p = px[row + x]
                px[row + x] = (255 shl 24) or
                    (c255(((p shr 16) and 255) * g) shl 16) or
                    (c255(((p shr 8) and 255) * g) shl 8) or
                    c255((p and 255) * g)
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** "AI Photo Boost" for normal photos: light exposure balance and dynamic-range help, no contrast push. */
    fun boost(bmp: Bitmap) {
        exposureBalance(bmp, 0.5f)
        localTone(bmp, 0.3f)
    }

    /** Portrait: clean cut-out (GrabCut + guided filter) and halo-free depth blur; falls back to the simple version. */
    fun portrait(f: File, apI: Int, focus: android.graphics.PointF? = null): Bitmap {
        if (!MultiFrame.init()) return portraitLegacy(f, apI)
        return try {
            PortraitMatte.render(decodeUpright(f, 3200), apI, focus)
        } catch (t: Throwable) {
            portraitLegacy(f, apI)
        }
    }

    private fun portraitLegacy(f: File, apI: Int): Bitmap {
        val bmp = decodeUpright(f, 3200)
        val w = bmp.width
        val h = bmp.height
        var mask: FloatArray? = null
        var mw = 0
        var mh = 0
        try {
            val sc = 640f / maxOf(w, h)
            val small = Bitmap.createScaledBitmap(bmp, (w * sc).toInt(), (h * sc).toInt(), true)
            val seg = Segmentation.getClient(
                SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
            )
            val res = Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
            val buf = res.buffer
            buf.rewind()
            mw = res.width
            mh = res.height
            val m = FloatArray(mw * mh)
            var cnt = 0
            for (i in m.indices) {
                m[i] = buf.float
                if (m[i] > 0.5f) cnt++
            }
            seg.close()
            small.recycle()
            val cover = cnt.toFloat() / m.size
            if (cover in 0.03f..0.92f) mask = m
        } catch (t: Throwable) {
            mask = null
        }
        val bs = maxOf(w / 8, 16)
        val bh = maxOf(h * bs / w, 16)
        val sm = Bitmap.createScaledBitmap(bmp, bs, bh, true)
        val smPx = IntArray(bs * bh)
        sm.getPixels(smPx, 0, bs, 0, 0, bs, bh)
        sm.recycle()
        val radius = intArrayOf(10, 7, 5, 3)[apI.coerceIn(0, 3)]
        val blurredSmall = boxBlur(smPx, bs, bh, radius)
        val bb = Bitmap.createBitmap(bs, bh, Bitmap.Config.ARGB_8888)
        bb.setPixels(blurredSmall, 0, bs, 0, 0, bs, bh)
        val bigBlur = Bitmap.createScaledBitmap(bb, w, h, true)
        bb.recycle()
        val bl = IntArray(w * h)
        bigBlur.getPixels(bl, 0, w, 0, 0, w, h)
        bigBlur.recycle()
        val arr = IntArray(w * h)
        bmp.getPixels(arr, 0, w, 0, 0, w, h)
        val m = mask
        for (y in 0 until h) {
            val ny = (y - h / 2f) / (h / 2f)
            var y0 = 0; var y1 = 0; var ty = 0f
            if (m != null) {
                val fy = y * (mh - 1f) / (h - 1f)
                y0 = fy.toInt(); y1 = minOf(y0 + 1, mh - 1); ty = fy - y0
            }
            for (x in 0 until w) {
                val a: Float
                if (m != null) {
                    val fx = x * (mw - 1f) / (w - 1f)
                    val x0 = fx.toInt()
                    val x1 = minOf(x0 + 1, mw - 1)
                    val tx = fx - x0
                    val top = m[y0 * mw + x0] * (1 - tx) + m[y0 * mw + x1] * tx
                    val bot = m[y1 * mw + x0] * (1 - tx) + m[y1 * mw + x1] * tx
                    a = smooth(0.3f, 0.7f, top * (1 - ty) + bot * ty)
                } else {
                    val nx = (x - w / 2f) / (w / 2f)
                    a = 1f - smooth(0.35f, 0.9f, sqrt(nx * nx + ny * ny))
                }
                val i = y * w + x
                if (a >= 0.99f) continue
                if (a <= 0.01f) { arr[i] = bl[i]; continue }
                val p = arr[i]
                val q = bl[i]
                val r = (((p shr 16) and 255) * a + ((q shr 16) and 255) * (1 - a)).toInt()
                val g = (((p shr 8) and 255) * a + ((q shr 8) and 255) * (1 - a)).toInt()
                val b = ((p and 255) * a + (q and 255) * (1 - a)).toInt()
                arr[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bmp.setPixels(arr, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Colour look (+ optional extra matrix) then watermark/brand frame. */
    fun finish(src: Bitmap, look: Int, extra: ColorMatrix?, wmStyle: Int, author: String, ex: ExifData): Bitmap {
        var out = src
        val fm = Filters.matrix(look)
        val m: ColorMatrix? = when {
            fm != null && extra != null -> ColorMatrix(extra).also { it.postConcat(fm) }
            fm != null -> fm
            else -> extra
        }
        if (m != null) {
            val o = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
            Canvas(o).drawBitmap(out, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
            out.recycle()
            out = o
        }
        if (wmStyle > 0) {
            val r = WatermarkRenderer.render(out, wmStyle, author, ex)
            if (r !== out) out.recycle()
            out = r
        }
        return out
    }
}
