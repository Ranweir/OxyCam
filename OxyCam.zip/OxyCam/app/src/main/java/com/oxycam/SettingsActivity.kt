package com.oxycam

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            fitsSystemWindows = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
        build()
    }

    private fun build() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "←   Camera settings"
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { finish() }
        })

        section("General")
        choiceRow("Grid lines", "grid", listOf("Off", "Grid", "Golden ratio", "Diagonal", "Reference line").let {
            // stored values: 0 off, 1 grid, 2 golden, 3 diagonal, 4 reference
            it
        }, 0)
        switchRow("Level", "Horizon spirit level in the viewfinder", "level", false)
        choiceRow("Aspect ratio / image size", "ratio", listOf("4:3 (full sensor, 4032x3024)", "1:1", "16:9", "Full screen"), 0)
        switchRow("Shutter sound", null, "sound", true)
        switchRow("Location tag", "Save GPS location in photos", "geotag", false)
        switchRow("Quick capture", "Double-press Volume Down inside the app to take a photo", "quick", false)
        choiceRow(
            "Watermark", "wmstyle",
            listOf("Off", "Device name", "Author text", "Device + date", "Leica style frame", "Hasselblad style frame", "ZEISS style frame"), 0
        )
        inputRow("Author / custom text", "wmtext", "Shown on watermark styles that use it")

        section("Photo & video")
        switchRow("Auto HDR", "Use the phone's hardware HDR in Photo mode when available", "autohdr", false)
        switchRow("AI photo boost", "Automatic tone and clarity correction on Photo mode shots", "aiboost", false)
        choiceRow("Video resolution", "vq", listOf("720p HD", "1080p FHD", "4K UHD"), 1)
        choiceRow("Video frame rate", "fps", listOf("30 fps", "60 fps"), 0)
        choiceRow("Video stabilisation", "stabmode", listOf("Off", "EIS", "EIS+", "EIS++"), 0)
        infoRow("About EIS levels", "EIS = standard electronic stabilisation. EIS+ adds optical stabilisation and the phone's preview stabilisation if it has one. EIS++ is EIS+ at a locked 30 fps. Phones without these hardware modes behave like plain EIS.")
        switchRow("Full-sensor 4K (experimental)", "Ask the camera to use the full sensor width for 4K video. Many phones ignore this.", "fullsensor", false)
        infoRow("HEIF / HEIC format", "Not available in this build")
        infoRow("Dolby Vision / HDR10+ video", "Not available in this build")

        section("Pro mode")
        switchRow("Histogram", "Live histogram in Pro mode", "hist", false)
        switchRow("Exposure zebra", "Mark over-exposed areas in Pro mode", "zebra", false)
        switchRow("Focus peaking", "Mark sharp edges in Pro mode (helps manual focus)", "peak", false)
        switchRow("Hasselblad natural colour", "Use the HNCS-style look in Pro mode", "hncs", false)
        infoRow("RAW / RAW+ (DNG)", "Not available in this build")

        section("Interface")
        choiceRow("Camera theme colour", "theme", listOf("OnePlus red", "Classic amber", "Minimal white", "Material You"), 1)
        switchRow("Touch to capture", "Tap the viewfinder to take a photo", "touchcap", false)
        switchRow("Mirror selfie", "Save selfies the way they look in the preview", "mirror", true)
        choiceRow("Volume button function", "volkey", listOf("Shutter", "Zoom", "Volume", "None"), 0)
        infoRow("Shutter method: voice / palm", "Not available in this build (tap to shoot only)")
        infoRow("Storage location", "Saved to internal storage (DCIM/Camera)")

        section("Other")
        actionRow("Reset settings") {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            build()
        }
        root.addView(TextView(this).apply {
            text = "OxyCam 3.0"
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun section(t: String) {
        root.addView(TextView(this).apply {
            text = t
            setTextColor(Color.parseColor("#FFCC00"))
            textSize = 13f
            setPadding(0, dp(22), 0, dp(4))
        })
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(12), 0, dp(12))
    }

    private fun texts(title: String, sub: String?, dim: Boolean = false): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            setTextColor(if (dim) Color.GRAY else Color.WHITE)
            textSize = 16f
        })
        if (sub != null) col.addView(TextView(this).apply {
            text = sub
            setTextColor(Color.GRAY)
            textSize = 12f
        })
        return col
    }

    private fun switchRow(title: String, sub: String?, key: String, def: Boolean) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        root.addView(r)
    }

    private fun choiceRow(title: String, key: String, options: List<String>, def: Int) {
        val r = row()
        r.addView(texts(title, null), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = options[prefs.getInt(key, def).coerceIn(0, options.size - 1)]
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(170)
            gravity = Gravity.END
        }
        r.addView(v)
        r.setOnClickListener {
            val cur = prefs.getInt(key, def).coerceIn(0, options.size - 1)
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.toTypedArray(), cur) { d, which ->
                    prefs.edit().putInt(key, which).apply()
                    v.text = options[which]
                    d.dismiss()
                }
                .show()
        }
        root.addView(r)
    }

    private fun inputRow(title: String, key: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = prefs.getString(key, "").orEmpty().ifBlank { "Not set" }
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(150)
            maxLines = 1
        }
        r.addView(v)
        r.setOnClickListener {
            val et = EditText(this).apply {
                setText(prefs.getString(key, ""))
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine()
            }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setPositiveButton("Save") { _, _ ->
                    prefs.edit().putString(key, et.text.toString().trim()).apply()
                    v.text = et.text.toString().trim().ifBlank { "Not set" }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        root.addView(r)
    }

    private fun infoRow(title: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub, true))
        root.addView(r)
    }

    private fun actionRow(title: String, onClick: () -> Unit) {
        val r = row()
        r.addView(texts(title, null))
        r.setOnClickListener(View.OnClickListener { onClick() })
        root.addView(r)
    }
}
