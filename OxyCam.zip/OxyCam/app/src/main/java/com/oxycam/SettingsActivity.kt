package com.oxycam

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            fitsSystemWindows = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
        build()
    }

    private fun build() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "←   Camera settings"
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { finish() }
        })

        section("General")
        choiceRow("Grid lines", "grid", listOf("Off", "Grid", "Golden ratio", "Diagonal", "Reference line").let {
            // stored values: 0 off, 1 grid, 2 golden, 3 diagonal, 4 reference
            it
        }, 0)
        switchRow("Level", "Horizon spirit level in the viewfinder", "level", false)
        choiceRow("Aspect ratio / image size", "ratio", listOf("4:3 (full sensor, 4032x3024)", "1:1", "16:9", "Full screen"), 0)
        switchRow("Shutter sound", null, "sound", true)
        switchRow("Zoom dial sound", "Tick sound while turning the zoom dial", "zoomsound", true)
        choiceRow("Zoom dial sound volume", "zoomvol", listOf("Low", "Medium", "High"), 1)
        switchRow("Location tag", "Save GPS location in photos", "geotag", false)
        switchRow("Quick capture", "Double-press Volume Down inside the app to take a photo", "quick", false)
        choiceRow(
            "Watermark", "wmstyle",
            listOf("Off", "Device name", "Author text", "Device + date", "Leica style frame", "Hasselblad style frame", "ZEISS style frame"), 0
        )
        inputRow("Author / custom text", "wmtext", "Shown on watermark styles that use it")

        section("Photo & video")
        switchRow("Auto HDR", "Use the phone's hardware HDR in Photo mode when available", "autohdr", false)
        switchRow("Super resolution zoom", "Photo mode, 1x to 2x zoom: takes a quick 5-frame burst and merges it in the background (about 5-6 s) for a cleaner, sharper zoomed photo. You do not need to hold still.", "srzoom", true)
        switchRow("AI photo boost", "Automatic tone and clarity correction on Photo mode shots", "aiboost", false)
        choiceRow("Photo style (vibrancy)", "style", listOf("Natural", "Vibrant", "Vivid"), 1)
        choiceRow("Contrast", "contrast", listOf("Low", "Default", "Medium", "High", "Extra high"), 1)
        choiceRow("Clarity (definition)", "clarity", listOf("Off", "Low", "Medium", "High"), 0)
        infoRow("About photo look", "Style and Contrast also change the live viewfinder. Clarity (local contrast / definition) and Sharpness are applied to the saved photo. None of these apply to video, Night mode or when a filter is chosen.")
        choiceRow("Photo capture", "photocap", listOf("Fast (single shot)", "Enhanced (3-frame burst)"), 1)
        infoRow("About photo capture", "Enhanced takes 3 frames back-to-back the moment you press the shutter (no waiting, no need to stay still) and merges them in the background for less noise and more detail. You can keep shooting while it saves.")
        infoRow("Camera info", prefs.getString("diag", "Open the camera once to see sizes here").orEmpty())
        choiceRow("Photo sharpness", "sharp", listOf("Off", "Low", "Medium", "High"), 2)
        choiceRow("Video resolution", "vq", listOf("720p HD", "1080p FHD", "4K UHD"), 1)
        choiceRow("Video frame rate", "fpsidx2", listOf("30 fps", "60 fps"), 0)
        infoRow("Frame rate limits", "30 or 60 fps. 60 fps at 4K depends on the phone's camera driver: the app tries it and tells you the real frame rate after recording.")
        switchRow("Full-sensor 4K (experimental)", "Ask the camera to use the full sensor width for 4K video. Many phones ignore this.", "fullsensor", false)
        infoRow("HEIF / HEIC format", "Not available in this build")
        switchRow("HDR10+ video", "Record video in 10-bit HDR10+ when the camera supports it (falls back to HDR10 / HLG, then normal video). Not used at 120/240 fps. HDR videos look best on HDR screens.", "vidhdr", false)
        infoRow("HDR video info", prefs.getString("hdrdiag", "Turn on HDR10+ in Video mode once to see what this phone offers").orEmpty())
        infoRow("Dolby Vision video", "Not available in this build")

        section("Pro mode")
        switchRow("Histogram", "Live histogram in Pro mode", "hist", false)
        switchRow("Exposure zebra", "Mark over-exposed areas in Pro mode", "zebra", false)
        switchRow("Focus peaking", "Mark sharp edges in Pro mode (helps manual focus)", "peak", false)
        switchRow("Hasselblad natural colour", "Use the HNCS-style look in Pro mode", "hncs", false)
        infoRow("RAW / RAW+ (DNG)", "Not available in this build")

        section("Interface")
        choiceRow(
            "Camera theme colour", "theme", ThemeColors.names, 1,
            ThemeColors.names.indices.map { ThemeColors.colorFor(this, it) }
        )
        inputRow("Custom colour (hex)", "themehex", "Example: #FF5722. Used when \"Custom colour\" is chosen above")
        choiceRow(
            "Shutter button colour", "shutcol", ThemeColors.shutterNames, 0,
            ThemeColors.shutterNames.indices.map { ThemeColors.shutterColorFor(this, it) }
        )
        inputRow("Custom shutter colour (hex)", "shuthex", "Example: #FF5722. Used when \"Custom colour\" is chosen above")
        switchRow("Touch to capture", "Tap the viewfinder to take a photo", "touchcap", false)
        switchRow("Mirror selfie", "Save selfies the way they look in the preview", "mirror", true)
        choiceRow("Volume button function", "volkey", listOf("Shutter", "Zoom", "Volume", "None"), 0)
        infoRow("Shutter method: voice / palm", "Not available in this build (tap to shoot only)")
        infoRow("Storage location", "Saved to internal storage (DCIM/Camera)")

        section("Other")
        actionRow("Reset settings") {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            build()
        }
        root.addView(TextView(this).apply {
            text = "Made by Ranweir"
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun section(t: String) {
        root.addView(TextView(this).apply {
            text = t
            setTextColor(Color.parseColor("#FFCC00"))
            textSize = 13f
            setPadding(0, dp(22), 0, dp(4))
        })
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(12), 0, dp(12))
    }

    private fun texts(title: String, sub: String?, dim: Boolean = false): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            setTextColor(if (dim) Color.GRAY else Color.WHITE)
            textSize = 16f
        })
        if (sub != null) col.addView(TextView(this).apply {
            text = sub
            setTextColor(Color.GRAY)
            textSize = 12f
        })
        return col
    }

    private fun switchRow(title: String, sub: String?, key: String, def: Boolean) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        root.addView(r)
    }

    private fun choiceRow(title: String, key: String, options: List<String>, def: Int, swatches: List<Int>? = null) {
        val r = row()
        r.addView(texts(title, null), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = options[prefs.getInt(key, def).coerceIn(0, options.size - 1)]
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(170)
            gravity = Gravity.END
        }
        r.addView(v)
        r.setOnClickListener {
            val cur = prefs.getInt(key, def).coerceIn(0, options.size - 1)
            GlassDialog.choice(this, title, options, cur, r, null, swatches) { which ->
                prefs.edit().putInt(key, which).apply()
                v.text = options[which]
            }
        }
        root.addView(r)
    }

    private fun inputRow(title: String, key: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = prefs.getString(key, "").orEmpty().ifBlank { "Not set" }
            setTextColor(Color.GRAY)
            textSize = 14f
            maxWidth = dp(150)
            maxLines = 1
        }
        r.addView(v)
        r.setOnClickListener {
            GlassDialog.input(this, title, prefs.getString(key, "").orEmpty(), r) { text ->
                prefs.edit().putString(key, text).apply()
                v.text = text.ifBlank { "Not set" }
            }
        }
        root.addView(r)
    }

    private fun infoRow(title: String, sub: String) {
        val r = row()
        r.addView(texts(title, sub, true))
        root.addView(r)
    }

    private fun actionRow(title: String, onClick: () -> Unit) {
        val r = row()
        r.addView(texts(title, null))
        r.setOnClickListener(View.OnClickListener { onClick() })
        root.addView(r)
    }
}
