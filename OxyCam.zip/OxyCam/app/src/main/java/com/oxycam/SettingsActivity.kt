package com.oxycam

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("oxycam", Context.MODE_PRIVATE)
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            fitsSystemWindows = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
        build()
    }

    private fun build() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "←   Camera settings"
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { finish() }
        })
        section("General")
        switchRow("Shutter sound", "Play a sound when taking a photo", "sound", true)
        choiceRow("Volume button function", "volkey", listOf("Shutter", "Zoom", "Volume", "None"), 0)
        switchRow("Mirror front camera", "Save selfies the same way as they look in the preview", "mirror", true)
        choiceRow("Watermark", "watermark", listOf("Off", "Device", "Device + time"), 0)
        section("Composition")
        choiceRow("Grid", "grid", listOf("Off", "Grid", "Golden ratio", "Diagonal"), 0)
        switchRow("Level", "Show a horizontal level line in the viewfinder", "level", false)
        section("Video")
        choiceRow("Video resolution", "vq", listOf("720p HD", "1080p FHD", "4K UHD"), 1)
        section("Other")
        actionRow("Reset settings") {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            build()
        }
        root.addView(TextView(this).apply {
            text = "OxyCam 2.0"
            setTextColor(Color.GRAY)
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun section(t: String) {
        root.addView(TextView(this).apply {
            text = t
            setTextColor(Color.parseColor("#FFCC00"))
            textSize = 13f
            setPadding(0, dp(22), 0, dp(4))
        })
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(12), 0, dp(12))
    }

    private fun texts(title: String, sub: String?): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 16f
        })
        if (sub != null) col.addView(TextView(this).apply {
            text = sub
            setTextColor(Color.GRAY)
            textSize = 12f
        })
        return col
    }

    private fun switchRow(title: String, sub: String?, key: String, def: Boolean) {
        val r = row()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this).apply {
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        root.addView(r)
    }

    private fun choiceRow(title: String, key: String, options: List<String>, def: Int) {
        val r = row()
        r.addView(texts(title, null), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = TextView(this).apply {
            text = options[prefs.getInt(key, def).coerceIn(0, options.size - 1)]
            setTextColor(Color.GRAY)
            textSize = 14f
        }
        r.addView(v)
        r.setOnClickListener {
            val cur = prefs.getInt(key, def).coerceIn(0, options.size - 1)
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.toTypedArray(), cur) { d, which ->
                    prefs.edit().putInt(key, which).apply()
                    v.text = options[which]
                    d.dismiss()
                }
                .show()
        }
        root.addView(r)
    }

    private fun actionRow(title: String, onClick: () -> Unit) {
        val r = row()
        r.addView(texts(title, null))
        r.setOnClickListener(View.OnClickListener { onClick() })
        root.addView(r)
    }
}
