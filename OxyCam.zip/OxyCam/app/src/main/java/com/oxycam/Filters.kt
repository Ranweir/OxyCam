package com.oxycam

import android.graphics.ColorMatrix

/** Colour "looks". These are approximations of the named styles built from simple colour maths, not the real vendor colour science. */
object Filters {
    class Look(
        val name: String,
        val sat: Float = 1f, val contrast: Float = 1f, val bright: Float = 0f,
        val r: Float = 1f, val g: Float = 1f, val b: Float = 1f
    )

    val looks: List<Look> = listOf(
        Look("Original"),
        // Vivo ZEISS style
        Look("ZEISS Natural", sat = 1.02f, contrast = 1.06f, r = 0.99f, b = 1.01f),
        Look("ZEISS Cinematic", sat = 0.92f, contrast = 1.18f, bright = -6f, r = 1.02f, b = 1.04f),
        Look("ZEISS Biotar", sat = 1.05f, contrast = 1.08f, bright = 4f, r = 1.04f, b = 0.96f),
        Look("ZEISS Sonnar", contrast = 1.12f, g = 1.01f),
        Look("ZEISS Planar", sat = 0.98f, contrast = 1.04f, bright = 3f),
        Look("ZEISS Textured", sat = 1.08f, contrast = 1.22f, bright = -4f),
        Look("ZEISS Classic", sat = 0.85f, contrast = 1.1f, bright = 10f, r = 1.03f, b = 0.95f),
        // Apple style
        Look("Apple Standard", sat = 1.05f, contrast = 1.04f),
        Look("Apple Rich Contrast", sat = 1.08f, contrast = 1.25f, bright = -8f),
        Look("Apple Vibrant", sat = 1.3f, contrast = 1.08f, bright = 3f),
        Look("Apple Warm", sat = 1.04f, r = 1.06f, b = 0.93f),
        Look("Apple Cool", r = 0.94f, b = 1.06f),
        // Leica style
        Look("Leica Classic", sat = 0.9f, contrast = 1.15f, bright = -4f, r = 1.02f, b = 0.97f),
        Look("Leica Contemporary", contrast = 1.1f, bright = 2f),
        Look("Leica Monochrom", sat = 0f, contrast = 1.3f, bright = -6f),
        // Hasselblad
        Look("Hasselblad HNCS", contrast = 0.98f, bright = 4f, r = 1.01f),
        // Sony
        Look("Sony S-Cinetone", sat = 1.05f, contrast = 1.05f, bright = 2f, r = 1.02f, b = 0.99f),
        Look("Sony S-Log3 (flat)", sat = 0.6f, contrast = 0.62f, bright = 55f),
        Look("Sony HLG (flat)", sat = 0.85f, contrast = 0.8f, bright = 30f),
        // Samsung
        Look("Samsung Galaxy Tone", sat = 1.2f, contrast = 1.06f, bright = 5f, b = 1.02f),
        // Fujifilm sims
        Look("Fuji Provia", sat = 1.05f, contrast = 1.1f),
        Look("Fuji Velvia", sat = 1.55f, contrast = 1.18f, bright = -6f),
        Look("Fuji Astia", sat = 0.95f, bright = 4f, r = 1.02f),
        Look("Fuji Classic Chrome", sat = 0.72f, contrast = 1.15f, bright = -4f, r = 0.98f, g = 0.99f, b = 1.03f),
        Look("Fuji Acros", sat = 0f, contrast = 1.25f, bright = -4f),
        Look("Fuji Classic Neg", sat = 0.9f, contrast = 1.15f, r = 1.03f, b = 0.97f),
        Look("Fuji Eterna", sat = 0.78f, contrast = 0.9f, bright = 12f, b = 1.02f),
        // Ricoh GR
        Look("Ricoh Positive Film", sat = 1.35f, contrast = 1.2f, bright = -6f),
        Look("Ricoh High-Contrast B&W", sat = 0f, contrast = 1.55f, bright = -18f),
        // Insta360
        Look("Insta360 Action", sat = 1.25f, contrast = 1.15f, bright = 2f),
        Look("Insta360 Flat", sat = 0.8f, contrast = 0.8f, bright = 25f)
    )

    val names: List<String> = looks.map { it.name }

    fun indexOf(name: String): Int = looks.indexOfFirst { it.name == name }.coerceAtLeast(0)

    fun cm(
        sat: Float = 1f, contrast: Float = 1f, bright: Float = 0f,
        r: Float = 1f, g: Float = 1f, b: Float = 1f
    ): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val t = (-0.5f * contrast + 0.5f) * 255f + bright
        val c = ColorMatrix(
            floatArrayOf(
                contrast * r, 0f, 0f, 0f, t,
                0f, contrast * g, 0f, 0f, t,
                0f, 0f, contrast * b, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(c)
        return m
    }

    private val contrastAdj = floatArrayOf(-0.10f, 0f, 0.06f, 0.12f, 0.20f)

    /** One vibrancy mode. [ev] is extra exposure (in EV) that goes with the mode. */
    class Style(
        val name: String,
        val sat: Float = 1f, val con: Float = 1f, val br: Float = 0f,
        val r: Float = 1f, val g: Float = 1f, val b: Float = 1f,
        val ev: Float = 0f
    )

    /** Indexes 0..2 are kept the same as older builds so saved settings still point to the same mode. */
    val styles: List<Style> = listOf(
        Style("Natural"),
        Style("Vibrant", sat = 1.22f, con = 1.06f, br = 8f, ev = 0.3f),
        Style("Vivid", sat = 1.38f, con = 1.10f, br = 12f, ev = 0.5f),
        Style("Rich (deep colours)", sat = 1.28f, con = 1.16f, br = -4f, ev = 0.1f),
        Style("Bright & Clean", sat = 1.12f, con = 1.04f, br = 14f, ev = 0.6f),
        Style("Warm Vibrant", sat = 1.24f, con = 1.06f, br = 8f, r = 1.05f, b = 0.94f, ev = 0.3f),
        Style("Cool Vibrant", sat = 1.22f, con = 1.06f, br = 8f, r = 0.95f, b = 1.06f, ev = 0.3f),
        Style("Golden Hour", sat = 1.25f, con = 1.08f, br = 6f, r = 1.09f, g = 1.02f, b = 0.88f, ev = 0.2f),
        Style("Cinematic Vibrant", sat = 1.12f, con = 1.18f, br = -6f, r = 1.03f, g = 0.99f, b = 1.04f),
        Style("HDR Punch", sat = 1.32f, con = 1.22f, br = 2f, ev = 0.2f),
        Style("Pop", sat = 1.55f, con = 1.14f, br = 10f, ev = 0.4f),
        Style("Ultra Vivid", sat = 1.75f, con = 1.20f, br = 12f, ev = 0.5f),
        Style("Dramatic Contrast", sat = 1.15f, con = 1.32f, br = -12f, ev = -0.1f),
        Style("Portrait Glow", sat = 1.08f, con = 0.98f, br = 10f, r = 1.03f, b = 0.98f, ev = 0.3f),
        Style("Soft Pastel", sat = 0.95f, con = 0.92f, br = 16f, ev = 0.5f),
        Style("Matte Film", sat = 0.9f, con = 0.9f, br = 10f, r = 1.02f, b = 0.98f, ev = 0.2f)
    )

    val styleNames: List<String> = styles.map { it.name }

    /** Vibrancy strength: how far the mode is pushed away from Natural. */
    val strengthNames = listOf("Subtle", "Normal", "Strong")
    private val strengthK = floatArrayOf(0.6f, 1f, 1.4f)

    /** Packs the saved vibrancy mode (low 8 bits) and strength (above) into one Int for styleMatrix / styleEv. */
    fun styleOf(p: android.content.SharedPreferences): Int =
        (p.getInt("style", 1) and 0xFF) or (p.getInt("styleint", 1).coerceIn(0, 2) shl 8)

    private fun styleAt(packed: Int): Style = styles[(packed and 0xFF).coerceIn(0, styles.size - 1)]
    private fun kAt(packed: Int): Float = strengthK[((packed shr 8) and 0xFF).coerceIn(0, 2)]

    /**
     * Vibrancy mode used when no filter is chosen. [packed] comes from [styleOf].
     * [contrastIdx] 0..4 (Low, Default, Medium, High, Extra high) adds or removes contrast on top of the style.
     * Applies to the viewfinder and photos. Returns null when nothing would change.
     */
    fun styleMatrix(packed: Int, contrastIdx: Int = 1): ColorMatrix? {
        val st = styleAt(packed)
        val k = kAt(packed)
        val sat = 1f + (st.sat - 1f) * k
        var con = 1f + (st.con - 1f) * k
        val br = st.br * k
        val r = 1f + (st.r - 1f) * k
        val g = 1f + (st.g - 1f) * k
        val b = 1f + (st.b - 1f) * k
        con += contrastAdj[contrastIdx.coerceIn(0, 4)]
        if (sat == 1f && con > 0.999f && con < 1.001f && br == 0f && r == 1f && g == 1f && b == 1f) return null
        return cm(sat, con, br, r, g, b)
    }

    /** Extra exposure (in EV) that goes with the vibrancy mode, so the picture is also a little brighter. */
    fun styleEv(packed: Int): Float = styleAt(packed).ev * kAt(packed)

    fun matrix(i: Int): ColorMatrix? {
        if (i <= 0 || i >= looks.size) return null
        val l = looks[i]
        return cm(l.sat, l.contrast, l.bright, l.r, l.g, l.b)
    }
}
