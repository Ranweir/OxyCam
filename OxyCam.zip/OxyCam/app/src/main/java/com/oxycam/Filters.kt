package com.oxycam

import android.graphics.ColorMatrix

object Filters {
    val names = listOf("Original", "Vivid", "Clear", "Warm", "Cool", "Film", "B&W", "Fade", "Dramatic")

    fun cm(
        sat: Float = 1f, contrast: Float = 1f, bright: Float = 0f,
        r: Float = 1f, g: Float = 1f, b: Float = 1f
    ): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val t = (-0.5f * contrast + 0.5f) * 255f + bright
        val c = ColorMatrix(
            floatArrayOf(
                contrast * r, 0f, 0f, 0f, t,
                0f, contrast * g, 0f, 0f, t,
                0f, 0f, contrast * b, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(c)
        return m
    }

    fun matrix(i: Int): ColorMatrix? = when (i) {
        1 -> cm(sat = 1.35f, contrast = 1.1f)
        2 -> cm(sat = 1.1f, contrast = 1.15f, bright = 8f)
        3 -> cm(sat = 1.05f, r = 1.07f, b = 0.92f)
        4 -> cm(r = 0.93f, b = 1.07f)
        5 -> cm(sat = 0.85f, contrast = 1.08f, bright = 14f, r = 1.04f, b = 0.96f)
        6 -> cm(sat = 0f, contrast = 1.15f)
        7 -> cm(sat = 0.8f, contrast = 0.85f, bright = 22f)
        8 -> cm(sat = 0.9f, contrast = 1.35f, bright = -10f)
        else -> null
    }
}
