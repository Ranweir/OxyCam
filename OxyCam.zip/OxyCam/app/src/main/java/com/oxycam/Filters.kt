package com.oxycam

import android.graphics.ColorMatrix

/** Colour "looks". These are approximations of the named styles built from simple colour maths, not the real vendor colour science. */
object Filters {
    class Look(
        val name: String,
        val sat: Float = 1f, val contrast: Float = 1f, val bright: Float = 0f,
        val r: Float = 1f, val g: Float = 1f, val b: Float = 1f
    )

    val looks: List<Look> = listOf(
        Look("Original"),
        // Vivo ZEISS style
        Look("ZEISS Natural", sat = 1.02f, contrast = 1.06f, r = 0.99f, b = 1.01f),
        Look("ZEISS Cinematic", sat = 0.92f, contrast = 1.18f, bright = -6f, r = 1.02f, b = 1.04f),
        Look("ZEISS Biotar", sat = 1.05f, contrast = 1.08f, bright = 4f, r = 1.04f, b = 0.96f),
        Look("ZEISS Sonnar", contrast = 1.12f, g = 1.01f),
        Look("ZEISS Planar", sat = 0.98f, contrast = 1.04f, bright = 3f),
        Look("ZEISS Textured", sat = 1.08f, contrast = 1.22f, bright = -4f),
        Look("ZEISS Classic", sat = 0.85f, contrast = 1.1f, bright = 10f, r = 1.03f, b = 0.95f),
        // Apple style
        Look("Apple Standard", sat = 1.05f, contrast = 1.04f),
        Look("Apple Rich Contrast", sat = 1.08f, contrast = 1.25f, bright = -8f),
        Look("Apple Vibrant", sat = 1.3f, contrast = 1.08f, bright = 3f),
        Look("Apple Warm", sat = 1.04f, r = 1.06f, b = 0.93f),
        Look("Apple Cool", r = 0.94f, b = 1.06f),
        // Leica style
        Look("Leica Classic", sat = 0.9f, contrast = 1.15f, bright = -4f, r = 1.02f, b = 0.97f),
        Look("Leica Contemporary", contrast = 1.1f, bright = 2f),
        Look("Leica Monochrom", sat = 0f, contrast = 1.3f, bright = -6f),
        // Hasselblad
        Look("Hasselblad HNCS", contrast = 0.98f, bright = 4f, r = 1.01f),
        // Sony
        Look("Sony S-Cinetone", sat = 1.05f, contrast = 1.05f, bright = 2f, r = 1.02f, b = 0.99f),
        Look("Sony S-Log3 (flat)", sat = 0.6f, contrast = 0.62f, bright = 55f),
        Look("Sony HLG (flat)", sat = 0.85f, contrast = 0.8f, bright = 30f),
        // Samsung
        Look("Samsung Galaxy Tone", sat = 1.2f, contrast = 1.06f, bright = 5f, b = 1.02f),
        // Fujifilm sims
        Look("Fuji Provia", sat = 1.05f, contrast = 1.1f),
        Look("Fuji Velvia", sat = 1.55f, contrast = 1.18f, bright = -6f),
        Look("Fuji Astia", sat = 0.95f, bright = 4f, r = 1.02f),
        Look("Fuji Classic Chrome", sat = 0.72f, contrast = 1.15f, bright = -4f, r = 0.98f, g = 0.99f, b = 1.03f),
        Look("Fuji Acros", sat = 0f, contrast = 1.25f, bright = -4f),
        Look("Fuji Classic Neg", sat = 0.9f, contrast = 1.15f, r = 1.03f, b = 0.97f),
        Look("Fuji Eterna", sat = 0.78f, contrast = 0.9f, bright = 12f, b = 1.02f),
        // Ricoh GR
        Look("Ricoh Positive Film", sat = 1.35f, contrast = 1.2f, bright = -6f),
        Look("Ricoh High-Contrast B&W", sat = 0f, contrast = 1.55f, bright = -18f),
        // Insta360
        Look("Insta360 Action", sat = 1.25f, contrast = 1.15f, bright = 2f),
        Look("Insta360 Flat", sat = 0.8f, contrast = 0.8f, bright = 25f)
    )

    val names: List<String> = looks.map { it.name }

    fun indexOf(name: String): Int = looks.indexOfFirst { it.name == name }.coerceAtLeast(0)

    fun cm(
        sat: Float = 1f, contrast: Float = 1f, bright: Float = 0f,
        r: Float = 1f, g: Float = 1f, b: Float = 1f
    ): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val t = (-0.5f * contrast + 0.5f) * 255f + bright
        val c = ColorMatrix(
            floatArrayOf(
                contrast * r, 0f, 0f, 0f, t,
                0f, contrast * g, 0f, 0f, t,
                0f, 0f, contrast * b, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(c)
        return m
    }

    /** Photo style used when no filter is chosen: 0 Natural, 1 Vibrant, 2 Vivid. Applies to the viewfinder and photos. */
    fun styleMatrix(idx: Int): ColorMatrix? = when (idx) {
        1 -> cm(sat = 1.22f, contrast = 1.06f, bright = 8f)
        2 -> cm(sat = 1.38f, contrast = 1.10f, bright = 12f)
        else -> null
    }

    /** Extra exposure (in EV) that goes with the style, so the picture is also a little brighter. */
    fun styleEv(idx: Int): Float = when (idx) {
        1 -> 0.3f
        2 -> 0.5f
        else -> 0f
    }

    fun matrix(i: Int): ColorMatrix? {
        if (i <= 0 || i >= looks.size) return null
        val l = looks[i]
        return cm(l.sat, l.contrast, l.bright, l.r, l.g, l.b)
    }
}
