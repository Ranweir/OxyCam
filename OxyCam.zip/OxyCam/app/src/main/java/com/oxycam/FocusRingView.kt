package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tap-to-focus ring. The ring is drawn in the middle of the view in one of [STYLE_NAMES]; an optional exposure
 * slider (sun on a line) is drawn beside it.
 */
class FocusRingView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    companion object {
        val STYLE_NAMES = listOf(
            "Classic yellow ring", "White ring", "Thick ring", "Double ring", "Dotted ring", "Dashed ring",
            "Ring with centre dot", "Crosshair ring", "Plus target", "iOS square", "Plain square", "Corner brackets",
            "Brackets with dot", "Rounded corners", "Diamond", "Hexagon", "Triangle", "Rangefinder ticks",
            "Aperture iris", "Leica red dot", "Leica frame", "Broken ring", "Radar arc", "Glow ring",
            "Ripple rings", "Cinema frame", "Orange crosshair", "Mini dot"
        )
        private val YELLOW = Color.parseColor("#FFCC00")
        private val ORANGE = Color.parseColor("#FF6A00")
        private val RED = Color.parseColor("#E8001C")
    }

    var ringStyle: Int = 0
        set(v) {
            field = v.coerceIn(0, STYLE_NAMES.size - 1)
            invalidate()
        }
    var showSlider = false
        set(v) {
            field = v
            invalidate()
        }
    var sliderLeft = false
        set(v) {
            field = v
            invalidate()
        }
    var evFrac = 0.5f
        private set
    var sliderLabel = ""
        private set

    fun setEv(frac: Float, label: String) {
        evFrac = frac.coerceIn(0f, 1f)
        sliderLabel = label
        invalidate()
    }

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()

    private fun dp(v: Float) = v * d

    private fun pen(color: Int, w: Float, alpha: Int = 255): Paint {
        p.style = Paint.Style.STROKE
        p.color = color
        p.alpha = alpha
        p.strokeWidth = dp(w)
        p.pathEffect = null
        return p
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        f.color = color
        c.drawCircle(x, y, r, f)
    }

    private fun brackets(c: Canvas, cx: Float, cy: Float, hw: Float, hh: Float, len: Float, paint: Paint) {
        for (sx in intArrayOf(-1, 1)) {
            for (sy in intArrayOf(-1, 1)) {
                val px = cx + sx * hw
                val py = cy + sy * hh
                path.reset()
                path.moveTo(px, py - sy * len)
                path.lineTo(px, py)
                path.lineTo(px - sx * len, py)
                c.drawPath(path, paint)
            }
        }
    }

    private fun polygon(c: Canvas, cx: Float, cy: Float, r: Float, n: Int, paint: Paint) {
        path.reset()
        for (i in 0 until n) {
            val a = -PI / 2 + 2 * PI * i / n
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, paint)
    }

    /** Four short lines at N, E, S, W from radius [r0] to [r1]. */
    private fun ticks(c: Canvas, cx: Float, cy: Float, r0: Float, r1: Float, paint: Paint) {
        c.drawLine(cx, cy - r0, cx, cy - r1, paint)
        c.drawLine(cx, cy + r0, cx, cy + r1, paint)
        c.drawLine(cx - r0, cy, cx - r1, cy, paint)
        c.drawLine(cx + r0, cy, cx + r1, cy, paint)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        drawRing(c, cx, cy, dp(32f))
        if (showSlider) drawSlider(c, cx, cy)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, r: Float) {
        when (ringStyle) {
            0 -> c.drawCircle(cx, cy, r, pen(YELLOW, 2f))
            1 -> c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
            2 -> c.drawCircle(cx, cy, r, pen(Color.WHITE, 4f))
            3 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                c.drawCircle(cx, cy, r * 0.72f, pen(YELLOW, 1.5f))
            }
            4 -> {
                val pe = pen(Color.WHITE, 3f)
                pe.pathEffect = DashPathEffect(floatArrayOf(0.1f, dp(8f)), 0f)
                c.drawCircle(cx, cy, r, pe)
            }
            5 -> {
                val pe = pen(Color.WHITE, 2f)
                pe.pathEffect = DashPathEffect(floatArrayOf(dp(10f), dp(7f)), 0f)
                c.drawCircle(cx, cy, r, pe)
            }
            6 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                dot(c, cx, cy, dp(3f), YELLOW)
            }
            7 -> {
                val pe = pen(Color.WHITE, 1.5f)
                c.drawCircle(cx, cy, r, pe)
                ticks(c, cx, cy, r, r - dp(9f), pen(Color.WHITE, 2f))
            }
            8 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1f, 90))
                val pe = pen(YELLOW, 2f)
                c.drawLine(cx - r * 0.45f, cy, cx + r * 0.45f, cy, pe)
                c.drawLine(cx, cy - r * 0.45f, cx, cy + r * 0.45f, pe)
            }
            9 -> {
                c.drawRoundRect(RectF(cx - r, cy - r, cx + r, cy + r), dp(2f), dp(2f), pen(YELLOW, 1.5f))
                ticks(c, cx, cy, r, r - dp(7f), pen(YELLOW, 1.5f))
            }
            10 -> c.drawRect(RectF(cx - r, cy - r, cx + r, cy + r), pen(Color.WHITE, 1.5f))
            11 -> brackets(c, cx, cy, r, r, dp(14f), pen(Color.WHITE, 2.5f))
            12 -> {
                brackets(c, cx, cy, r, r, dp(14f), pen(YELLOW, 2.5f))
                dot(c, cx, cy, dp(3f), YELLOW)
            }
            13 -> {
                val cr = dp(12f)
                val len = dp(10f)
                val pe = pen(Color.WHITE, 2.5f)
                for (sx in intArrayOf(-1, 1)) {
                    for (sy in intArrayOf(-1, 1)) {
                        val px = cx + sx * r
                        val py = cy + sy * r
                        val left = if (sx < 0) px else px - 2 * cr
                        val top = if (sy < 0) py else py - 2 * cr
                        val start = if (sx < 0 && sy < 0) 180f else if (sx > 0 && sy < 0) 270f else if (sx > 0) 0f else 90f
                        c.drawArc(RectF(left, top, left + 2 * cr, top + 2 * cr), start, 90f, false, pe)
                        c.drawLine(px, py - sy * cr, px, py - sy * (cr + len), pe)
                        c.drawLine(px - sx * cr, py, px - sx * (cr + len), py, pe)
                    }
                }
            }
            14 -> polygon(c, cx, cy, r * 1.15f, 4, pen(Color.WHITE, 1.5f))
            15 -> polygon(c, cx, cy, r, 6, pen(Color.WHITE, 1.5f))
            16 -> polygon(c, cx, cy, r * 1.1f, 3, pen(YELLOW, 1.8f))
            17 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                ticks(c, cx, cy, r, r + dp(9f), pen(Color.WHITE, 2f))
            }
            18 -> {
                polygon(c, cx, cy, r, 6, pen(Color.WHITE, 1.5f))
                val pe = pen(YELLOW, 1.5f, 220)
                for (i in 0 until 6) {
                    val a1 = -PI / 2 + 2 * PI * i / 6
                    val a2 = -PI / 2 + 2 * PI * (i + 2) / 6
                    c.drawLine(
                        cx + (r * cos(a1)).toFloat(), cy + (r * sin(a1)).toFloat(),
                        cx + (r * 0.4f * cos(a2)).toFloat(), cy + (r * 0.4f * sin(a2)).toFloat(), pe
                    )
                }
            }
            19 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                dot(c, cx, cy, dp(5.5f), RED)
            }
            20 -> {
                brackets(c, cx, cy, r * 1.1f, r * 1.1f, dp(13f), pen(Color.WHITE, 2f))
                dot(c, cx, cy, dp(3.5f), RED)
            }
            21 -> {
                val pe = pen(Color.WHITE, 2.5f)
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                for (k in 0 until 3) c.drawArc(oval, -90f + k * 120f + 20f, 80f, false, pe)
            }
            22 -> {
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f, 200))
                c.drawArc(oval, -90f, 100f, false, pen(YELLOW, 4f))
            }
            23 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 9f, 25))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 6f, 55))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 3.5f, 110))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
            }
            24 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f, 255))
                c.drawCircle(cx, cy, r * 0.78f, pen(Color.WHITE, 1.5f, 150))
                c.drawCircle(cx, cy, r * 0.56f, pen(Color.WHITE, 1.5f, 80))
            }
            25 -> brackets(c, cx, cy, r * 1.35f, r * 0.9f, dp(14f), pen(Color.WHITE, 2f))
            26 -> {
                c.drawCircle(cx, cy, r, pen(ORANGE, 2f))
                ticks(c, cx, cy, r, r - dp(9f), pen(ORANGE, 2f))
                val pe = pen(ORANGE, 1.5f)
                c.drawLine(cx - dp(5f), cy, cx + dp(5f), cy, pe)
                c.drawLine(cx, cy - dp(5f), cx, cy + dp(5f), pe)
            }
            else -> {
                c.drawCircle(cx, cy, dp(11f), pen(Color.WHITE, 2f))
                dot(c, cx, cy, dp(2.5f), Color.WHITE)
            }
        }
    }

    private fun drawSlider(c: Canvas, cx: Float, cy: Float) {
        val sx = if (sliderLeft) cx - dp(54f) else cx + dp(54f)
        val half = dp(46f)
        c.drawLine(sx, cy - half, sx, cy + half, pen(Color.WHITE, 1.5f, 170))
        val ty = cy + half - evFrac * 2 * half
        val rr = dp(6.5f)
        dot(c, sx, ty, rr, YELLOW)
        val pe = pen(YELLOW, 1.5f)
        for (i in 0 until 8) {
            val a = PI / 4 * i
            c.drawLine(
                sx + (dp(9.5f) * cos(a)).toFloat(), ty + (dp(9.5f) * sin(a)).toFloat(),
                sx + (dp(12.5f) * cos(a)).toFloat(), ty + (dp(12.5f) * sin(a)).toFloat(), pe
            )
        }
        if (sliderLabel.isNotEmpty()) {
            tp.textSize = dp(11f)
            c.drawText(sliderLabel, sx, cy - half - dp(10f), tp)
        }
    }
}
