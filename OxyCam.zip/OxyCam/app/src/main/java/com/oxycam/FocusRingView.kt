package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tap-to-focus ring. The ring is drawn in the middle of the view in one of [STYLE_NAMES]; an optional exposure
 * slider (sun on a line) is drawn beside it.
 */
class FocusRingView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    companion object {
        val STYLE_NAMES = listOf(
            "Classic yellow ring", "White ring", "Thick ring", "Double ring", "Dotted ring", "Dashed ring",
            "Ring with centre dot", "Crosshair ring", "Plus target", "iOS square", "Plain square", "Corner brackets",
            "Brackets with dot", "Rounded corners", "Diamond", "Hexagon", "Triangle", "Rangefinder ticks",
            "Aperture iris", "Leica red dot", "Leica frame", "Broken ring", "Radar arc", "Glow ring",
            "Ripple rings", "Cinema frame", "Orange crosshair", "Mini dot",
            "Scope", "Square with dot", "Double square", "Octagon", "Pentagon", "Sunburst", "Four dots", "Eight dots",
            "Thin brackets with cross", "Side bars", "Twin arcs", "Diagonal ticks", "Heart", "Squircle",
            "Ring with square", "Four arcs"
        )
        private val YELLOW = Color.parseColor("#FFCC00")
        private val ORANGE = Color.parseColor("#FF6A00")
        private val RED = Color.parseColor("#E8001C")
        private val PINK = Color.parseColor("#FF4D8D")
        private val CYAN = Color.parseColor("#33D6FF")

        /** track: 0 line, 1 thick line, 2 dashed, 3 dotted, 4 ruler, 5 double line, 6 filled bar, 7 arc, 8 none, 9 line with +/-, 10 fading line, 11 steps.
         *  thumb: 0 sun, 1 dot, 2 ring, 3 square, 4 diamond, 5 triangle, 6 bar, 7 plus, 8 star, 9 pill, 10 hollow sun. */
        class SliderSpec(val name: String, val track: Int, val thumb: Int, val color: Int)

        val SLIDERS: List<SliderSpec> = listOf(
            SliderSpec("Sun", 0, 0, YELLOW), SliderSpec("Sun, thick line", 1, 0, YELLOW),
            SliderSpec("Sun, dotted", 3, 0, YELLOW), SliderSpec("Sun, dashed", 2, 0, YELLOW),
            SliderSpec("Sun, ruler", 4, 0, YELLOW), SliderSpec("Sun, plus/minus", 9, 0, YELLOW),
            SliderSpec("Sun, steps", 11, 0, YELLOW), SliderSpec("Sun, fading", 10, 0, YELLOW),
            SliderSpec("Hollow sun", 0, 10, YELLOW), SliderSpec("Dot", 0, 1, Color.WHITE),
            SliderSpec("Yellow dot, thick", 1, 1, YELLOW), SliderSpec("Dot, ruler", 4, 1, Color.WHITE),
            SliderSpec("Dot, steps", 11, 1, Color.WHITE), SliderSpec("Dot, dashed", 2, 1, YELLOW),
            SliderSpec("Dot, double line", 5, 1, YELLOW), SliderSpec("Ring", 0, 2, Color.WHITE),
            SliderSpec("Ring, ruler", 4, 2, Color.WHITE), SliderSpec("Ring, dotted", 3, 2, YELLOW),
            SliderSpec("Ring, plus/minus", 9, 2, Color.WHITE), SliderSpec("Square", 0, 3, Color.WHITE),
            SliderSpec("Square, ruler", 4, 3, YELLOW), SliderSpec("Square, steps", 11, 3, Color.WHITE),
            SliderSpec("Diamond", 0, 4, YELLOW), SliderSpec("Diamond, double line", 5, 4, Color.WHITE),
            SliderSpec("Diamond, ruler", 4, 4, YELLOW), SliderSpec("Pointer", 0, 5, YELLOW),
            SliderSpec("Pointer, steps", 11, 5, Color.WHITE), SliderSpec("Bar", 0, 6, Color.WHITE),
            SliderSpec("Bar, ruler", 4, 6, YELLOW), SliderSpec("Bar, plus/minus", 9, 6, Color.WHITE),
            SliderSpec("Bar, fading", 10, 6, YELLOW), SliderSpec("Plus", 0, 7, YELLOW),
            SliderSpec("Plus, dotted", 3, 7, Color.WHITE), SliderSpec("Star", 0, 8, YELLOW),
            SliderSpec("Star, ruler", 4, 8, Color.WHITE), SliderSpec("Pill", 0, 9, Color.WHITE),
            SliderSpec("Pill, filled bar", 6, 9, YELLOW), SliderSpec("Filled bar, dot", 6, 1, YELLOW),
            SliderSpec("Filled bar, sun", 6, 0, YELLOW), SliderSpec("Arc, sun", 7, 0, YELLOW),
            SliderSpec("Arc, dot", 7, 1, Color.WHITE), SliderSpec("Arc, ring", 7, 2, YELLOW),
            SliderSpec("Arc, bar", 7, 6, Color.WHITE), SliderSpec("Orange sun", 0, 0, ORANGE),
            SliderSpec("Red dot", 0, 1, RED), SliderSpec("Cyan ring, ruler", 4, 2, CYAN),
            SliderSpec("Pink star", 0, 8, PINK), SliderSpec("Sun only", 8, 0, YELLOW),
            SliderSpec("Dot only", 8, 1, Color.WHITE)
        )
        val SLIDER_NAMES: List<String> = SLIDERS.map { it.name }
    }

    var ringStyle: Int = 0
        set(v) {
            field = v.coerceIn(0, STYLE_NAMES.size - 1)
            invalidate()
        }
    var showSlider = false
        set(v) {
            field = v
            invalidate()
        }
    var sliderLeft = false
        set(v) {
            field = v
            invalidate()
        }
    var sliderStyle: Int = 0
        set(v) {
            field = v.coerceIn(0, SLIDERS.size - 1)
            invalidate()
        }
    var showValue = false
        set(v) {
            field = v
            invalidate()
        }
    /** Used by the style picker: draws only the slider, centred, without the ring. */
    var sliderOnly = false
        set(v) {
            field = v
            invalidate()
        }
    var evFrac = 0.5f
        private set
    var sliderLabel = ""
        private set

    fun setEv(frac: Float, label: String) {
        evFrac = frac.coerceIn(0f, 1f)
        sliderLabel = label
        invalidate()
    }

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()

    private fun dp(v: Float) = v * d

    private fun pen(color: Int, w: Float, alpha: Int = 255): Paint {
        p.style = Paint.Style.STROKE
        p.color = color
        p.alpha = alpha
        p.strokeWidth = dp(w)
        p.pathEffect = null
        return p
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        f.color = color
        c.drawCircle(x, y, r, f)
    }

    private fun brackets(c: Canvas, cx: Float, cy: Float, hw: Float, hh: Float, len: Float, paint: Paint) {
        for (sx in intArrayOf(-1, 1)) {
            for (sy in intArrayOf(-1, 1)) {
                val px = cx + sx * hw
                val py = cy + sy * hh
                path.reset()
                path.moveTo(px, py - sy * len)
                path.lineTo(px, py)
                path.lineTo(px - sx * len, py)
                c.drawPath(path, paint)
            }
        }
    }

    private fun polygon(c: Canvas, cx: Float, cy: Float, r: Float, n: Int, paint: Paint) {
        path.reset()
        for (i in 0 until n) {
            val a = -PI / 2 + 2 * PI * i / n
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, paint)
    }

    /** Four short lines at N, E, S, W from radius [r0] to [r1]. */
    private fun ticks(c: Canvas, cx: Float, cy: Float, r0: Float, r1: Float, paint: Paint) {
        c.drawLine(cx, cy - r0, cx, cy - r1, paint)
        c.drawLine(cx, cy + r0, cx, cy + r1, paint)
        c.drawLine(cx - r0, cy, cx - r1, cy, paint)
        c.drawLine(cx + r0, cy, cx + r1, cy, paint)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        if (sliderOnly) {
            drawSlider(c, cx, cy, true)
            return
        }
        drawRing(c, cx, cy, dp(32f))
        if (showSlider) drawSlider(c, cx, cy, false)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, r: Float) {
        when (ringStyle) {
            0 -> c.drawCircle(cx, cy, r, pen(YELLOW, 2f))
            1 -> c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
            2 -> c.drawCircle(cx, cy, r, pen(Color.WHITE, 4f))
            3 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                c.drawCircle(cx, cy, r * 0.72f, pen(YELLOW, 1.5f))
            }
            4 -> {
                val pe = pen(Color.WHITE, 3f)
                pe.pathEffect = DashPathEffect(floatArrayOf(0.1f, dp(8f)), 0f)
                c.drawCircle(cx, cy, r, pe)
            }
            5 -> {
                val pe = pen(Color.WHITE, 2f)
                pe.pathEffect = DashPathEffect(floatArrayOf(dp(10f), dp(7f)), 0f)
                c.drawCircle(cx, cy, r, pe)
            }
            6 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                dot(c, cx, cy, dp(3f), YELLOW)
            }
            7 -> {
                val pe = pen(Color.WHITE, 1.5f)
                c.drawCircle(cx, cy, r, pe)
                ticks(c, cx, cy, r, r - dp(9f), pen(Color.WHITE, 2f))
            }
            8 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1f, 90))
                val pe = pen(YELLOW, 2f)
                c.drawLine(cx - r * 0.45f, cy, cx + r * 0.45f, cy, pe)
                c.drawLine(cx, cy - r * 0.45f, cx, cy + r * 0.45f, pe)
            }
            9 -> {
                c.drawRoundRect(RectF(cx - r, cy - r, cx + r, cy + r), dp(2f), dp(2f), pen(YELLOW, 1.5f))
                ticks(c, cx, cy, r, r - dp(7f), pen(YELLOW, 1.5f))
            }
            10 -> c.drawRect(RectF(cx - r, cy - r, cx + r, cy + r), pen(Color.WHITE, 1.5f))
            11 -> brackets(c, cx, cy, r, r, dp(14f), pen(Color.WHITE, 2.5f))
            12 -> {
                brackets(c, cx, cy, r, r, dp(14f), pen(YELLOW, 2.5f))
                dot(c, cx, cy, dp(3f), YELLOW)
            }
            13 -> {
                val cr = dp(12f)
                val len = dp(10f)
                val pe = pen(Color.WHITE, 2.5f)
                for (sx in intArrayOf(-1, 1)) {
                    for (sy in intArrayOf(-1, 1)) {
                        val px = cx + sx * r
                        val py = cy + sy * r
                        val left = if (sx < 0) px else px - 2 * cr
                        val top = if (sy < 0) py else py - 2 * cr
                        val start = if (sx < 0 && sy < 0) 180f else if (sx > 0 && sy < 0) 270f else if (sx > 0) 0f else 90f
                        c.drawArc(RectF(left, top, left + 2 * cr, top + 2 * cr), start, 90f, false, pe)
                        c.drawLine(px, py - sy * cr, px, py - sy * (cr + len), pe)
                        c.drawLine(px - sx * cr, py, px - sx * (cr + len), py, pe)
                    }
                }
            }
            14 -> polygon(c, cx, cy, r * 1.15f, 4, pen(Color.WHITE, 1.5f))
            15 -> polygon(c, cx, cy, r, 6, pen(Color.WHITE, 1.5f))
            16 -> polygon(c, cx, cy, r * 1.1f, 3, pen(YELLOW, 1.8f))
            17 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                ticks(c, cx, cy, r, r + dp(9f), pen(Color.WHITE, 2f))
            }
            18 -> {
                polygon(c, cx, cy, r, 6, pen(Color.WHITE, 1.5f))
                val pe = pen(YELLOW, 1.5f, 220)
                for (i in 0 until 6) {
                    val a1 = -PI / 2 + 2 * PI * i / 6
                    val a2 = -PI / 2 + 2 * PI * (i + 2) / 6
                    c.drawLine(
                        cx + (r * cos(a1)).toFloat(), cy + (r * sin(a1)).toFloat(),
                        cx + (r * 0.4f * cos(a2)).toFloat(), cy + (r * 0.4f * sin(a2)).toFloat(), pe
                    )
                }
            }
            19 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                dot(c, cx, cy, dp(5.5f), RED)
            }
            20 -> {
                brackets(c, cx, cy, r * 1.1f, r * 1.1f, dp(13f), pen(Color.WHITE, 2f))
                dot(c, cx, cy, dp(3.5f), RED)
            }
            21 -> {
                val pe = pen(Color.WHITE, 2.5f)
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                for (k in 0 until 3) c.drawArc(oval, -90f + k * 120f + 20f, 80f, false, pe)
            }
            22 -> {
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f, 200))
                c.drawArc(oval, -90f, 100f, false, pen(YELLOW, 4f))
            }
            23 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 9f, 25))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 6f, 55))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 3.5f, 110))
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
            }
            24 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f, 255))
                c.drawCircle(cx, cy, r * 0.78f, pen(Color.WHITE, 1.5f, 150))
                c.drawCircle(cx, cy, r * 0.56f, pen(Color.WHITE, 1.5f, 80))
            }
            25 -> brackets(c, cx, cy, r * 1.35f, r * 0.9f, dp(14f), pen(Color.WHITE, 2f))
            26 -> {
                c.drawCircle(cx, cy, r, pen(ORANGE, 2f))
                ticks(c, cx, cy, r, r - dp(9f), pen(ORANGE, 2f))
                val pe = pen(ORANGE, 1.5f)
                c.drawLine(cx - dp(5f), cy, cx + dp(5f), cy, pe)
                c.drawLine(cx, cy - dp(5f), cx, cy + dp(5f), pe)
            }
            28 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                c.drawCircle(cx, cy, r * 0.5f, pen(Color.WHITE, 1f, 160))
                val pe = pen(YELLOW, 1.5f)
                c.drawLine(cx - r * 1.15f, cy, cx + r * 1.15f, cy, pe)
                c.drawLine(cx, cy - r * 1.15f, cx, cy + r * 1.15f, pe)
            }
            29 -> {
                c.drawRect(RectF(cx - r, cy - r, cx + r, cy + r), pen(Color.WHITE, 1.5f))
                dot(c, cx, cy, dp(3f), YELLOW)
            }
            30 -> {
                c.drawRect(RectF(cx - r, cy - r, cx + r, cy + r), pen(Color.WHITE, 1.5f))
                c.drawRect(RectF(cx - r * 0.6f, cy - r * 0.6f, cx + r * 0.6f, cy + r * 0.6f), pen(YELLOW, 1.5f))
            }
            31 -> polygon(c, cx, cy, r, 8, pen(Color.WHITE, 1.5f))
            32 -> polygon(c, cx, cy, r * 1.05f, 5, pen(YELLOW, 1.8f))
            33 -> {
                val pe = pen(YELLOW, 1.8f)
                for (i in 0 until 12) {
                    val a = 2 * PI * i / 12
                    c.drawLine(
                        cx + (r * 0.55f * cos(a)).toFloat(), cy + (r * 0.55f * sin(a)).toFloat(),
                        cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(), pe
                    )
                }
            }
            34 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1f, 70))
                dot(c, cx, cy - r, dp(3.5f), Color.WHITE)
                dot(c, cx, cy + r, dp(3.5f), Color.WHITE)
                dot(c, cx - r, cy, dp(3.5f), Color.WHITE)
                dot(c, cx + r, cy, dp(3.5f), Color.WHITE)
            }
            35 -> {
                for (i in 0 until 8) {
                    val a = 2 * PI * i / 8
                    dot(c, cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(), dp(2.8f), Color.WHITE)
                }
            }
            36 -> {
                brackets(c, cx, cy, r, r, dp(12f), pen(Color.WHITE, 1.5f))
                val pe = pen(YELLOW, 1.5f)
                c.drawLine(cx - dp(7f), cy, cx + dp(7f), cy, pe)
                c.drawLine(cx, cy - dp(7f), cx, cy + dp(7f), pe)
            }
            37 -> {
                val pe = pen(Color.WHITE, 2.5f)
                c.drawLine(cx - r * 1.1f, cy, cx - r * 0.45f, cy, pe)
                c.drawLine(cx + r * 0.45f, cy, cx + r * 1.1f, cy, pe)
                c.drawLine(cx - r * 1.1f, cy - dp(6f), cx - r * 1.1f, cy + dp(6f), pe)
                c.drawLine(cx + r * 1.1f, cy - dp(6f), cx + r * 1.1f, cy + dp(6f), pe)
            }
            38 -> {
                val pe = pen(Color.WHITE, 3f)
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(oval, 145f, 70f, false, pe)
                c.drawArc(oval, -35f, 70f, false, pe)
            }
            39 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                val pe = pen(Color.WHITE, 2f)
                for (k in 0 until 4) {
                    val a = PI / 4 + k * PI / 2
                    c.drawLine(
                        cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(),
                        cx + ((r - dp(9f)) * cos(a)).toFloat(), cy + ((r - dp(9f)) * sin(a)).toFloat(), pe
                    )
                }
            }
            40 -> {
                path.reset()
                val sc = r / 17f
                for (i in 0..60) {
                    val t = 2 * PI * i / 60
                    val s3 = sin(t)
                    val hx = 16 * s3 * s3 * s3
                    val hy = 13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t)
                    val px = cx + (hx * sc).toFloat()
                    val py = cy - ((hy + 2.5) * sc).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, pen(PINK, 2f))
            }
            41 -> c.drawRoundRect(RectF(cx - r, cy - r, cx + r, cy + r), dp(16f), dp(16f), pen(YELLOW, 2f))
            42 -> {
                c.drawCircle(cx, cy, r, pen(Color.WHITE, 1.5f))
                c.drawRect(RectF(cx - r * 0.45f, cy - r * 0.45f, cx + r * 0.45f, cy + r * 0.45f), pen(YELLOW, 1.5f))
            }
            43 -> {
                val pe = pen(Color.WHITE, 3f)
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                for (k in 0 until 4) c.drawArc(oval, k * 90f + 20f, 50f, false, pe)
            }
            else -> {
                c.drawCircle(cx, cy, dp(11f), pen(Color.WHITE, 2f))
                dot(c, cx, cy, dp(2.5f), Color.WHITE)
            }
        }
    }

    private fun sunRays(c: Canvas, x: Float, y: Float, r0: Float, r1: Float, color: Int) {
        val pe = pen(color, 1.5f)
        for (i in 0 until 8) {
            val a = PI / 4 * i
            c.drawLine(
                x + (r0 * cos(a)).toFloat(), y + (r0 * sin(a)).toFloat(),
                x + (r1 * cos(a)).toFloat(), y + (r1 * sin(a)).toFloat(), pe
            )
        }
    }

    private fun drawThumb(c: Canvas, kind: Int, x: Float, y: Float, color: Int, sgn: Float) {
        when (kind) {
            0 -> {
                dot(c, x, y, dp(6.5f), color)
                sunRays(c, x, y, dp(9.5f), dp(12.5f), color)
            }
            1 -> dot(c, x, y, dp(6.5f), color)
            2 -> c.drawCircle(x, y, dp(7f), pen(color, 2f))
            3 -> {
                f.color = color
                c.drawRoundRect(RectF(x - dp(6f), y - dp(6f), x + dp(6f), y + dp(6f)), dp(2f), dp(2f), f)
            }
            4 -> {
                path.reset()
                path.moveTo(x, y - dp(8f))
                path.lineTo(x + dp(8f), y)
                path.lineTo(x, y + dp(8f))
                path.lineTo(x - dp(8f), y)
                path.close()
                f.color = color
                c.drawPath(path, f)
            }
            5 -> {
                path.reset()
                path.moveTo(x - sgn * dp(8f), y)
                path.lineTo(x + sgn * dp(5f), y - dp(7f))
                path.lineTo(x + sgn * dp(5f), y + dp(7f))
                path.close()
                f.color = color
                c.drawPath(path, f)
            }
            6 -> c.drawLine(x - dp(9f), y, x + dp(9f), y, pen(color, 4f))
            7 -> {
                val pe = pen(color, 2.5f)
                c.drawLine(x - dp(8f), y, x + dp(8f), y, pe)
                c.drawLine(x, y - dp(8f), x, y + dp(8f), pe)
            }
            8 -> {
                path.reset()
                for (i in 0 until 8) {
                    val a = -PI / 2 + PI / 4 * i
                    val rr = if (i % 2 == 0) dp(9.5f) else dp(3.5f)
                    val px = x + (rr * cos(a)).toFloat()
                    val py = y + (rr * sin(a)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                f.color = color
                c.drawPath(path, f)
            }
            9 -> {
                f.color = color
                c.drawRoundRect(RectF(x - dp(9f), y - dp(4.5f), x + dp(9f), y + dp(4.5f)), dp(4.5f), dp(4.5f), f)
            }
            else -> {
                c.drawCircle(x, y, dp(5.5f), pen(color, 2f))
                sunRays(c, x, y, dp(8.5f), dp(11.5f), color)
            }
        }
    }

    private fun drawTrack(c: Canvas, kind: Int, sx: Float, top: Float, bot: Float, ty: Float, color: Int) {
        val len = bot - top
        when (kind) {
            0 -> c.drawLine(sx, top, sx, bot, pen(Color.WHITE, 1.5f, 170))
            1 -> c.drawLine(sx, top, sx, bot, pen(Color.WHITE, 3f, 170))
            2 -> {
                val pe = pen(Color.WHITE, 2f, 200)
                var y = top
                while (y < bot) {
                    c.drawLine(sx, y, sx, minOf(y + dp(6f), bot), pe)
                    y += dp(11f)
                }
            }
            3 -> {
                val pe = pen(Color.WHITE, 3f, 200)
                var y = top
                while (y <= bot) {
                    c.drawPoint(sx, y, pe)
                    y += dp(8f)
                }
            }
            4 -> {
                val pe = pen(Color.WHITE, 1.5f, 190)
                for (i in 0..10) {
                    val y = top + len * i / 10f
                    val w = if (i % 5 == 0) dp(10f) else dp(6f)
                    c.drawLine(sx - w / 2, y, sx + w / 2, y, pe)
                }
            }
            5 -> {
                val pe = pen(Color.WHITE, 1.5f, 170)
                c.drawLine(sx - dp(2.5f), top, sx - dp(2.5f), bot, pe)
                c.drawLine(sx + dp(2.5f), top, sx + dp(2.5f), bot, pe)
            }
            6 -> {
                f.color = Color.argb(70, 255, 255, 255)
                c.drawRoundRect(RectF(sx - dp(3f), top, sx + dp(3f), bot), dp(3f), dp(3f), f)
                f.color = color
                c.drawRoundRect(RectF(sx - dp(3f), ty, sx + dp(3f), bot), dp(3f), dp(3f), f)
            }
            9 -> {
                c.drawLine(sx, top, sx, bot, pen(Color.WHITE, 1.5f, 170))
                val pe = pen(Color.WHITE, 2f)
                c.drawLine(sx - dp(4f), top - dp(8f), sx + dp(4f), top - dp(8f), pe)
                c.drawLine(sx, top - dp(12f), sx, top - dp(4f), pe)
                c.drawLine(sx - dp(4f), bot + dp(8f), sx + dp(4f), bot + dp(8f), pe)
            }
            10 -> {
                for (i in 0 until 12) {
                    val a = (255 * (1f - abs((i + 0.5f) / 12f - 0.5f) * 1.7f)).toInt().coerceIn(35, 255)
                    c.drawLine(sx, top + len * i / 12f, sx, top + len * (i + 1) / 12f, pen(Color.WHITE, 2f, a))
                }
            }
            11 -> {
                for (i in 0..10) {
                    val rr = if (i == 5) dp(2.6f) else dp(1.8f)
                    dot(c, sx, top + len * i / 10f, rr, Color.argb(170, 255, 255, 255))
                }
            }
            else -> { }
        }
    }

    private fun drawSlider(c: Canvas, cx: Float, cy: Float, preview: Boolean) {
        val sgn = if (sliderLeft) -1f else 1f
        val spec = SLIDERS[sliderStyle]
        val half = if (preview) dp(32f) else dp(46f)
        val arcR = if (preview) dp(36f) else dp(54f)
        val sx = if (preview) cx else cx + sgn * dp(54f)
        val top = cy - half
        val bot = cy + half
        var tx = sx
        var ty = bot - evFrac * 2 * half
        if (spec.track == 7) {
            val acx = sx - sgn * arcR
            val pe = pen(Color.WHITE, 1.5f, 170)
            var px = 0f
            var py = 0f
            for (i in 0..24) {
                val ang = Math.toRadians(-50.0 + 100.0 * i / 24)
                val x = acx + sgn * (arcR * cos(ang)).toFloat()
                val y = cy + (arcR * sin(ang)).toFloat()
                if (i > 0) c.drawLine(px, py, x, y, pe)
                px = x
                py = y
            }
            val at = Math.toRadians(50.0 - 100.0 * evFrac)
            tx = acx + sgn * (arcR * cos(at)).toFloat()
            ty = cy + (arcR * sin(at)).toFloat()
        } else {
            drawTrack(c, spec.track, sx, top, bot, ty, spec.color)
        }
        drawThumb(c, spec.thumb, tx, ty, spec.color, sgn)
        if (showValue && !preview && sliderLabel.isNotEmpty()) {
            tp.textSize = dp(11f)
            c.drawText(sliderLabel, sx, top - dp(10f) - (if (spec.track == 9) dp(14f) else 0f), tp)
        }
    }
}
