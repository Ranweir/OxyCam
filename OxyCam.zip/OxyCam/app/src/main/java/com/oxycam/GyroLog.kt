package com.oxycam

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock

/** Gyroscope samples recorded while a video is being shot. Times are in the elapsedRealtime clock (ns). */
class GyroData(
    val n: Int,
    val t: LongArray,
    val x: FloatArray,
    val y: FloatArray,
    val z: FloatArray,
    val startNs: Long
)

/** Records the hardware gyroscope on its own thread at the fastest rate the phone allows. */
class GyroLog(ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var thread: HandlerThread? = null
    private var t = LongArray(16384)
    private var x = FloatArray(16384)
    private var y = FloatArray(16384)
    private var z = FloatArray(16384)
    private var n = 0
    private var startNs = 0L

    fun start(): Boolean {
        val s = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return false
        synchronized(this) { n = 0 }
        startNs = SystemClock.elapsedRealtimeNanos()
        val th = HandlerThread("oxy-gyro")
        th.start()
        thread = th
        return sm.registerListener(this, s, 2500, Handler(th.looper))
    }

    fun stop(): GyroData? {
        sm.unregisterListener(this)
        thread?.quitSafely()
        thread = null
        synchronized(this) {
            if (n < 20) return null
            return GyroData(n, t.copyOf(n), x.copyOf(n), y.copyOf(n), z.copyOf(n), startNs)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        synchronized(this) {
            if (n == t.size) {
                val c = n * 2
                t = t.copyOf(c)
                x = x.copyOf(c)
                y = y.copyOf(c)
                z = z.copyOf(c)
            }
            t[n] = e.timestamp
            x[n] = e.values[0]
            y[n] = e.values[1]
            z[n] = e.values[2]
            n++
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
