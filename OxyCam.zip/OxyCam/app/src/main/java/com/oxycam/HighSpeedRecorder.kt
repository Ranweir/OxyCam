package com.oxycam

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.io.File

/**
 * 120 / 240 fps recording through a Camera2 constrained high-speed session (CameraX cannot do this).
 * Records without audio, rear camera only. The caller must release CameraX first.
 */
class HighSpeedRecorder(private val ctx: Context) {

    companion object {
        private fun backId(cm: CameraManager): String? =
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }

        /** True if the rear camera offers a high-speed mode of this size and frame rate. */
        fun supports(ctx: Context, size: Size, fps: Int): Boolean {
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = backId(cm)
                if (id == null) false else {
                    val map = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    if (map == null) false
                    else map.highSpeedVideoSizes.contains(size) &&
                        map.getHighSpeedVideoFpsRangesFor(size).any { it.upper == fps }
                }
            } catch (t: Throwable) {
                false
            }
        }
    }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var mr: MediaRecorder? = null

    @Volatile
    var active = false
        private set

    fun start(tv: TextureView, size: Size, fps: Int, out: File, onStarted: () -> Unit, errCb: (String) -> Unit) {
        val t = HandlerThread("oxy-highspeed")
        t.start()
        thread = t
        handler = Handler(t.looper)
        active = true
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = backId(cm) ?: throw IllegalStateException("no rear camera")
            val ch = cm.getCameraCharacteristics(id)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: throw IllegalStateException("no stream map")
            val ranges = map.getHighSpeedVideoFpsRangesFor(size).filter { it.upper == fps }
            val range = ranges.firstOrNull { it.lower == it.upper }
                ?: ranges.maxByOrNull { it.lower }
                ?: throw IllegalStateException("$fps fps not supported")
            val orient = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

            val rec = MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(out.absolutePath)
            rec.setVideoEncodingBitRate((size.width * size.height * fps * 0.15).toInt().coerceIn(8_000_000, 60_000_000))
            rec.setVideoFrameRate(fps)
            rec.setVideoSize(size.width, size.height)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setOrientationHint(orient)
            rec.prepare()
            mr = rec

            val begin: (SurfaceTexture) -> Unit = { st -> openCam(cm, id, st, size, range, rec, onStarted, errCb) }
            if (tv.isAvailable) {
                begin(tv.surfaceTexture!!)
            } else {
                tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        begin(st)
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        } catch (t2: Throwable) {
            fail(t2.message ?: "error", errCb)
        }
    }

    @SuppressLint("MissingPermission")
    private fun openCam(
        cm: CameraManager, id: String, st: SurfaceTexture, size: Size, range: Range<Int>,
        rec: MediaRecorder, onStarted: () -> Unit, errCb: (String) -> Unit
    ) {
        try {
            st.setDefaultBufferSize(size.width, size.height)
            val preview = Surface(st)
            val recSurface = rec.surface
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    device = cam
                    try {
                        cam.createConstrainedHighSpeedCaptureSession(
                            listOf(preview, recSurface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(s: CameraCaptureSession) {
                                    session = s
                                    try {
                                        val hs = s as CameraConstrainedHighSpeedCaptureSession
                                        val rb = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                                        rb.addTarget(preview)
                                        rb.addTarget(recSurface)
                                        rb.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                                        hs.setRepeatingBurst(hs.createHighSpeedRequestList(rb.build()), null, handler)
                                        rec.start()
                                        onStarted()
                                    } catch (e: Throwable) {
                                        fail(e.message ?: "start failed", errCb)
                                    }
                                }

                                override fun onConfigureFailed(s: CameraCaptureSession) {
                                    fail("high-speed session could not be configured", errCb)
                                }
                            },
                            handler
                        )
                    } catch (e: Throwable) {
                        fail(e.message ?: "session failed", errCb)
                    }
                }

                override fun onDisconnected(cam: CameraDevice) {
                    cam.close()
                }

                override fun onError(cam: CameraDevice, error: Int) {
                    cam.close()
                    fail("camera error $error", errCb)
                }
            }, handler)
        } catch (e: Throwable) {
            fail(e.message ?: "open failed", errCb)
        }
    }

    private fun fail(msg: String, errCb: (String) -> Unit) {
        cleanup()
        errCb(msg)
    }

    fun stop(done: () -> Unit) {
        val h = handler
        val r = Runnable {
            try { session?.stopRepeating() } catch (e: Throwable) { }
            try { session?.abortCaptures() } catch (e: Throwable) { }
            try { mr?.stop() } catch (e: Throwable) { }
            cleanup()
            done()
        }
        if (h != null) h.post(r) else r.run()
    }

    private fun cleanup() {
        active = false
        try { session?.close() } catch (e: Throwable) { }
        session = null
        try { device?.close() } catch (e: Throwable) { }
        device = null
        try {
            mr?.reset()
            mr?.release()
        } catch (e: Throwable) { }
        mr = null
        thread?.quitSafely()
        thread = null
        handler = null
    }
}
