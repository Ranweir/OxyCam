package com.oxycam

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.io.File

/**
 * 120 / 240 fps recording through a Camera2 constrained high-speed session (CameraX cannot do this).
 * Records without audio, rear camera only. The caller must release CameraX first.
 */
class HighSpeedRecorder(private val ctx: Context) {

    companion object {
        private fun backId(cm: CameraManager): String? =
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }

        /** True if the rear camera offers a high-speed mode of this size and frame rate. */
        fun supports(ctx: Context, size: Size, fps: Int): Boolean {
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = backId(cm)
                if (id == null) false else {
                    val map = cm.getCameraCharacteristics(id).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    if (map == null) false
                    else map.highSpeedVideoSizes.contains(size) &&
                        map.getHighSpeedVideoFpsRangesFor(size).any { it.upper == fps }
                }
            } catch (t: Throwable) {
                false
            }
        }
    }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var mr: MediaRecorder? = null

    @Volatile
    var active = false
        private set

    // live controls for the ordinary (4K 60) session
    private var reqBuilder: CaptureRequest.Builder? = null
    private var chars: CameraCharacteristics? = null
    @Volatile private var zoomNow = 1f
    @Volatile private var torchOn = false

    fun setZoom(z: Float) {
        zoomNow = z
        pushControls()
    }

    fun setTorch(on: Boolean) {
        torchOn = on
        pushControls()
    }

    private fun fill(rb: CaptureRequest.Builder) {
        val c = chars
        if (Build.VERSION.SDK_INT >= 30) {
            val r = c?.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            val z = if (r != null) zoomNow.coerceIn(r.lower, r.upper) else zoomNow
            rb.set(CaptureRequest.CONTROL_ZOOM_RATIO, z)
        } else {
            val ar = c?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
            if (ar != null) {
                val z = zoomNow.coerceAtLeast(1f)
                val w = (ar.width() / z).toInt()
                val h = (ar.height() / z).toInt()
                val l = ar.left + (ar.width() - w) / 2
                val t = ar.top + (ar.height() - h) / 2
                rb.set(CaptureRequest.SCALER_CROP_REGION, Rect(l, t, l + w, t + h))
            }
        }
        rb.set(CaptureRequest.FLASH_MODE, if (torchOn) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
    }

    private fun pushControls() {
        val h = handler ?: return
        h.post {
            val rb = reqBuilder ?: return@post
            val s = session ?: return@post
            try {
                fill(rb)
                s.setRepeatingRequest(rb.build(), null, handler)
            } catch (e: Throwable) { }
        }
    }

    /**
     * @param normal false = constrained high-speed session (120/240 fps, no audio).
     *               true  = ordinary Camera2 recording session (e.g. 4K 60 fps), HEVC with H.264 fallback, with audio if [audio].
     */
    fun start(
        tv: TextureView, size: Size, fps: Int, out: File, onStarted: () -> Unit, errCb: (String) -> Unit,
        normal: Boolean = false, audio: Boolean = false
    ) {
        val t = HandlerThread("oxy-highspeed")
        t.start()
        thread = t
        handler = Handler(t.looper)
        active = true
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = backId(cm) ?: throw IllegalStateException("no rear camera")
            val ch = cm.getCameraCharacteristics(id)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: throw IllegalStateException("no stream map")
            val range: Range<Int>
            if (normal) {
                // ordinary session: use the listed range if there is one, otherwise ask for exactly fps-fps anyway
                val listed = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.filter { it.upper == fps }
                range = listed?.firstOrNull { it.lower == it.upper } ?: listed?.maxByOrNull { it.lower } ?: Range(fps, fps)
            } else {
                val ranges = map.getHighSpeedVideoFpsRangesFor(size).filter { it.upper == fps }
                range = ranges.firstOrNull { it.lower == it.upper }
                    ?: ranges.maxByOrNull { it.lower }
                    ?: throw IllegalStateException("$fps fps not supported")
            }
            val orient = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            chars = ch

            val rec = try {
                buildRecorder(size, fps, out, orient, normal, audio, hevc = normal)
            } catch (t: Throwable) {
                if (normal) buildRecorder(size, fps, out, orient, true, audio, hevc = false) else throw t
            }
            mr = rec

            val begin: (SurfaceTexture) -> Unit = { st -> openCam(cm, id, st, size, range, rec, normal, onStarted, errCb) }
            if (tv.isAvailable) {
                begin(tv.surfaceTexture!!)
            } else {
                tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        begin(st)
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        } catch (t2: Throwable) {
            fail(t2.message ?: "error", errCb)
        }
    }

    private fun buildRecorder(
        size: Size, fps: Int, out: File, orient: Int, normal: Boolean, audio: Boolean, hevc: Boolean
    ): MediaRecorder {
        val rec = MediaRecorder()
        try {
            if (audio) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(out.absolutePath)
            val maxBr = if (!normal) 60_000_000 else if (hevc) 50_000_000 else 70_000_000
            rec.setVideoEncodingBitRate((size.width * size.height * fps * 0.15).toInt().coerceIn(8_000_000, maxBr))
            rec.setVideoFrameRate(fps)
            rec.setVideoSize(size.width, size.height)
            rec.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(128_000)
                rec.setAudioSamplingRate(44_100)
            }
            rec.setOrientationHint(orient)
            rec.prepare()
        } catch (t: Throwable) {
            try { rec.release() } catch (e: Throwable) { }
            throw t
        }
        return rec
    }

    /** Ordinary (non high-speed) Camera2 session: viewfinder + encoder, repeating request locked to the fps range. */
    @Suppress("DEPRECATION")
    private fun startNormal(
        cam: CameraDevice, preview: Surface, recSurface: Surface, range: Range<Int>,
        rec: MediaRecorder, onStarted: () -> Unit, errCb: (String) -> Unit
    ) {
        cam.createCaptureSession(
            listOf(preview, recSurface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val rb = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        rb.addTarget(preview)
                        rb.addTarget(recSurface)
                        rb.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                        rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                        fill(rb)
                        reqBuilder = rb
                        s.setRepeatingRequest(rb.build(), null, handler)
                        rec.start()
                        onStarted()
                    } catch (e: Throwable) {
                        fail(e.message ?: "start failed", errCb)
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    fail("camera session could not be configured", errCb)
                }
            },
            handler
        )
    }

    @SuppressLint("MissingPermission")
    private fun openCam(
        cm: CameraManager, id: String, st: SurfaceTexture, size: Size, range: Range<Int>,
        rec: MediaRecorder, normal: Boolean, onStarted: () -> Unit, errCb: (String) -> Unit
    ) {
        try {
            if (normal) st.setDefaultBufferSize(1920, 1080) else st.setDefaultBufferSize(size.width, size.height)
            val preview = Surface(st)
            val recSurface = rec.surface
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    device = cam
                    if (normal) {
                        try {
                            startNormal(cam, preview, recSurface, range, rec, onStarted, errCb)
                        } catch (e: Throwable) {
                            fail(e.message ?: "session failed", errCb)
                        }
                        return
                    }
                    try {
                        cam.createConstrainedHighSpeedCaptureSession(
                            listOf(preview, recSurface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(s: CameraCaptureSession) {
                                    session = s
                                    try {
                                        val hs = s as CameraConstrainedHighSpeedCaptureSession
                                        val rb = cam.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                                        rb.addTarget(preview)
                                        rb.addTarget(recSurface)
                                        rb.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                                        hs.setRepeatingBurst(hs.createHighSpeedRequestList(rb.build()), null, handler)
                                        rec.start()
                                        onStarted()
                                    } catch (e: Throwable) {
                                        fail(e.message ?: "start failed", errCb)
                                    }
                                }

                                override fun onConfigureFailed(s: CameraCaptureSession) {
                                    fail("high-speed session could not be configured", errCb)
                                }
                            },
                            handler
                        )
                    } catch (e: Throwable) {
                        fail(e.message ?: "session failed", errCb)
                    }
                }

                override fun onDisconnected(cam: CameraDevice) {
                    cam.close()
                }

                override fun onError(cam: CameraDevice, error: Int) {
                    cam.close()
                    fail("camera error $error", errCb)
                }
            }, handler)
        } catch (e: Throwable) {
            fail(e.message ?: "open failed", errCb)
        }
    }

    private fun fail(msg: String, errCb: (String) -> Unit) {
        cleanup()
        errCb(msg)
    }

    fun stop(done: () -> Unit) {
        val h = handler
        val r = Runnable {
            try { session?.stopRepeating() } catch (e: Throwable) { }
            try { session?.abortCaptures() } catch (e: Throwable) { }
            try { mr?.stop() } catch (e: Throwable) { }
            cleanup()
            done()
        }
        if (h != null) h.post(r) else r.run()
    }

    private fun cleanup() {
        active = false
        reqBuilder = null
        try { session?.close() } catch (e: Throwable) { }
        session = null
        try { device?.close() } catch (e: Throwable) { }
        device = null
        try {
            mr?.reset()
            mr?.release()
        } catch (e: Throwable) { }
        mr = null
        thread?.quitSafely()
        thread = null
        handler = null
    }
}
