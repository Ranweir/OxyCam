package com.oxycam.eis

import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Tiny allocation-free quaternion helpers. A quaternion is DoubleArray(4) = [w, x, y, z]. */
object Quat {
    fun identity(): DoubleArray = doubleArrayOf(1.0, 0.0, 0.0, 0.0)

    fun set(dst: DoubleArray, src: DoubleArray) {
        dst[0] = src[0]; dst[1] = src[1]; dst[2] = src[2]; dst[3] = src[3]
    }

    fun mul(a: DoubleArray, b: DoubleArray, out: DoubleArray): DoubleArray {
        val w = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
        val x = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2]
        val y = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1]
        val z = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
        out[0] = w; out[1] = x; out[2] = y; out[3] = z
        return out
    }

    fun conj(a: DoubleArray, out: DoubleArray): DoubleArray {
        out[0] = a[0]; out[1] = -a[1]; out[2] = -a[2]; out[3] = -a[3]
        return out
    }

    fun dot(a: DoubleArray, b: DoubleArray): Double = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]

    fun normalize(q: DoubleArray) {
        val n = sqrt(dot(q, q))
        if (n < 1e-12) { q[0] = 1.0; q[1] = 0.0; q[2] = 0.0; q[3] = 0.0; return }
        q[0] /= n; q[1] /= n; q[2] /= n; q[3] /= n
    }

    /** Spherical linear interpolation along the shortest path. [out] may alias [a]. */
    fun slerp(a: DoubleArray, b: DoubleArray, t: Double, out: DoubleArray): DoubleArray {
        var bw = b[0]; var bx = b[1]; var by = b[2]; var bz = b[3]
        var d = a[0] * bw + a[1] * bx + a[2] * by + a[3] * bz
        if (d < 0.0) { d = -d; bw = -bw; bx = -bx; by = -by; bz = -bz }
        val s0: Double
        val s1: Double
        if (d > 0.9995) {
            s0 = 1.0 - t
            s1 = t
        } else {
            val th = acos(d)
            val sn = sin(th)
            s0 = sin((1.0 - t) * th) / sn
            s1 = sin(t * th) / sn
        }
        val w = s0 * a[0] + s1 * bw
        val x = s0 * a[1] + s1 * bx
        val y = s0 * a[2] + s1 * by
        val z = s0 * a[3] + s1 * bz
        out[0] = w; out[1] = x; out[2] = y; out[3] = z
        normalize(out)
        return out
    }

    /** Rotation vector (axis * angle) of a unit quaternion. */
    fun toRotVec(q: DoubleArray, out: DoubleArray) {
        var w = q[0]; var x = q[1]; var y = q[2]; var z = q[3]
        if (w < 0) { w = -w; x = -x; y = -y; z = -z }
        val vn = sqrt(x * x + y * y + z * z)
        val f = if (vn < 1e-9) 2.0 else 2.0 * atan2(vn, w) / vn
        out[0] = x * f; out[1] = y * f; out[2] = z * f
    }

    fun fromRotVec(rx: Double, ry: Double, rz: Double, out: DoubleArray): DoubleArray {
        val a = sqrt(rx * rx + ry * ry + rz * rz)
        if (a < 1e-12) { out[0] = 1.0; out[1] = rx * 0.5; out[2] = ry * 0.5; out[3] = rz * 0.5; normalize(out); return out }
        val s = sin(a / 2) / a
        out[0] = cos(a / 2); out[1] = rx * s; out[2] = ry * s; out[3] = rz * s
        return out
    }

    /** Row-major 3x3 rotation matrix of a unit quaternion. */
    fun toMat3(q: DoubleArray, m: DoubleArray) {
        val w = q[0]; val x = q[1]; val y = q[2]; val z = q[3]
        m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - z * w); m[2] = 2 * (x * z + y * w)
        m[3] = 2 * (x * y + z * w); m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - x * w)
        m[6] = 2 * (x * z - y * w); m[7] = 2 * (y * z + x * w); m[8] = 1 - 2 * (x * x + y * y)
    }
}
