package com.oxycam

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExifData(
    val focal35: String = "26mm",
    val aperture: String = "f/1.8",
    val iso: String = "ISO 100",
    val shutter: String = "1/100s",
    val date: String = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.US).format(Date())
)

/**
 * Watermark styles: 0 off, 1 device name, 2 author text, 3 device + date,
 * 4 Leica style frame, 5 Hasselblad style frame, 6 ZEISS style frame.
 * The brand frames are look-alike layouts drawn with text/shapes, not the official logos.
 */
object WatermarkRenderer {
    fun model(): String = Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL

    fun render(src: Bitmap, style: Int, author: String, ex: ExifData): Bitmap {
        if (style <= 0) return src
        return if (style <= 3) simple(src, style, author, ex) else frame(src, style, author, ex)
    }

    private fun simple(src: Bitmap, style: Int, author: String, ex: ExifData): Bitmap {
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = out.width / 38f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(out.width / 300f, 0f, 0f, Color.BLACK)
        }
        val t = when (style) {
            2 -> if (author.isBlank()) "Shot on " + model() else author
            3 -> "Shot on ${model()}  •  ${ex.date}"
            else -> "Shot on " + model()
        }
        c.drawText(t, out.width / 2f, out.height - out.width * 0.04f, p)
        return out
    }

    private fun frame(src: Bitmap, style: Int, author: String, ex: ExifData): Bitmap {
        val w = src.width
        val h = src.height
        val bar = (w * 0.12f).toInt()
        val out = Bitmap.createBitmap(w, h + bar, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)
        val cy = h + bar / 2f
        val pad = w * 0.045f
        val info = "${ex.focal35}  ${ex.aperture}  ${ex.shutter}  ${ex.iso}"
        val sub = if (author.isBlank()) ex.date else author + "  •  " + ex.date

        val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 25, 25) }
        val grey = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(110, 110, 110) }
        val big = bar * 0.30f
        val small = bar * 0.17f

        when (style) {
            4 -> { // Leica style: red dot + wordmark left, specs right
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(224, 0, 18) }
                c.drawCircle(pad + bar * 0.2f, cy, bar * 0.2f, dot)
                dark.textSize = big
                dark.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
                c.drawText("Leica", pad + bar * 0.5f, cy + big * 0.35f, dark)
                right(c, w - pad, cy, model(), info, dark, grey, small)
            }
            5 -> { // Hasselblad style: spaced wordmark centred, specs underneath
                dark.textSize = big * 0.9f
                dark.textAlign = Paint.Align.CENTER
                dark.letterSpacing = 0.35f
                dark.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                c.drawText("HASSELBLAD", w / 2f, cy - bar * 0.02f, dark)
                grey.textSize = small
                grey.textAlign = Paint.Align.CENTER
                c.drawText(model() + "   " + info, w / 2f, cy + bar * 0.28f, grey)
            }
            else -> { // ZEISS style: blue wordmark left, specs right
                val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(0, 85, 160)
                    textSize = big
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    letterSpacing = 0.25f
                }
                c.drawText("ZEISS", pad, cy + big * 0.35f, blue)
                right(c, w - pad, cy, model(), info, dark, grey, small)
            }
        }
        grey.textSize = small * 0.8f
        grey.textAlign = Paint.Align.RIGHT
        c.drawText(sub, w - pad, h + bar - small * 0.5f, grey)
        return out
    }

    private fun right(c: Canvas, x: Float, cy: Float, l1: String, l2: String, p1: Paint, p2: Paint, size: Float) {
        p1.textAlign = Paint.Align.RIGHT
        p1.letterSpacing = 0f
        p1.typeface = Typeface.DEFAULT_BOLD
        p1.textSize = size * 1.2f
        p2.textAlign = Paint.Align.RIGHT
        p2.textSize = size
        c.drawText(l1, x, cy - size * 0.2f, p1)
        c.drawText(l2, x, cy + size * 1.2f, p2)
    }
}
