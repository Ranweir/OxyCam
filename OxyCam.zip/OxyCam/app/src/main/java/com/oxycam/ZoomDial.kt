package com.oxycam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/** OxygenOS style circular zoom wheel: ticks sit on a big circle, drag sideways to rotate it. */
class ZoomDial(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var minZ = 1f
    var maxZ = 8f
    var zoom = 1f
        set(v) {
            field = v
            invalidate()
        }
    var onZoom: ((Float) -> Unit)? = null
    var onTouching: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val accent = Color.parseColor("#FFCC00")
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 0, 0, 0) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.6f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * d
        textAlign = Paint.Align.CENTER
    }
    private val cur = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00")
        textSize = 24f * d
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val pointer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00")
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
    }

    private val majors = floatArrayOf(0.6f, 1f, 2f, 3f, 4f, 5f, 6f, 8f, 10f, 15f, 20f, 30f)
    private val degPerOctave = 34f
    private val k = degPerOctave / ln(2f)
    private var lastX = 0f

    private fun stepFor(v: Float): Float = if (v < 2f) 0.1f else if (v < 5f) 0.25f else 0.5f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val r = w * 0.85f
        val top = 14f * d
        val cx = w / 2f
        val cy = top + r
        c.drawCircle(cx, cy, r, bg)
        c.drawCircle(cx, cy, r, ring)

        val lnCur = ln(zoom)
        var v = (minZ * 10f).toInt() / 10f
        if (v < 0.1f) v = 0.1f
        var guard = 0
        while (v <= maxZ + 0.001f && guard < 2000) {
            guard++
            val phi = (ln(v) - lnCur) * k
            if (abs(phi) <= 40f && v >= minZ - 0.001f) {
                val major = majors.any { abs(it - v) < 0.001f }
                val len = if (major) 15f * d else 8f * d
                c.save()
                c.rotate(phi, cx, cy)
                tick.color = if (major) Color.WHITE else Color.argb(150, 255, 255, 255)
                c.drawLine(cx, top, cx, top + len, tick)
                if (major) {
                    val t = if (v < 1f) ".${(v * 10).roundToInt()}" else v.toInt().toString()
                    c.drawText(t, cx, top + len + 18f * d, label)
                }
                c.restore()
            }
            v = ((v + stepFor(v)) * 100f).roundToInt() / 100f
        }
        c.drawLine(cx, top - 10f * d, cx, top + 20f * d, pointer)
        c.drawText(String.format(java.util.Locale.US, "%.1fx", zoom), cx, top + 78f * d, cur)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                onTouching?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val r = width * 0.85f
                val dx = e.x - lastX
                lastX = e.x
                val dDeg = -dx / r * (180f / Math.PI.toFloat()) * 1.6f
                val nz = exp(ln(zoom) + dDeg / k).coerceIn(minZ, maxZ)
                zoom = nz
                onZoom?.invoke(nz)
                onTouching?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onTouching?.invoke()
        }
        return true
    }
}
