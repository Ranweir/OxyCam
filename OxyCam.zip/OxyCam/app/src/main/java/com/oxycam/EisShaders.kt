package com.oxycam

/**
 * GLSL for the EIS renderer.
 *
 * The picture is drawn as a 33x33 mesh. Per vertex (vertex shader) we work out where in the camera image that
 * output point comes from:
 *   output uv -> centre crop (x0.85) -> sensor-quad uv (matrix T) -> camera ray -> rotate by the rotation vector of the
 *   sensor row that point belongs to (32 horizontal strips, rotation interpolated between strip boundaries)
 *   -> back to uv (= homography K * R * K^-1) -> SurfaceTexture matrix.
 * The fragment shader then samples the camera frame and applies Contrast Adaptive Sharpening (CAS)
 * so the cropped / upscaled picture stays crisp.
 */
object EisShaders {
    const val VERTEX = """
precision highp float;
attribute vec2 aUv;
uniform mat4 uTexMat;      // SurfaceTexture matrix
uniform mat4 uOutT;        // output quad uv -> sensor quad uv
uniform vec3 uRv[33];      // rotation vector per strip boundary (camera sensor frame)
uniform vec2 uInvF;        // ray scale: ray.x = (u-0.5)*uInvF.x, ray.y = -(v-0.5)*uInvF.y
uniform float uCrop;       // 0.85 = 15% crop
uniform vec2 uPix;         // 1 / output size
varying vec2 vTex;
varying vec2 vDx;
varying vec2 vDy;

mat3 rodrigues(vec3 r) {
    float th = length(r);
    if (th < 1e-6) return mat3(1.0);
    vec3 k = r / th;
    float s = sin(th);
    float c = 1.0 - cos(th);
    mat3 K = mat3(0.0, k.z, -k.y,  -k.z, 0.0, k.x,  k.y, -k.x, 0.0);
    return mat3(1.0) + s * K + c * (K * K);
}

vec2 warp(vec2 uvOut) {
    vec2 uvc = (uvOut - 0.5) * uCrop + 0.5;
    vec2 uvS = (uOutT * vec4(uvc, 0.0, 1.0)).xy;
    float row = clamp((1.0 - uvS.y) * 32.0, 0.0, 32.0);
    int j0 = int(min(floor(row), 31.0));
    float f = row - float(j0);
    vec3 rv = mix(uRv[j0], uRv[j0 + 1], f);
    vec3 ray = vec3((uvS.x - 0.5) * uInvF.x, -(uvS.y - 0.5) * uInvF.y, 1.0);
    vec3 r2 = rodrigues(rv) * ray;
    vec2 src = vec2(r2.x / r2.z / uInvF.x + 0.5, -r2.y / r2.z / uInvF.y + 0.5);
    return (uTexMat * vec4(src, 0.0, 1.0)).xy;
}

void main() {
    gl_Position = vec4(aUv * 2.0 - 1.0, 0.0, 1.0);
    vTex = warp(aUv);
    vDx = warp(aUv + vec2(uPix.x, 0.0)) - vTex;   // texture-space step for one output pixel (for sharpening)
    vDy = warp(aUv + vec2(0.0, uPix.y)) - vTex;
}
"""

    const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision highp float;
uniform samplerExternalOES sTex;
uniform float uSharp;      // 0..1
varying vec2 vTex;
varying vec2 vDx;
varying vec2 vDy;

void main() {
    vec3 e = texture2D(sTex, vTex).rgb;
    vec3 a = texture2D(sTex, vTex - vDy).rgb;
    vec3 b = texture2D(sTex, vTex - vDx).rgb;
    vec3 c = texture2D(sTex, vTex + vDx).rgb;
    vec3 d = texture2D(sTex, vTex + vDy).rgb;
    vec3 mn = min(min(min(a, b), min(c, d)), e);
    vec3 mx = max(max(max(a, b), max(c, d)), e);
    // Contrast Adaptive Sharpening: less sharpening where the neighbourhood is already high-contrast
    vec3 amp = clamp(min(mn, 1.0 - mx) / max(mx, 1e-4), 0.0, 1.0);
    amp = sqrt(amp);
    float peak = -1.0 / mix(8.0, 5.0, uSharp);
    vec3 w = amp * peak;
    vec3 col = (w * (a + b + c + d) + e) / (1.0 + 4.0 * w);
    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""
}
